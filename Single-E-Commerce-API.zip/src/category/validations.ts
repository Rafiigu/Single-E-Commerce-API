import { z } from "zod";

export const listCategoriesQuerySchema = z.object({
  mode: z.enum(["all", "pagination"]).default("pagination"),
  page: z.coerce
    .number()
    .default(1)
    .transform((v) => {
      if (v < 1) {
        return 1;
      }

      return v;
    }),
  size: z.coerce
    .number()
    .default(10)
    .transform((v) => {
      if (v < 1) {
        return 1;
      }

      return v;
    }),
  search: z.string().optional(),
  status: z.enum(["active", "inactive", "all"]).default("all"),
});

export const idCategoryParamsSchema = z.object({
  id: z.string({ required_error: "ID wajib ada." }),
});

export const mutateCategoryBodySchema = z.object({
  name: z.string({ required_error: "Nama kategori harus ada." }),
});
