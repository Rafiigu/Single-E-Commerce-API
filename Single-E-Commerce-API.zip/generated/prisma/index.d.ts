
/**
 * Client
**/

import * as runtime from './runtime/library.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model Admin
 * 
 */
export type Admin = $Result.DefaultSelection<Prisma.$AdminPayload>
/**
 * Model User
 * 
 */
export type User = $Result.DefaultSelection<Prisma.$UserPayload>
/**
 * Model UserVerificationToken
 * 
 */
export type UserVerificationToken = $Result.DefaultSelection<Prisma.$UserVerificationTokenPayload>
/**
 * Model Category
 * 
 */
export type Category = $Result.DefaultSelection<Prisma.$CategoryPayload>
/**
 * Model Product
 * 
 */
export type Product = $Result.DefaultSelection<Prisma.$ProductPayload>
/**
 * Model StockMutation
 * 
 */
export type StockMutation = $Result.DefaultSelection<Prisma.$StockMutationPayload>
/**
 * Model PaymentTerm
 * 
 */
export type PaymentTerm = $Result.DefaultSelection<Prisma.$PaymentTermPayload>
/**
 * Model PaymentAccount
 * 
 */
export type PaymentAccount = $Result.DefaultSelection<Prisma.$PaymentAccountPayload>
/**
 * Model Wishlist
 * 
 */
export type Wishlist = $Result.DefaultSelection<Prisma.$WishlistPayload>
/**
 * Model TopUp
 * 
 */
export type TopUp = $Result.DefaultSelection<Prisma.$TopUpPayload>
/**
 * Model Transaction
 * 
 */
export type Transaction = $Result.DefaultSelection<Prisma.$TransactionPayload>
/**
 * Model TransactionDetails
 * 
 */
export type TransactionDetails = $Result.DefaultSelection<Prisma.$TransactionDetailsPayload>

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more Admins
 * const admins = await prisma.admin.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more Admins
   * const admins = await prisma.admin.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

  /**
   * Add a middleware
   * @deprecated since 4.16.0. For new code, prefer client extensions instead.
   * @see https://pris.ly/d/extensions
   */
  $use(cb: Prisma.Middleware): void

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>


  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.admin`: Exposes CRUD operations for the **Admin** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Admins
    * const admins = await prisma.admin.findMany()
    * ```
    */
  get admin(): Prisma.AdminDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.user`: Exposes CRUD operations for the **User** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Users
    * const users = await prisma.user.findMany()
    * ```
    */
  get user(): Prisma.UserDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.userVerificationToken`: Exposes CRUD operations for the **UserVerificationToken** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more UserVerificationTokens
    * const userVerificationTokens = await prisma.userVerificationToken.findMany()
    * ```
    */
  get userVerificationToken(): Prisma.UserVerificationTokenDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.category`: Exposes CRUD operations for the **Category** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Categories
    * const categories = await prisma.category.findMany()
    * ```
    */
  get category(): Prisma.CategoryDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.product`: Exposes CRUD operations for the **Product** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Products
    * const products = await prisma.product.findMany()
    * ```
    */
  get product(): Prisma.ProductDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.stockMutation`: Exposes CRUD operations for the **StockMutation** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more StockMutations
    * const stockMutations = await prisma.stockMutation.findMany()
    * ```
    */
  get stockMutation(): Prisma.StockMutationDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.paymentTerm`: Exposes CRUD operations for the **PaymentTerm** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more PaymentTerms
    * const paymentTerms = await prisma.paymentTerm.findMany()
    * ```
    */
  get paymentTerm(): Prisma.PaymentTermDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.paymentAccount`: Exposes CRUD operations for the **PaymentAccount** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more PaymentAccounts
    * const paymentAccounts = await prisma.paymentAccount.findMany()
    * ```
    */
  get paymentAccount(): Prisma.PaymentAccountDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.wishlist`: Exposes CRUD operations for the **Wishlist** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Wishlists
    * const wishlists = await prisma.wishlist.findMany()
    * ```
    */
  get wishlist(): Prisma.WishlistDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.topUp`: Exposes CRUD operations for the **TopUp** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more TopUps
    * const topUps = await prisma.topUp.findMany()
    * ```
    */
  get topUp(): Prisma.TopUpDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.transaction`: Exposes CRUD operations for the **Transaction** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Transactions
    * const transactions = await prisma.transaction.findMany()
    * ```
    */
  get transaction(): Prisma.TransactionDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.transactionDetails`: Exposes CRUD operations for the **TransactionDetails** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more TransactionDetails
    * const transactionDetails = await prisma.transactionDetails.findMany()
    * ```
    */
  get transactionDetails(): Prisma.TransactionDetailsDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
   * Metrics
   */
  export type Metrics = runtime.Metrics
  export type Metric<T> = runtime.Metric<T>
  export type MetricHistogram = runtime.MetricHistogram
  export type MetricHistogramBucket = runtime.MetricHistogramBucket

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 6.8.2
   * Query Engine version: 2060c79ba17c6bb9f5823312b6f6b7f4a845738e
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    Admin: 'Admin',
    User: 'User',
    UserVerificationToken: 'UserVerificationToken',
    Category: 'Category',
    Product: 'Product',
    StockMutation: 'StockMutation',
    PaymentTerm: 'PaymentTerm',
    PaymentAccount: 'PaymentAccount',
    Wishlist: 'Wishlist',
    TopUp: 'TopUp',
    Transaction: 'Transaction',
    TransactionDetails: 'TransactionDetails'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    db?: Datasource
  }

  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "admin" | "user" | "userVerificationToken" | "category" | "product" | "stockMutation" | "paymentTerm" | "paymentAccount" | "wishlist" | "topUp" | "transaction" | "transactionDetails"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      Admin: {
        payload: Prisma.$AdminPayload<ExtArgs>
        fields: Prisma.AdminFieldRefs
        operations: {
          findUnique: {
            args: Prisma.AdminFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AdminPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.AdminFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AdminPayload>
          }
          findFirst: {
            args: Prisma.AdminFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AdminPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.AdminFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AdminPayload>
          }
          findMany: {
            args: Prisma.AdminFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AdminPayload>[]
          }
          create: {
            args: Prisma.AdminCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AdminPayload>
          }
          createMany: {
            args: Prisma.AdminCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.AdminDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AdminPayload>
          }
          update: {
            args: Prisma.AdminUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AdminPayload>
          }
          deleteMany: {
            args: Prisma.AdminDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.AdminUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.AdminUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AdminPayload>
          }
          aggregate: {
            args: Prisma.AdminAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateAdmin>
          }
          groupBy: {
            args: Prisma.AdminGroupByArgs<ExtArgs>
            result: $Utils.Optional<AdminGroupByOutputType>[]
          }
          count: {
            args: Prisma.AdminCountArgs<ExtArgs>
            result: $Utils.Optional<AdminCountAggregateOutputType> | number
          }
        }
      }
      User: {
        payload: Prisma.$UserPayload<ExtArgs>
        fields: Prisma.UserFieldRefs
        operations: {
          findUnique: {
            args: Prisma.UserFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.UserFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findFirst: {
            args: Prisma.UserFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.UserFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findMany: {
            args: Prisma.UserFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          create: {
            args: Prisma.UserCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          createMany: {
            args: Prisma.UserCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.UserDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          update: {
            args: Prisma.UserUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          deleteMany: {
            args: Prisma.UserDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.UserUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.UserUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          aggregate: {
            args: Prisma.UserAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUser>
          }
          groupBy: {
            args: Prisma.UserGroupByArgs<ExtArgs>
            result: $Utils.Optional<UserGroupByOutputType>[]
          }
          count: {
            args: Prisma.UserCountArgs<ExtArgs>
            result: $Utils.Optional<UserCountAggregateOutputType> | number
          }
        }
      }
      UserVerificationToken: {
        payload: Prisma.$UserVerificationTokenPayload<ExtArgs>
        fields: Prisma.UserVerificationTokenFieldRefs
        operations: {
          findUnique: {
            args: Prisma.UserVerificationTokenFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserVerificationTokenPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.UserVerificationTokenFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserVerificationTokenPayload>
          }
          findFirst: {
            args: Prisma.UserVerificationTokenFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserVerificationTokenPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.UserVerificationTokenFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserVerificationTokenPayload>
          }
          findMany: {
            args: Prisma.UserVerificationTokenFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserVerificationTokenPayload>[]
          }
          create: {
            args: Prisma.UserVerificationTokenCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserVerificationTokenPayload>
          }
          createMany: {
            args: Prisma.UserVerificationTokenCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.UserVerificationTokenDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserVerificationTokenPayload>
          }
          update: {
            args: Prisma.UserVerificationTokenUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserVerificationTokenPayload>
          }
          deleteMany: {
            args: Prisma.UserVerificationTokenDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.UserVerificationTokenUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.UserVerificationTokenUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserVerificationTokenPayload>
          }
          aggregate: {
            args: Prisma.UserVerificationTokenAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUserVerificationToken>
          }
          groupBy: {
            args: Prisma.UserVerificationTokenGroupByArgs<ExtArgs>
            result: $Utils.Optional<UserVerificationTokenGroupByOutputType>[]
          }
          count: {
            args: Prisma.UserVerificationTokenCountArgs<ExtArgs>
            result: $Utils.Optional<UserVerificationTokenCountAggregateOutputType> | number
          }
        }
      }
      Category: {
        payload: Prisma.$CategoryPayload<ExtArgs>
        fields: Prisma.CategoryFieldRefs
        operations: {
          findUnique: {
            args: Prisma.CategoryFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CategoryPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.CategoryFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CategoryPayload>
          }
          findFirst: {
            args: Prisma.CategoryFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CategoryPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.CategoryFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CategoryPayload>
          }
          findMany: {
            args: Prisma.CategoryFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CategoryPayload>[]
          }
          create: {
            args: Prisma.CategoryCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CategoryPayload>
          }
          createMany: {
            args: Prisma.CategoryCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.CategoryDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CategoryPayload>
          }
          update: {
            args: Prisma.CategoryUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CategoryPayload>
          }
          deleteMany: {
            args: Prisma.CategoryDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.CategoryUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.CategoryUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CategoryPayload>
          }
          aggregate: {
            args: Prisma.CategoryAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateCategory>
          }
          groupBy: {
            args: Prisma.CategoryGroupByArgs<ExtArgs>
            result: $Utils.Optional<CategoryGroupByOutputType>[]
          }
          count: {
            args: Prisma.CategoryCountArgs<ExtArgs>
            result: $Utils.Optional<CategoryCountAggregateOutputType> | number
          }
        }
      }
      Product: {
        payload: Prisma.$ProductPayload<ExtArgs>
        fields: Prisma.ProductFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ProductFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProductPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ProductFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProductPayload>
          }
          findFirst: {
            args: Prisma.ProductFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProductPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ProductFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProductPayload>
          }
          findMany: {
            args: Prisma.ProductFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProductPayload>[]
          }
          create: {
            args: Prisma.ProductCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProductPayload>
          }
          createMany: {
            args: Prisma.ProductCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.ProductDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProductPayload>
          }
          update: {
            args: Prisma.ProductUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProductPayload>
          }
          deleteMany: {
            args: Prisma.ProductDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.ProductUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.ProductUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProductPayload>
          }
          aggregate: {
            args: Prisma.ProductAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateProduct>
          }
          groupBy: {
            args: Prisma.ProductGroupByArgs<ExtArgs>
            result: $Utils.Optional<ProductGroupByOutputType>[]
          }
          count: {
            args: Prisma.ProductCountArgs<ExtArgs>
            result: $Utils.Optional<ProductCountAggregateOutputType> | number
          }
        }
      }
      StockMutation: {
        payload: Prisma.$StockMutationPayload<ExtArgs>
        fields: Prisma.StockMutationFieldRefs
        operations: {
          findUnique: {
            args: Prisma.StockMutationFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$StockMutationPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.StockMutationFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$StockMutationPayload>
          }
          findFirst: {
            args: Prisma.StockMutationFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$StockMutationPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.StockMutationFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$StockMutationPayload>
          }
          findMany: {
            args: Prisma.StockMutationFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$StockMutationPayload>[]
          }
          create: {
            args: Prisma.StockMutationCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$StockMutationPayload>
          }
          createMany: {
            args: Prisma.StockMutationCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.StockMutationDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$StockMutationPayload>
          }
          update: {
            args: Prisma.StockMutationUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$StockMutationPayload>
          }
          deleteMany: {
            args: Prisma.StockMutationDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.StockMutationUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.StockMutationUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$StockMutationPayload>
          }
          aggregate: {
            args: Prisma.StockMutationAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateStockMutation>
          }
          groupBy: {
            args: Prisma.StockMutationGroupByArgs<ExtArgs>
            result: $Utils.Optional<StockMutationGroupByOutputType>[]
          }
          count: {
            args: Prisma.StockMutationCountArgs<ExtArgs>
            result: $Utils.Optional<StockMutationCountAggregateOutputType> | number
          }
        }
      }
      PaymentTerm: {
        payload: Prisma.$PaymentTermPayload<ExtArgs>
        fields: Prisma.PaymentTermFieldRefs
        operations: {
          findUnique: {
            args: Prisma.PaymentTermFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentTermPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.PaymentTermFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentTermPayload>
          }
          findFirst: {
            args: Prisma.PaymentTermFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentTermPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.PaymentTermFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentTermPayload>
          }
          findMany: {
            args: Prisma.PaymentTermFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentTermPayload>[]
          }
          create: {
            args: Prisma.PaymentTermCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentTermPayload>
          }
          createMany: {
            args: Prisma.PaymentTermCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.PaymentTermDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentTermPayload>
          }
          update: {
            args: Prisma.PaymentTermUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentTermPayload>
          }
          deleteMany: {
            args: Prisma.PaymentTermDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.PaymentTermUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.PaymentTermUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentTermPayload>
          }
          aggregate: {
            args: Prisma.PaymentTermAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregatePaymentTerm>
          }
          groupBy: {
            args: Prisma.PaymentTermGroupByArgs<ExtArgs>
            result: $Utils.Optional<PaymentTermGroupByOutputType>[]
          }
          count: {
            args: Prisma.PaymentTermCountArgs<ExtArgs>
            result: $Utils.Optional<PaymentTermCountAggregateOutputType> | number
          }
        }
      }
      PaymentAccount: {
        payload: Prisma.$PaymentAccountPayload<ExtArgs>
        fields: Prisma.PaymentAccountFieldRefs
        operations: {
          findUnique: {
            args: Prisma.PaymentAccountFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentAccountPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.PaymentAccountFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentAccountPayload>
          }
          findFirst: {
            args: Prisma.PaymentAccountFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentAccountPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.PaymentAccountFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentAccountPayload>
          }
          findMany: {
            args: Prisma.PaymentAccountFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentAccountPayload>[]
          }
          create: {
            args: Prisma.PaymentAccountCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentAccountPayload>
          }
          createMany: {
            args: Prisma.PaymentAccountCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.PaymentAccountDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentAccountPayload>
          }
          update: {
            args: Prisma.PaymentAccountUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentAccountPayload>
          }
          deleteMany: {
            args: Prisma.PaymentAccountDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.PaymentAccountUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.PaymentAccountUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentAccountPayload>
          }
          aggregate: {
            args: Prisma.PaymentAccountAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregatePaymentAccount>
          }
          groupBy: {
            args: Prisma.PaymentAccountGroupByArgs<ExtArgs>
            result: $Utils.Optional<PaymentAccountGroupByOutputType>[]
          }
          count: {
            args: Prisma.PaymentAccountCountArgs<ExtArgs>
            result: $Utils.Optional<PaymentAccountCountAggregateOutputType> | number
          }
        }
      }
      Wishlist: {
        payload: Prisma.$WishlistPayload<ExtArgs>
        fields: Prisma.WishlistFieldRefs
        operations: {
          findUnique: {
            args: Prisma.WishlistFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WishlistPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.WishlistFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WishlistPayload>
          }
          findFirst: {
            args: Prisma.WishlistFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WishlistPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.WishlistFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WishlistPayload>
          }
          findMany: {
            args: Prisma.WishlistFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WishlistPayload>[]
          }
          create: {
            args: Prisma.WishlistCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WishlistPayload>
          }
          createMany: {
            args: Prisma.WishlistCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.WishlistDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WishlistPayload>
          }
          update: {
            args: Prisma.WishlistUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WishlistPayload>
          }
          deleteMany: {
            args: Prisma.WishlistDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.WishlistUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.WishlistUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$WishlistPayload>
          }
          aggregate: {
            args: Prisma.WishlistAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateWishlist>
          }
          groupBy: {
            args: Prisma.WishlistGroupByArgs<ExtArgs>
            result: $Utils.Optional<WishlistGroupByOutputType>[]
          }
          count: {
            args: Prisma.WishlistCountArgs<ExtArgs>
            result: $Utils.Optional<WishlistCountAggregateOutputType> | number
          }
        }
      }
      TopUp: {
        payload: Prisma.$TopUpPayload<ExtArgs>
        fields: Prisma.TopUpFieldRefs
        operations: {
          findUnique: {
            args: Prisma.TopUpFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TopUpPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.TopUpFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TopUpPayload>
          }
          findFirst: {
            args: Prisma.TopUpFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TopUpPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.TopUpFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TopUpPayload>
          }
          findMany: {
            args: Prisma.TopUpFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TopUpPayload>[]
          }
          create: {
            args: Prisma.TopUpCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TopUpPayload>
          }
          createMany: {
            args: Prisma.TopUpCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.TopUpDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TopUpPayload>
          }
          update: {
            args: Prisma.TopUpUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TopUpPayload>
          }
          deleteMany: {
            args: Prisma.TopUpDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.TopUpUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.TopUpUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TopUpPayload>
          }
          aggregate: {
            args: Prisma.TopUpAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateTopUp>
          }
          groupBy: {
            args: Prisma.TopUpGroupByArgs<ExtArgs>
            result: $Utils.Optional<TopUpGroupByOutputType>[]
          }
          count: {
            args: Prisma.TopUpCountArgs<ExtArgs>
            result: $Utils.Optional<TopUpCountAggregateOutputType> | number
          }
        }
      }
      Transaction: {
        payload: Prisma.$TransactionPayload<ExtArgs>
        fields: Prisma.TransactionFieldRefs
        operations: {
          findUnique: {
            args: Prisma.TransactionFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TransactionPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.TransactionFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TransactionPayload>
          }
          findFirst: {
            args: Prisma.TransactionFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TransactionPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.TransactionFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TransactionPayload>
          }
          findMany: {
            args: Prisma.TransactionFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TransactionPayload>[]
          }
          create: {
            args: Prisma.TransactionCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TransactionPayload>
          }
          createMany: {
            args: Prisma.TransactionCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.TransactionDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TransactionPayload>
          }
          update: {
            args: Prisma.TransactionUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TransactionPayload>
          }
          deleteMany: {
            args: Prisma.TransactionDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.TransactionUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.TransactionUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TransactionPayload>
          }
          aggregate: {
            args: Prisma.TransactionAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateTransaction>
          }
          groupBy: {
            args: Prisma.TransactionGroupByArgs<ExtArgs>
            result: $Utils.Optional<TransactionGroupByOutputType>[]
          }
          count: {
            args: Prisma.TransactionCountArgs<ExtArgs>
            result: $Utils.Optional<TransactionCountAggregateOutputType> | number
          }
        }
      }
      TransactionDetails: {
        payload: Prisma.$TransactionDetailsPayload<ExtArgs>
        fields: Prisma.TransactionDetailsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.TransactionDetailsFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TransactionDetailsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.TransactionDetailsFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TransactionDetailsPayload>
          }
          findFirst: {
            args: Prisma.TransactionDetailsFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TransactionDetailsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.TransactionDetailsFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TransactionDetailsPayload>
          }
          findMany: {
            args: Prisma.TransactionDetailsFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TransactionDetailsPayload>[]
          }
          create: {
            args: Prisma.TransactionDetailsCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TransactionDetailsPayload>
          }
          createMany: {
            args: Prisma.TransactionDetailsCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.TransactionDetailsDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TransactionDetailsPayload>
          }
          update: {
            args: Prisma.TransactionDetailsUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TransactionDetailsPayload>
          }
          deleteMany: {
            args: Prisma.TransactionDetailsDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.TransactionDetailsUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.TransactionDetailsUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TransactionDetailsPayload>
          }
          aggregate: {
            args: Prisma.TransactionDetailsAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateTransactionDetails>
          }
          groupBy: {
            args: Prisma.TransactionDetailsGroupByArgs<ExtArgs>
            result: $Utils.Optional<TransactionDetailsGroupByOutputType>[]
          }
          count: {
            args: Prisma.TransactionDetailsCountArgs<ExtArgs>
            result: $Utils.Optional<TransactionDetailsCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasources?: Datasources
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasourceUrl?: string
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Defaults to stdout
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events
     * log: [
     *   { emit: 'stdout', level: 'query' },
     *   { emit: 'stdout', level: 'info' },
     *   { emit: 'stdout', level: 'warn' }
     *   { emit: 'stdout', level: 'error' }
     * ]
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
  }
  export type GlobalOmitConfig = {
    admin?: AdminOmit
    user?: UserOmit
    userVerificationToken?: UserVerificationTokenOmit
    category?: CategoryOmit
    product?: ProductOmit
    stockMutation?: StockMutationOmit
    paymentTerm?: PaymentTermOmit
    paymentAccount?: PaymentAccountOmit
    wishlist?: WishlistOmit
    topUp?: TopUpOmit
    transaction?: TransactionOmit
    transactionDetails?: TransactionDetailsOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type GetLogType<T extends LogLevel | LogDefinition> = T extends LogDefinition ? T['emit'] extends 'event' ? T['level'] : never : never
  export type GetEvents<T extends any> = T extends Array<LogLevel | LogDefinition> ?
    GetLogType<T[0]> | GetLogType<T[1]> | GetLogType<T[2]> | GetLogType<T[3]>
    : never

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  /**
   * These options are being passed into the middleware as "params"
   */
  export type MiddlewareParams = {
    model?: ModelName
    action: PrismaAction
    args: any
    dataPath: string[]
    runInTransaction: boolean
  }

  /**
   * The `T` type makes sure, that the `return proceed` is not forgotten in the middleware implementation
   */
  export type Middleware<T = any> = (
    params: MiddlewareParams,
    next: (params: MiddlewareParams) => $Utils.JsPromise<T>,
  ) => $Utils.JsPromise<T>

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type AdminCountOutputType
   */

  export type AdminCountOutputType = {
    topUps: number
  }

  export type AdminCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    topUps?: boolean | AdminCountOutputTypeCountTopUpsArgs
  }

  // Custom InputTypes
  /**
   * AdminCountOutputType without action
   */
  export type AdminCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AdminCountOutputType
     */
    select?: AdminCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * AdminCountOutputType without action
   */
  export type AdminCountOutputTypeCountTopUpsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TopUpWhereInput
  }


  /**
   * Count Type UserCountOutputType
   */

  export type UserCountOutputType = {
    wishlists: number
    topUp: number
    transactions: number
    userVerificationTokens: number
  }

  export type UserCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    wishlists?: boolean | UserCountOutputTypeCountWishlistsArgs
    topUp?: boolean | UserCountOutputTypeCountTopUpArgs
    transactions?: boolean | UserCountOutputTypeCountTransactionsArgs
    userVerificationTokens?: boolean | UserCountOutputTypeCountUserVerificationTokensArgs
  }

  // Custom InputTypes
  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserCountOutputType
     */
    select?: UserCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountWishlistsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: WishlistWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountTopUpArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TopUpWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountTransactionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TransactionWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountUserVerificationTokensArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserVerificationTokenWhereInput
  }


  /**
   * Count Type CategoryCountOutputType
   */

  export type CategoryCountOutputType = {
    products: number
  }

  export type CategoryCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    products?: boolean | CategoryCountOutputTypeCountProductsArgs
  }

  // Custom InputTypes
  /**
   * CategoryCountOutputType without action
   */
  export type CategoryCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CategoryCountOutputType
     */
    select?: CategoryCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * CategoryCountOutputType without action
   */
  export type CategoryCountOutputTypeCountProductsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ProductWhereInput
  }


  /**
   * Count Type ProductCountOutputType
   */

  export type ProductCountOutputType = {
    stockMutations: number
    wishlists: number
    transactionDetails: number
  }

  export type ProductCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    stockMutations?: boolean | ProductCountOutputTypeCountStockMutationsArgs
    wishlists?: boolean | ProductCountOutputTypeCountWishlistsArgs
    transactionDetails?: boolean | ProductCountOutputTypeCountTransactionDetailsArgs
  }

  // Custom InputTypes
  /**
   * ProductCountOutputType without action
   */
  export type ProductCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProductCountOutputType
     */
    select?: ProductCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * ProductCountOutputType without action
   */
  export type ProductCountOutputTypeCountStockMutationsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: StockMutationWhereInput
  }

  /**
   * ProductCountOutputType without action
   */
  export type ProductCountOutputTypeCountWishlistsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: WishlistWhereInput
  }

  /**
   * ProductCountOutputType without action
   */
  export type ProductCountOutputTypeCountTransactionDetailsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TransactionDetailsWhereInput
  }


  /**
   * Count Type PaymentTermCountOutputType
   */

  export type PaymentTermCountOutputType = {
    PaymentAccounts: number
    TopUps: number
  }

  export type PaymentTermCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    PaymentAccounts?: boolean | PaymentTermCountOutputTypeCountPaymentAccountsArgs
    TopUps?: boolean | PaymentTermCountOutputTypeCountTopUpsArgs
  }

  // Custom InputTypes
  /**
   * PaymentTermCountOutputType without action
   */
  export type PaymentTermCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentTermCountOutputType
     */
    select?: PaymentTermCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * PaymentTermCountOutputType without action
   */
  export type PaymentTermCountOutputTypeCountPaymentAccountsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PaymentAccountWhereInput
  }

  /**
   * PaymentTermCountOutputType without action
   */
  export type PaymentTermCountOutputTypeCountTopUpsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TopUpWhereInput
  }


  /**
   * Count Type PaymentAccountCountOutputType
   */

  export type PaymentAccountCountOutputType = {
    TopUps: number
  }

  export type PaymentAccountCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    TopUps?: boolean | PaymentAccountCountOutputTypeCountTopUpsArgs
  }

  // Custom InputTypes
  /**
   * PaymentAccountCountOutputType without action
   */
  export type PaymentAccountCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentAccountCountOutputType
     */
    select?: PaymentAccountCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * PaymentAccountCountOutputType without action
   */
  export type PaymentAccountCountOutputTypeCountTopUpsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TopUpWhereInput
  }


  /**
   * Count Type TransactionCountOutputType
   */

  export type TransactionCountOutputType = {
    transactionDetails: number
  }

  export type TransactionCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    transactionDetails?: boolean | TransactionCountOutputTypeCountTransactionDetailsArgs
  }

  // Custom InputTypes
  /**
   * TransactionCountOutputType without action
   */
  export type TransactionCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TransactionCountOutputType
     */
    select?: TransactionCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * TransactionCountOutputType without action
   */
  export type TransactionCountOutputTypeCountTransactionDetailsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TransactionDetailsWhereInput
  }


  /**
   * Models
   */

  /**
   * Model Admin
   */

  export type AggregateAdmin = {
    _count: AdminCountAggregateOutputType | null
    _min: AdminMinAggregateOutputType | null
    _max: AdminMaxAggregateOutputType | null
  }

  export type AdminMinAggregateOutputType = {
    id: string | null
    name: string | null
    email: string | null
    password: string | null
    role: string | null
    status: string | null
    isPasswordChanged: boolean | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type AdminMaxAggregateOutputType = {
    id: string | null
    name: string | null
    email: string | null
    password: string | null
    role: string | null
    status: string | null
    isPasswordChanged: boolean | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type AdminCountAggregateOutputType = {
    id: number
    name: number
    email: number
    password: number
    role: number
    status: number
    isPasswordChanged: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type AdminMinAggregateInputType = {
    id?: true
    name?: true
    email?: true
    password?: true
    role?: true
    status?: true
    isPasswordChanged?: true
    createdAt?: true
    updatedAt?: true
  }

  export type AdminMaxAggregateInputType = {
    id?: true
    name?: true
    email?: true
    password?: true
    role?: true
    status?: true
    isPasswordChanged?: true
    createdAt?: true
    updatedAt?: true
  }

  export type AdminCountAggregateInputType = {
    id?: true
    name?: true
    email?: true
    password?: true
    role?: true
    status?: true
    isPasswordChanged?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type AdminAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Admin to aggregate.
     */
    where?: AdminWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Admins to fetch.
     */
    orderBy?: AdminOrderByWithRelationInput | AdminOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: AdminWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Admins from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Admins.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Admins
    **/
    _count?: true | AdminCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: AdminMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: AdminMaxAggregateInputType
  }

  export type GetAdminAggregateType<T extends AdminAggregateArgs> = {
        [P in keyof T & keyof AggregateAdmin]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateAdmin[P]>
      : GetScalarType<T[P], AggregateAdmin[P]>
  }




  export type AdminGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: AdminWhereInput
    orderBy?: AdminOrderByWithAggregationInput | AdminOrderByWithAggregationInput[]
    by: AdminScalarFieldEnum[] | AdminScalarFieldEnum
    having?: AdminScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: AdminCountAggregateInputType | true
    _min?: AdminMinAggregateInputType
    _max?: AdminMaxAggregateInputType
  }

  export type AdminGroupByOutputType = {
    id: string
    name: string
    email: string
    password: string
    role: string
    status: string
    isPasswordChanged: boolean
    createdAt: Date
    updatedAt: Date
    _count: AdminCountAggregateOutputType | null
    _min: AdminMinAggregateOutputType | null
    _max: AdminMaxAggregateOutputType | null
  }

  type GetAdminGroupByPayload<T extends AdminGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<AdminGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof AdminGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], AdminGroupByOutputType[P]>
            : GetScalarType<T[P], AdminGroupByOutputType[P]>
        }
      >
    >


  export type AdminSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    email?: boolean
    password?: boolean
    role?: boolean
    status?: boolean
    isPasswordChanged?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    topUps?: boolean | Admin$topUpsArgs<ExtArgs>
    _count?: boolean | AdminCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["admin"]>



  export type AdminSelectScalar = {
    id?: boolean
    name?: boolean
    email?: boolean
    password?: boolean
    role?: boolean
    status?: boolean
    isPasswordChanged?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type AdminOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "email" | "password" | "role" | "status" | "isPasswordChanged" | "createdAt" | "updatedAt", ExtArgs["result"]["admin"]>
  export type AdminInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    topUps?: boolean | Admin$topUpsArgs<ExtArgs>
    _count?: boolean | AdminCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $AdminPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Admin"
    objects: {
      topUps: Prisma.$TopUpPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string
      email: string
      password: string
      role: string
      status: string
      isPasswordChanged: boolean
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["admin"]>
    composites: {}
  }

  type AdminGetPayload<S extends boolean | null | undefined | AdminDefaultArgs> = $Result.GetResult<Prisma.$AdminPayload, S>

  type AdminCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<AdminFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: AdminCountAggregateInputType | true
    }

  export interface AdminDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Admin'], meta: { name: 'Admin' } }
    /**
     * Find zero or one Admin that matches the filter.
     * @param {AdminFindUniqueArgs} args - Arguments to find a Admin
     * @example
     * // Get one Admin
     * const admin = await prisma.admin.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends AdminFindUniqueArgs>(args: SelectSubset<T, AdminFindUniqueArgs<ExtArgs>>): Prisma__AdminClient<$Result.GetResult<Prisma.$AdminPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Admin that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {AdminFindUniqueOrThrowArgs} args - Arguments to find a Admin
     * @example
     * // Get one Admin
     * const admin = await prisma.admin.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends AdminFindUniqueOrThrowArgs>(args: SelectSubset<T, AdminFindUniqueOrThrowArgs<ExtArgs>>): Prisma__AdminClient<$Result.GetResult<Prisma.$AdminPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Admin that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AdminFindFirstArgs} args - Arguments to find a Admin
     * @example
     * // Get one Admin
     * const admin = await prisma.admin.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends AdminFindFirstArgs>(args?: SelectSubset<T, AdminFindFirstArgs<ExtArgs>>): Prisma__AdminClient<$Result.GetResult<Prisma.$AdminPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Admin that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AdminFindFirstOrThrowArgs} args - Arguments to find a Admin
     * @example
     * // Get one Admin
     * const admin = await prisma.admin.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends AdminFindFirstOrThrowArgs>(args?: SelectSubset<T, AdminFindFirstOrThrowArgs<ExtArgs>>): Prisma__AdminClient<$Result.GetResult<Prisma.$AdminPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Admins that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AdminFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Admins
     * const admins = await prisma.admin.findMany()
     * 
     * // Get first 10 Admins
     * const admins = await prisma.admin.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const adminWithIdOnly = await prisma.admin.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends AdminFindManyArgs>(args?: SelectSubset<T, AdminFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AdminPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Admin.
     * @param {AdminCreateArgs} args - Arguments to create a Admin.
     * @example
     * // Create one Admin
     * const Admin = await prisma.admin.create({
     *   data: {
     *     // ... data to create a Admin
     *   }
     * })
     * 
     */
    create<T extends AdminCreateArgs>(args: SelectSubset<T, AdminCreateArgs<ExtArgs>>): Prisma__AdminClient<$Result.GetResult<Prisma.$AdminPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Admins.
     * @param {AdminCreateManyArgs} args - Arguments to create many Admins.
     * @example
     * // Create many Admins
     * const admin = await prisma.admin.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends AdminCreateManyArgs>(args?: SelectSubset<T, AdminCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Admin.
     * @param {AdminDeleteArgs} args - Arguments to delete one Admin.
     * @example
     * // Delete one Admin
     * const Admin = await prisma.admin.delete({
     *   where: {
     *     // ... filter to delete one Admin
     *   }
     * })
     * 
     */
    delete<T extends AdminDeleteArgs>(args: SelectSubset<T, AdminDeleteArgs<ExtArgs>>): Prisma__AdminClient<$Result.GetResult<Prisma.$AdminPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Admin.
     * @param {AdminUpdateArgs} args - Arguments to update one Admin.
     * @example
     * // Update one Admin
     * const admin = await prisma.admin.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends AdminUpdateArgs>(args: SelectSubset<T, AdminUpdateArgs<ExtArgs>>): Prisma__AdminClient<$Result.GetResult<Prisma.$AdminPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Admins.
     * @param {AdminDeleteManyArgs} args - Arguments to filter Admins to delete.
     * @example
     * // Delete a few Admins
     * const { count } = await prisma.admin.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends AdminDeleteManyArgs>(args?: SelectSubset<T, AdminDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Admins.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AdminUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Admins
     * const admin = await prisma.admin.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends AdminUpdateManyArgs>(args: SelectSubset<T, AdminUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Admin.
     * @param {AdminUpsertArgs} args - Arguments to update or create a Admin.
     * @example
     * // Update or create a Admin
     * const admin = await prisma.admin.upsert({
     *   create: {
     *     // ... data to create a Admin
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Admin we want to update
     *   }
     * })
     */
    upsert<T extends AdminUpsertArgs>(args: SelectSubset<T, AdminUpsertArgs<ExtArgs>>): Prisma__AdminClient<$Result.GetResult<Prisma.$AdminPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Admins.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AdminCountArgs} args - Arguments to filter Admins to count.
     * @example
     * // Count the number of Admins
     * const count = await prisma.admin.count({
     *   where: {
     *     // ... the filter for the Admins we want to count
     *   }
     * })
    **/
    count<T extends AdminCountArgs>(
      args?: Subset<T, AdminCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], AdminCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Admin.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AdminAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends AdminAggregateArgs>(args: Subset<T, AdminAggregateArgs>): Prisma.PrismaPromise<GetAdminAggregateType<T>>

    /**
     * Group by Admin.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AdminGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends AdminGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: AdminGroupByArgs['orderBy'] }
        : { orderBy?: AdminGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, AdminGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetAdminGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Admin model
   */
  readonly fields: AdminFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Admin.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__AdminClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    topUps<T extends Admin$topUpsArgs<ExtArgs> = {}>(args?: Subset<T, Admin$topUpsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TopUpPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Admin model
   */
  interface AdminFieldRefs {
    readonly id: FieldRef<"Admin", 'String'>
    readonly name: FieldRef<"Admin", 'String'>
    readonly email: FieldRef<"Admin", 'String'>
    readonly password: FieldRef<"Admin", 'String'>
    readonly role: FieldRef<"Admin", 'String'>
    readonly status: FieldRef<"Admin", 'String'>
    readonly isPasswordChanged: FieldRef<"Admin", 'Boolean'>
    readonly createdAt: FieldRef<"Admin", 'DateTime'>
    readonly updatedAt: FieldRef<"Admin", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Admin findUnique
   */
  export type AdminFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Admin
     */
    select?: AdminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Admin
     */
    omit?: AdminOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AdminInclude<ExtArgs> | null
    /**
     * Filter, which Admin to fetch.
     */
    where: AdminWhereUniqueInput
  }

  /**
   * Admin findUniqueOrThrow
   */
  export type AdminFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Admin
     */
    select?: AdminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Admin
     */
    omit?: AdminOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AdminInclude<ExtArgs> | null
    /**
     * Filter, which Admin to fetch.
     */
    where: AdminWhereUniqueInput
  }

  /**
   * Admin findFirst
   */
  export type AdminFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Admin
     */
    select?: AdminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Admin
     */
    omit?: AdminOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AdminInclude<ExtArgs> | null
    /**
     * Filter, which Admin to fetch.
     */
    where?: AdminWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Admins to fetch.
     */
    orderBy?: AdminOrderByWithRelationInput | AdminOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Admins.
     */
    cursor?: AdminWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Admins from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Admins.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Admins.
     */
    distinct?: AdminScalarFieldEnum | AdminScalarFieldEnum[]
  }

  /**
   * Admin findFirstOrThrow
   */
  export type AdminFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Admin
     */
    select?: AdminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Admin
     */
    omit?: AdminOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AdminInclude<ExtArgs> | null
    /**
     * Filter, which Admin to fetch.
     */
    where?: AdminWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Admins to fetch.
     */
    orderBy?: AdminOrderByWithRelationInput | AdminOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Admins.
     */
    cursor?: AdminWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Admins from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Admins.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Admins.
     */
    distinct?: AdminScalarFieldEnum | AdminScalarFieldEnum[]
  }

  /**
   * Admin findMany
   */
  export type AdminFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Admin
     */
    select?: AdminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Admin
     */
    omit?: AdminOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AdminInclude<ExtArgs> | null
    /**
     * Filter, which Admins to fetch.
     */
    where?: AdminWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Admins to fetch.
     */
    orderBy?: AdminOrderByWithRelationInput | AdminOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Admins.
     */
    cursor?: AdminWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Admins from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Admins.
     */
    skip?: number
    distinct?: AdminScalarFieldEnum | AdminScalarFieldEnum[]
  }

  /**
   * Admin create
   */
  export type AdminCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Admin
     */
    select?: AdminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Admin
     */
    omit?: AdminOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AdminInclude<ExtArgs> | null
    /**
     * The data needed to create a Admin.
     */
    data: XOR<AdminCreateInput, AdminUncheckedCreateInput>
  }

  /**
   * Admin createMany
   */
  export type AdminCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Admins.
     */
    data: AdminCreateManyInput | AdminCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Admin update
   */
  export type AdminUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Admin
     */
    select?: AdminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Admin
     */
    omit?: AdminOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AdminInclude<ExtArgs> | null
    /**
     * The data needed to update a Admin.
     */
    data: XOR<AdminUpdateInput, AdminUncheckedUpdateInput>
    /**
     * Choose, which Admin to update.
     */
    where: AdminWhereUniqueInput
  }

  /**
   * Admin updateMany
   */
  export type AdminUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Admins.
     */
    data: XOR<AdminUpdateManyMutationInput, AdminUncheckedUpdateManyInput>
    /**
     * Filter which Admins to update
     */
    where?: AdminWhereInput
    /**
     * Limit how many Admins to update.
     */
    limit?: number
  }

  /**
   * Admin upsert
   */
  export type AdminUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Admin
     */
    select?: AdminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Admin
     */
    omit?: AdminOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AdminInclude<ExtArgs> | null
    /**
     * The filter to search for the Admin to update in case it exists.
     */
    where: AdminWhereUniqueInput
    /**
     * In case the Admin found by the `where` argument doesn't exist, create a new Admin with this data.
     */
    create: XOR<AdminCreateInput, AdminUncheckedCreateInput>
    /**
     * In case the Admin was found with the provided `where` argument, update it with this data.
     */
    update: XOR<AdminUpdateInput, AdminUncheckedUpdateInput>
  }

  /**
   * Admin delete
   */
  export type AdminDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Admin
     */
    select?: AdminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Admin
     */
    omit?: AdminOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AdminInclude<ExtArgs> | null
    /**
     * Filter which Admin to delete.
     */
    where: AdminWhereUniqueInput
  }

  /**
   * Admin deleteMany
   */
  export type AdminDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Admins to delete
     */
    where?: AdminWhereInput
    /**
     * Limit how many Admins to delete.
     */
    limit?: number
  }

  /**
   * Admin.topUps
   */
  export type Admin$topUpsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TopUp
     */
    select?: TopUpSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TopUp
     */
    omit?: TopUpOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TopUpInclude<ExtArgs> | null
    where?: TopUpWhereInput
    orderBy?: TopUpOrderByWithRelationInput | TopUpOrderByWithRelationInput[]
    cursor?: TopUpWhereUniqueInput
    take?: number
    skip?: number
    distinct?: TopUpScalarFieldEnum | TopUpScalarFieldEnum[]
  }

  /**
   * Admin without action
   */
  export type AdminDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Admin
     */
    select?: AdminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Admin
     */
    omit?: AdminOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AdminInclude<ExtArgs> | null
  }


  /**
   * Model User
   */

  export type AggregateUser = {
    _count: UserCountAggregateOutputType | null
    _avg: UserAvgAggregateOutputType | null
    _sum: UserSumAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  export type UserAvgAggregateOutputType = {
    balance: number | null
  }

  export type UserSumAggregateOutputType = {
    balance: number | null
  }

  export type UserMinAggregateOutputType = {
    id: string | null
    name: string | null
    email: string | null
    password: string | null
    status: string | null
    profile: string | null
    balance: number | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type UserMaxAggregateOutputType = {
    id: string | null
    name: string | null
    email: string | null
    password: string | null
    status: string | null
    profile: string | null
    balance: number | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type UserCountAggregateOutputType = {
    id: number
    name: number
    email: number
    password: number
    status: number
    profile: number
    balance: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type UserAvgAggregateInputType = {
    balance?: true
  }

  export type UserSumAggregateInputType = {
    balance?: true
  }

  export type UserMinAggregateInputType = {
    id?: true
    name?: true
    email?: true
    password?: true
    status?: true
    profile?: true
    balance?: true
    createdAt?: true
    updatedAt?: true
  }

  export type UserMaxAggregateInputType = {
    id?: true
    name?: true
    email?: true
    password?: true
    status?: true
    profile?: true
    balance?: true
    createdAt?: true
    updatedAt?: true
  }

  export type UserCountAggregateInputType = {
    id?: true
    name?: true
    email?: true
    password?: true
    status?: true
    profile?: true
    balance?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type UserAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which User to aggregate.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Users
    **/
    _count?: true | UserCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: UserAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: UserSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UserMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UserMaxAggregateInputType
  }

  export type GetUserAggregateType<T extends UserAggregateArgs> = {
        [P in keyof T & keyof AggregateUser]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUser[P]>
      : GetScalarType<T[P], AggregateUser[P]>
  }




  export type UserGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserWhereInput
    orderBy?: UserOrderByWithAggregationInput | UserOrderByWithAggregationInput[]
    by: UserScalarFieldEnum[] | UserScalarFieldEnum
    having?: UserScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UserCountAggregateInputType | true
    _avg?: UserAvgAggregateInputType
    _sum?: UserSumAggregateInputType
    _min?: UserMinAggregateInputType
    _max?: UserMaxAggregateInputType
  }

  export type UserGroupByOutputType = {
    id: string
    name: string
    email: string
    password: string
    status: string
    profile: string
    balance: number
    createdAt: Date
    updatedAt: Date
    _count: UserCountAggregateOutputType | null
    _avg: UserAvgAggregateOutputType | null
    _sum: UserSumAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  type GetUserGroupByPayload<T extends UserGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UserGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UserGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UserGroupByOutputType[P]>
            : GetScalarType<T[P], UserGroupByOutputType[P]>
        }
      >
    >


  export type UserSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    email?: boolean
    password?: boolean
    status?: boolean
    profile?: boolean
    balance?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    wishlists?: boolean | User$wishlistsArgs<ExtArgs>
    topUp?: boolean | User$topUpArgs<ExtArgs>
    transactions?: boolean | User$transactionsArgs<ExtArgs>
    userVerificationTokens?: boolean | User$userVerificationTokensArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["user"]>



  export type UserSelectScalar = {
    id?: boolean
    name?: boolean
    email?: boolean
    password?: boolean
    status?: boolean
    profile?: boolean
    balance?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type UserOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "email" | "password" | "status" | "profile" | "balance" | "createdAt" | "updatedAt", ExtArgs["result"]["user"]>
  export type UserInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    wishlists?: boolean | User$wishlistsArgs<ExtArgs>
    topUp?: boolean | User$topUpArgs<ExtArgs>
    transactions?: boolean | User$transactionsArgs<ExtArgs>
    userVerificationTokens?: boolean | User$userVerificationTokensArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $UserPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "User"
    objects: {
      wishlists: Prisma.$WishlistPayload<ExtArgs>[]
      topUp: Prisma.$TopUpPayload<ExtArgs>[]
      transactions: Prisma.$TransactionPayload<ExtArgs>[]
      userVerificationTokens: Prisma.$UserVerificationTokenPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string
      email: string
      password: string
      status: string
      profile: string
      balance: number
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["user"]>
    composites: {}
  }

  type UserGetPayload<S extends boolean | null | undefined | UserDefaultArgs> = $Result.GetResult<Prisma.$UserPayload, S>

  type UserCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<UserFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: UserCountAggregateInputType | true
    }

  export interface UserDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['User'], meta: { name: 'User' } }
    /**
     * Find zero or one User that matches the filter.
     * @param {UserFindUniqueArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends UserFindUniqueArgs>(args: SelectSubset<T, UserFindUniqueArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one User that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {UserFindUniqueOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends UserFindUniqueOrThrowArgs>(args: SelectSubset<T, UserFindUniqueOrThrowArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends UserFindFirstArgs>(args?: SelectSubset<T, UserFindFirstArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends UserFindFirstOrThrowArgs>(args?: SelectSubset<T, UserFindFirstOrThrowArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Users that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Users
     * const users = await prisma.user.findMany()
     * 
     * // Get first 10 Users
     * const users = await prisma.user.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const userWithIdOnly = await prisma.user.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends UserFindManyArgs>(args?: SelectSubset<T, UserFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a User.
     * @param {UserCreateArgs} args - Arguments to create a User.
     * @example
     * // Create one User
     * const User = await prisma.user.create({
     *   data: {
     *     // ... data to create a User
     *   }
     * })
     * 
     */
    create<T extends UserCreateArgs>(args: SelectSubset<T, UserCreateArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Users.
     * @param {UserCreateManyArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const user = await prisma.user.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends UserCreateManyArgs>(args?: SelectSubset<T, UserCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a User.
     * @param {UserDeleteArgs} args - Arguments to delete one User.
     * @example
     * // Delete one User
     * const User = await prisma.user.delete({
     *   where: {
     *     // ... filter to delete one User
     *   }
     * })
     * 
     */
    delete<T extends UserDeleteArgs>(args: SelectSubset<T, UserDeleteArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one User.
     * @param {UserUpdateArgs} args - Arguments to update one User.
     * @example
     * // Update one User
     * const user = await prisma.user.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends UserUpdateArgs>(args: SelectSubset<T, UserUpdateArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Users.
     * @param {UserDeleteManyArgs} args - Arguments to filter Users to delete.
     * @example
     * // Delete a few Users
     * const { count } = await prisma.user.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends UserDeleteManyArgs>(args?: SelectSubset<T, UserDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Users
     * const user = await prisma.user.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends UserUpdateManyArgs>(args: SelectSubset<T, UserUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one User.
     * @param {UserUpsertArgs} args - Arguments to update or create a User.
     * @example
     * // Update or create a User
     * const user = await prisma.user.upsert({
     *   create: {
     *     // ... data to create a User
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the User we want to update
     *   }
     * })
     */
    upsert<T extends UserUpsertArgs>(args: SelectSubset<T, UserUpsertArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserCountArgs} args - Arguments to filter Users to count.
     * @example
     * // Count the number of Users
     * const count = await prisma.user.count({
     *   where: {
     *     // ... the filter for the Users we want to count
     *   }
     * })
    **/
    count<T extends UserCountArgs>(
      args?: Subset<T, UserCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UserCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UserAggregateArgs>(args: Subset<T, UserAggregateArgs>): Prisma.PrismaPromise<GetUserAggregateType<T>>

    /**
     * Group by User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends UserGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: UserGroupByArgs['orderBy'] }
        : { orderBy?: UserGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, UserGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUserGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the User model
   */
  readonly fields: UserFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for User.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__UserClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    wishlists<T extends User$wishlistsArgs<ExtArgs> = {}>(args?: Subset<T, User$wishlistsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WishlistPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    topUp<T extends User$topUpArgs<ExtArgs> = {}>(args?: Subset<T, User$topUpArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TopUpPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    transactions<T extends User$transactionsArgs<ExtArgs> = {}>(args?: Subset<T, User$transactionsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TransactionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    userVerificationTokens<T extends User$userVerificationTokensArgs<ExtArgs> = {}>(args?: Subset<T, User$userVerificationTokensArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserVerificationTokenPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the User model
   */
  interface UserFieldRefs {
    readonly id: FieldRef<"User", 'String'>
    readonly name: FieldRef<"User", 'String'>
    readonly email: FieldRef<"User", 'String'>
    readonly password: FieldRef<"User", 'String'>
    readonly status: FieldRef<"User", 'String'>
    readonly profile: FieldRef<"User", 'String'>
    readonly balance: FieldRef<"User", 'Int'>
    readonly createdAt: FieldRef<"User", 'DateTime'>
    readonly updatedAt: FieldRef<"User", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * User findUnique
   */
  export type UserFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User findUniqueOrThrow
   */
  export type UserFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User findFirst
   */
  export type UserFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User findFirstOrThrow
   */
  export type UserFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User findMany
   */
  export type UserFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which Users to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User create
   */
  export type UserCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to create a User.
     */
    data: XOR<UserCreateInput, UserUncheckedCreateInput>
  }

  /**
   * User createMany
   */
  export type UserCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Users.
     */
    data: UserCreateManyInput | UserCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * User update
   */
  export type UserUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to update a User.
     */
    data: XOR<UserUpdateInput, UserUncheckedUpdateInput>
    /**
     * Choose, which User to update.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User updateMany
   */
  export type UserUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Users.
     */
    data: XOR<UserUpdateManyMutationInput, UserUncheckedUpdateManyInput>
    /**
     * Filter which Users to update
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to update.
     */
    limit?: number
  }

  /**
   * User upsert
   */
  export type UserUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The filter to search for the User to update in case it exists.
     */
    where: UserWhereUniqueInput
    /**
     * In case the User found by the `where` argument doesn't exist, create a new User with this data.
     */
    create: XOR<UserCreateInput, UserUncheckedCreateInput>
    /**
     * In case the User was found with the provided `where` argument, update it with this data.
     */
    update: XOR<UserUpdateInput, UserUncheckedUpdateInput>
  }

  /**
   * User delete
   */
  export type UserDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter which User to delete.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User deleteMany
   */
  export type UserDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Users to delete
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to delete.
     */
    limit?: number
  }

  /**
   * User.wishlists
   */
  export type User$wishlistsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Wishlist
     */
    select?: WishlistSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Wishlist
     */
    omit?: WishlistOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WishlistInclude<ExtArgs> | null
    where?: WishlistWhereInput
    orderBy?: WishlistOrderByWithRelationInput | WishlistOrderByWithRelationInput[]
    cursor?: WishlistWhereUniqueInput
    take?: number
    skip?: number
    distinct?: WishlistScalarFieldEnum | WishlistScalarFieldEnum[]
  }

  /**
   * User.topUp
   */
  export type User$topUpArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TopUp
     */
    select?: TopUpSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TopUp
     */
    omit?: TopUpOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TopUpInclude<ExtArgs> | null
    where?: TopUpWhereInput
    orderBy?: TopUpOrderByWithRelationInput | TopUpOrderByWithRelationInput[]
    cursor?: TopUpWhereUniqueInput
    take?: number
    skip?: number
    distinct?: TopUpScalarFieldEnum | TopUpScalarFieldEnum[]
  }

  /**
   * User.transactions
   */
  export type User$transactionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Transaction
     */
    select?: TransactionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Transaction
     */
    omit?: TransactionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionInclude<ExtArgs> | null
    where?: TransactionWhereInput
    orderBy?: TransactionOrderByWithRelationInput | TransactionOrderByWithRelationInput[]
    cursor?: TransactionWhereUniqueInput
    take?: number
    skip?: number
    distinct?: TransactionScalarFieldEnum | TransactionScalarFieldEnum[]
  }

  /**
   * User.userVerificationTokens
   */
  export type User$userVerificationTokensArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserVerificationToken
     */
    select?: UserVerificationTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserVerificationToken
     */
    omit?: UserVerificationTokenOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserVerificationTokenInclude<ExtArgs> | null
    where?: UserVerificationTokenWhereInput
    orderBy?: UserVerificationTokenOrderByWithRelationInput | UserVerificationTokenOrderByWithRelationInput[]
    cursor?: UserVerificationTokenWhereUniqueInput
    take?: number
    skip?: number
    distinct?: UserVerificationTokenScalarFieldEnum | UserVerificationTokenScalarFieldEnum[]
  }

  /**
   * User without action
   */
  export type UserDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
  }


  /**
   * Model UserVerificationToken
   */

  export type AggregateUserVerificationToken = {
    _count: UserVerificationTokenCountAggregateOutputType | null
    _min: UserVerificationTokenMinAggregateOutputType | null
    _max: UserVerificationTokenMaxAggregateOutputType | null
  }

  export type UserVerificationTokenMinAggregateOutputType = {
    id: string | null
    token: string | null
    userId: string | null
    purpose: string | null
    createdAt: Date | null
    updatedAt: Date | null
    expiredAt: Date | null
  }

  export type UserVerificationTokenMaxAggregateOutputType = {
    id: string | null
    token: string | null
    userId: string | null
    purpose: string | null
    createdAt: Date | null
    updatedAt: Date | null
    expiredAt: Date | null
  }

  export type UserVerificationTokenCountAggregateOutputType = {
    id: number
    token: number
    userId: number
    purpose: number
    createdAt: number
    updatedAt: number
    expiredAt: number
    _all: number
  }


  export type UserVerificationTokenMinAggregateInputType = {
    id?: true
    token?: true
    userId?: true
    purpose?: true
    createdAt?: true
    updatedAt?: true
    expiredAt?: true
  }

  export type UserVerificationTokenMaxAggregateInputType = {
    id?: true
    token?: true
    userId?: true
    purpose?: true
    createdAt?: true
    updatedAt?: true
    expiredAt?: true
  }

  export type UserVerificationTokenCountAggregateInputType = {
    id?: true
    token?: true
    userId?: true
    purpose?: true
    createdAt?: true
    updatedAt?: true
    expiredAt?: true
    _all?: true
  }

  export type UserVerificationTokenAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which UserVerificationToken to aggregate.
     */
    where?: UserVerificationTokenWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UserVerificationTokens to fetch.
     */
    orderBy?: UserVerificationTokenOrderByWithRelationInput | UserVerificationTokenOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: UserVerificationTokenWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UserVerificationTokens from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UserVerificationTokens.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned UserVerificationTokens
    **/
    _count?: true | UserVerificationTokenCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UserVerificationTokenMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UserVerificationTokenMaxAggregateInputType
  }

  export type GetUserVerificationTokenAggregateType<T extends UserVerificationTokenAggregateArgs> = {
        [P in keyof T & keyof AggregateUserVerificationToken]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUserVerificationToken[P]>
      : GetScalarType<T[P], AggregateUserVerificationToken[P]>
  }




  export type UserVerificationTokenGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserVerificationTokenWhereInput
    orderBy?: UserVerificationTokenOrderByWithAggregationInput | UserVerificationTokenOrderByWithAggregationInput[]
    by: UserVerificationTokenScalarFieldEnum[] | UserVerificationTokenScalarFieldEnum
    having?: UserVerificationTokenScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UserVerificationTokenCountAggregateInputType | true
    _min?: UserVerificationTokenMinAggregateInputType
    _max?: UserVerificationTokenMaxAggregateInputType
  }

  export type UserVerificationTokenGroupByOutputType = {
    id: string
    token: string
    userId: string
    purpose: string
    createdAt: Date
    updatedAt: Date
    expiredAt: Date | null
    _count: UserVerificationTokenCountAggregateOutputType | null
    _min: UserVerificationTokenMinAggregateOutputType | null
    _max: UserVerificationTokenMaxAggregateOutputType | null
  }

  type GetUserVerificationTokenGroupByPayload<T extends UserVerificationTokenGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UserVerificationTokenGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UserVerificationTokenGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UserVerificationTokenGroupByOutputType[P]>
            : GetScalarType<T[P], UserVerificationTokenGroupByOutputType[P]>
        }
      >
    >


  export type UserVerificationTokenSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    token?: boolean
    userId?: boolean
    purpose?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    expiredAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["userVerificationToken"]>



  export type UserVerificationTokenSelectScalar = {
    id?: boolean
    token?: boolean
    userId?: boolean
    purpose?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    expiredAt?: boolean
  }

  export type UserVerificationTokenOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "token" | "userId" | "purpose" | "createdAt" | "updatedAt" | "expiredAt", ExtArgs["result"]["userVerificationToken"]>
  export type UserVerificationTokenInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }

  export type $UserVerificationTokenPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "UserVerificationToken"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      token: string
      userId: string
      purpose: string
      createdAt: Date
      updatedAt: Date
      expiredAt: Date | null
    }, ExtArgs["result"]["userVerificationToken"]>
    composites: {}
  }

  type UserVerificationTokenGetPayload<S extends boolean | null | undefined | UserVerificationTokenDefaultArgs> = $Result.GetResult<Prisma.$UserVerificationTokenPayload, S>

  type UserVerificationTokenCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<UserVerificationTokenFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: UserVerificationTokenCountAggregateInputType | true
    }

  export interface UserVerificationTokenDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['UserVerificationToken'], meta: { name: 'UserVerificationToken' } }
    /**
     * Find zero or one UserVerificationToken that matches the filter.
     * @param {UserVerificationTokenFindUniqueArgs} args - Arguments to find a UserVerificationToken
     * @example
     * // Get one UserVerificationToken
     * const userVerificationToken = await prisma.userVerificationToken.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends UserVerificationTokenFindUniqueArgs>(args: SelectSubset<T, UserVerificationTokenFindUniqueArgs<ExtArgs>>): Prisma__UserVerificationTokenClient<$Result.GetResult<Prisma.$UserVerificationTokenPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one UserVerificationToken that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {UserVerificationTokenFindUniqueOrThrowArgs} args - Arguments to find a UserVerificationToken
     * @example
     * // Get one UserVerificationToken
     * const userVerificationToken = await prisma.userVerificationToken.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends UserVerificationTokenFindUniqueOrThrowArgs>(args: SelectSubset<T, UserVerificationTokenFindUniqueOrThrowArgs<ExtArgs>>): Prisma__UserVerificationTokenClient<$Result.GetResult<Prisma.$UserVerificationTokenPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first UserVerificationToken that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserVerificationTokenFindFirstArgs} args - Arguments to find a UserVerificationToken
     * @example
     * // Get one UserVerificationToken
     * const userVerificationToken = await prisma.userVerificationToken.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends UserVerificationTokenFindFirstArgs>(args?: SelectSubset<T, UserVerificationTokenFindFirstArgs<ExtArgs>>): Prisma__UserVerificationTokenClient<$Result.GetResult<Prisma.$UserVerificationTokenPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first UserVerificationToken that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserVerificationTokenFindFirstOrThrowArgs} args - Arguments to find a UserVerificationToken
     * @example
     * // Get one UserVerificationToken
     * const userVerificationToken = await prisma.userVerificationToken.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends UserVerificationTokenFindFirstOrThrowArgs>(args?: SelectSubset<T, UserVerificationTokenFindFirstOrThrowArgs<ExtArgs>>): Prisma__UserVerificationTokenClient<$Result.GetResult<Prisma.$UserVerificationTokenPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more UserVerificationTokens that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserVerificationTokenFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all UserVerificationTokens
     * const userVerificationTokens = await prisma.userVerificationToken.findMany()
     * 
     * // Get first 10 UserVerificationTokens
     * const userVerificationTokens = await prisma.userVerificationToken.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const userVerificationTokenWithIdOnly = await prisma.userVerificationToken.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends UserVerificationTokenFindManyArgs>(args?: SelectSubset<T, UserVerificationTokenFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserVerificationTokenPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a UserVerificationToken.
     * @param {UserVerificationTokenCreateArgs} args - Arguments to create a UserVerificationToken.
     * @example
     * // Create one UserVerificationToken
     * const UserVerificationToken = await prisma.userVerificationToken.create({
     *   data: {
     *     // ... data to create a UserVerificationToken
     *   }
     * })
     * 
     */
    create<T extends UserVerificationTokenCreateArgs>(args: SelectSubset<T, UserVerificationTokenCreateArgs<ExtArgs>>): Prisma__UserVerificationTokenClient<$Result.GetResult<Prisma.$UserVerificationTokenPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many UserVerificationTokens.
     * @param {UserVerificationTokenCreateManyArgs} args - Arguments to create many UserVerificationTokens.
     * @example
     * // Create many UserVerificationTokens
     * const userVerificationToken = await prisma.userVerificationToken.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends UserVerificationTokenCreateManyArgs>(args?: SelectSubset<T, UserVerificationTokenCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a UserVerificationToken.
     * @param {UserVerificationTokenDeleteArgs} args - Arguments to delete one UserVerificationToken.
     * @example
     * // Delete one UserVerificationToken
     * const UserVerificationToken = await prisma.userVerificationToken.delete({
     *   where: {
     *     // ... filter to delete one UserVerificationToken
     *   }
     * })
     * 
     */
    delete<T extends UserVerificationTokenDeleteArgs>(args: SelectSubset<T, UserVerificationTokenDeleteArgs<ExtArgs>>): Prisma__UserVerificationTokenClient<$Result.GetResult<Prisma.$UserVerificationTokenPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one UserVerificationToken.
     * @param {UserVerificationTokenUpdateArgs} args - Arguments to update one UserVerificationToken.
     * @example
     * // Update one UserVerificationToken
     * const userVerificationToken = await prisma.userVerificationToken.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends UserVerificationTokenUpdateArgs>(args: SelectSubset<T, UserVerificationTokenUpdateArgs<ExtArgs>>): Prisma__UserVerificationTokenClient<$Result.GetResult<Prisma.$UserVerificationTokenPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more UserVerificationTokens.
     * @param {UserVerificationTokenDeleteManyArgs} args - Arguments to filter UserVerificationTokens to delete.
     * @example
     * // Delete a few UserVerificationTokens
     * const { count } = await prisma.userVerificationToken.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends UserVerificationTokenDeleteManyArgs>(args?: SelectSubset<T, UserVerificationTokenDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more UserVerificationTokens.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserVerificationTokenUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many UserVerificationTokens
     * const userVerificationToken = await prisma.userVerificationToken.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends UserVerificationTokenUpdateManyArgs>(args: SelectSubset<T, UserVerificationTokenUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one UserVerificationToken.
     * @param {UserVerificationTokenUpsertArgs} args - Arguments to update or create a UserVerificationToken.
     * @example
     * // Update or create a UserVerificationToken
     * const userVerificationToken = await prisma.userVerificationToken.upsert({
     *   create: {
     *     // ... data to create a UserVerificationToken
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the UserVerificationToken we want to update
     *   }
     * })
     */
    upsert<T extends UserVerificationTokenUpsertArgs>(args: SelectSubset<T, UserVerificationTokenUpsertArgs<ExtArgs>>): Prisma__UserVerificationTokenClient<$Result.GetResult<Prisma.$UserVerificationTokenPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of UserVerificationTokens.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserVerificationTokenCountArgs} args - Arguments to filter UserVerificationTokens to count.
     * @example
     * // Count the number of UserVerificationTokens
     * const count = await prisma.userVerificationToken.count({
     *   where: {
     *     // ... the filter for the UserVerificationTokens we want to count
     *   }
     * })
    **/
    count<T extends UserVerificationTokenCountArgs>(
      args?: Subset<T, UserVerificationTokenCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UserVerificationTokenCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a UserVerificationToken.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserVerificationTokenAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UserVerificationTokenAggregateArgs>(args: Subset<T, UserVerificationTokenAggregateArgs>): Prisma.PrismaPromise<GetUserVerificationTokenAggregateType<T>>

    /**
     * Group by UserVerificationToken.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserVerificationTokenGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends UserVerificationTokenGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: UserVerificationTokenGroupByArgs['orderBy'] }
        : { orderBy?: UserVerificationTokenGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, UserVerificationTokenGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUserVerificationTokenGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the UserVerificationToken model
   */
  readonly fields: UserVerificationTokenFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for UserVerificationToken.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__UserVerificationTokenClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the UserVerificationToken model
   */
  interface UserVerificationTokenFieldRefs {
    readonly id: FieldRef<"UserVerificationToken", 'String'>
    readonly token: FieldRef<"UserVerificationToken", 'String'>
    readonly userId: FieldRef<"UserVerificationToken", 'String'>
    readonly purpose: FieldRef<"UserVerificationToken", 'String'>
    readonly createdAt: FieldRef<"UserVerificationToken", 'DateTime'>
    readonly updatedAt: FieldRef<"UserVerificationToken", 'DateTime'>
    readonly expiredAt: FieldRef<"UserVerificationToken", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * UserVerificationToken findUnique
   */
  export type UserVerificationTokenFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserVerificationToken
     */
    select?: UserVerificationTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserVerificationToken
     */
    omit?: UserVerificationTokenOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserVerificationTokenInclude<ExtArgs> | null
    /**
     * Filter, which UserVerificationToken to fetch.
     */
    where: UserVerificationTokenWhereUniqueInput
  }

  /**
   * UserVerificationToken findUniqueOrThrow
   */
  export type UserVerificationTokenFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserVerificationToken
     */
    select?: UserVerificationTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserVerificationToken
     */
    omit?: UserVerificationTokenOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserVerificationTokenInclude<ExtArgs> | null
    /**
     * Filter, which UserVerificationToken to fetch.
     */
    where: UserVerificationTokenWhereUniqueInput
  }

  /**
   * UserVerificationToken findFirst
   */
  export type UserVerificationTokenFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserVerificationToken
     */
    select?: UserVerificationTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserVerificationToken
     */
    omit?: UserVerificationTokenOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserVerificationTokenInclude<ExtArgs> | null
    /**
     * Filter, which UserVerificationToken to fetch.
     */
    where?: UserVerificationTokenWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UserVerificationTokens to fetch.
     */
    orderBy?: UserVerificationTokenOrderByWithRelationInput | UserVerificationTokenOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for UserVerificationTokens.
     */
    cursor?: UserVerificationTokenWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UserVerificationTokens from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UserVerificationTokens.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of UserVerificationTokens.
     */
    distinct?: UserVerificationTokenScalarFieldEnum | UserVerificationTokenScalarFieldEnum[]
  }

  /**
   * UserVerificationToken findFirstOrThrow
   */
  export type UserVerificationTokenFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserVerificationToken
     */
    select?: UserVerificationTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserVerificationToken
     */
    omit?: UserVerificationTokenOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserVerificationTokenInclude<ExtArgs> | null
    /**
     * Filter, which UserVerificationToken to fetch.
     */
    where?: UserVerificationTokenWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UserVerificationTokens to fetch.
     */
    orderBy?: UserVerificationTokenOrderByWithRelationInput | UserVerificationTokenOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for UserVerificationTokens.
     */
    cursor?: UserVerificationTokenWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UserVerificationTokens from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UserVerificationTokens.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of UserVerificationTokens.
     */
    distinct?: UserVerificationTokenScalarFieldEnum | UserVerificationTokenScalarFieldEnum[]
  }

  /**
   * UserVerificationToken findMany
   */
  export type UserVerificationTokenFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserVerificationToken
     */
    select?: UserVerificationTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserVerificationToken
     */
    omit?: UserVerificationTokenOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserVerificationTokenInclude<ExtArgs> | null
    /**
     * Filter, which UserVerificationTokens to fetch.
     */
    where?: UserVerificationTokenWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UserVerificationTokens to fetch.
     */
    orderBy?: UserVerificationTokenOrderByWithRelationInput | UserVerificationTokenOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing UserVerificationTokens.
     */
    cursor?: UserVerificationTokenWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UserVerificationTokens from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UserVerificationTokens.
     */
    skip?: number
    distinct?: UserVerificationTokenScalarFieldEnum | UserVerificationTokenScalarFieldEnum[]
  }

  /**
   * UserVerificationToken create
   */
  export type UserVerificationTokenCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserVerificationToken
     */
    select?: UserVerificationTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserVerificationToken
     */
    omit?: UserVerificationTokenOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserVerificationTokenInclude<ExtArgs> | null
    /**
     * The data needed to create a UserVerificationToken.
     */
    data: XOR<UserVerificationTokenCreateInput, UserVerificationTokenUncheckedCreateInput>
  }

  /**
   * UserVerificationToken createMany
   */
  export type UserVerificationTokenCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many UserVerificationTokens.
     */
    data: UserVerificationTokenCreateManyInput | UserVerificationTokenCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * UserVerificationToken update
   */
  export type UserVerificationTokenUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserVerificationToken
     */
    select?: UserVerificationTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserVerificationToken
     */
    omit?: UserVerificationTokenOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserVerificationTokenInclude<ExtArgs> | null
    /**
     * The data needed to update a UserVerificationToken.
     */
    data: XOR<UserVerificationTokenUpdateInput, UserVerificationTokenUncheckedUpdateInput>
    /**
     * Choose, which UserVerificationToken to update.
     */
    where: UserVerificationTokenWhereUniqueInput
  }

  /**
   * UserVerificationToken updateMany
   */
  export type UserVerificationTokenUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update UserVerificationTokens.
     */
    data: XOR<UserVerificationTokenUpdateManyMutationInput, UserVerificationTokenUncheckedUpdateManyInput>
    /**
     * Filter which UserVerificationTokens to update
     */
    where?: UserVerificationTokenWhereInput
    /**
     * Limit how many UserVerificationTokens to update.
     */
    limit?: number
  }

  /**
   * UserVerificationToken upsert
   */
  export type UserVerificationTokenUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserVerificationToken
     */
    select?: UserVerificationTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserVerificationToken
     */
    omit?: UserVerificationTokenOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserVerificationTokenInclude<ExtArgs> | null
    /**
     * The filter to search for the UserVerificationToken to update in case it exists.
     */
    where: UserVerificationTokenWhereUniqueInput
    /**
     * In case the UserVerificationToken found by the `where` argument doesn't exist, create a new UserVerificationToken with this data.
     */
    create: XOR<UserVerificationTokenCreateInput, UserVerificationTokenUncheckedCreateInput>
    /**
     * In case the UserVerificationToken was found with the provided `where` argument, update it with this data.
     */
    update: XOR<UserVerificationTokenUpdateInput, UserVerificationTokenUncheckedUpdateInput>
  }

  /**
   * UserVerificationToken delete
   */
  export type UserVerificationTokenDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserVerificationToken
     */
    select?: UserVerificationTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserVerificationToken
     */
    omit?: UserVerificationTokenOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserVerificationTokenInclude<ExtArgs> | null
    /**
     * Filter which UserVerificationToken to delete.
     */
    where: UserVerificationTokenWhereUniqueInput
  }

  /**
   * UserVerificationToken deleteMany
   */
  export type UserVerificationTokenDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which UserVerificationTokens to delete
     */
    where?: UserVerificationTokenWhereInput
    /**
     * Limit how many UserVerificationTokens to delete.
     */
    limit?: number
  }

  /**
   * UserVerificationToken without action
   */
  export type UserVerificationTokenDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserVerificationToken
     */
    select?: UserVerificationTokenSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserVerificationToken
     */
    omit?: UserVerificationTokenOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserVerificationTokenInclude<ExtArgs> | null
  }


  /**
   * Model Category
   */

  export type AggregateCategory = {
    _count: CategoryCountAggregateOutputType | null
    _min: CategoryMinAggregateOutputType | null
    _max: CategoryMaxAggregateOutputType | null
  }

  export type CategoryMinAggregateOutputType = {
    id: string | null
    name: string | null
    status: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type CategoryMaxAggregateOutputType = {
    id: string | null
    name: string | null
    status: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type CategoryCountAggregateOutputType = {
    id: number
    name: number
    status: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type CategoryMinAggregateInputType = {
    id?: true
    name?: true
    status?: true
    createdAt?: true
    updatedAt?: true
  }

  export type CategoryMaxAggregateInputType = {
    id?: true
    name?: true
    status?: true
    createdAt?: true
    updatedAt?: true
  }

  export type CategoryCountAggregateInputType = {
    id?: true
    name?: true
    status?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type CategoryAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Category to aggregate.
     */
    where?: CategoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Categories to fetch.
     */
    orderBy?: CategoryOrderByWithRelationInput | CategoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: CategoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Categories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Categories.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Categories
    **/
    _count?: true | CategoryCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: CategoryMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: CategoryMaxAggregateInputType
  }

  export type GetCategoryAggregateType<T extends CategoryAggregateArgs> = {
        [P in keyof T & keyof AggregateCategory]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateCategory[P]>
      : GetScalarType<T[P], AggregateCategory[P]>
  }




  export type CategoryGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: CategoryWhereInput
    orderBy?: CategoryOrderByWithAggregationInput | CategoryOrderByWithAggregationInput[]
    by: CategoryScalarFieldEnum[] | CategoryScalarFieldEnum
    having?: CategoryScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: CategoryCountAggregateInputType | true
    _min?: CategoryMinAggregateInputType
    _max?: CategoryMaxAggregateInputType
  }

  export type CategoryGroupByOutputType = {
    id: string
    name: string
    status: string
    createdAt: Date
    updatedAt: Date
    _count: CategoryCountAggregateOutputType | null
    _min: CategoryMinAggregateOutputType | null
    _max: CategoryMaxAggregateOutputType | null
  }

  type GetCategoryGroupByPayload<T extends CategoryGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<CategoryGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof CategoryGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], CategoryGroupByOutputType[P]>
            : GetScalarType<T[P], CategoryGroupByOutputType[P]>
        }
      >
    >


  export type CategorySelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    status?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    products?: boolean | Category$productsArgs<ExtArgs>
    _count?: boolean | CategoryCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["category"]>



  export type CategorySelectScalar = {
    id?: boolean
    name?: boolean
    status?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type CategoryOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "status" | "createdAt" | "updatedAt", ExtArgs["result"]["category"]>
  export type CategoryInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    products?: boolean | Category$productsArgs<ExtArgs>
    _count?: boolean | CategoryCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $CategoryPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Category"
    objects: {
      products: Prisma.$ProductPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string
      status: string
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["category"]>
    composites: {}
  }

  type CategoryGetPayload<S extends boolean | null | undefined | CategoryDefaultArgs> = $Result.GetResult<Prisma.$CategoryPayload, S>

  type CategoryCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<CategoryFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: CategoryCountAggregateInputType | true
    }

  export interface CategoryDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Category'], meta: { name: 'Category' } }
    /**
     * Find zero or one Category that matches the filter.
     * @param {CategoryFindUniqueArgs} args - Arguments to find a Category
     * @example
     * // Get one Category
     * const category = await prisma.category.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends CategoryFindUniqueArgs>(args: SelectSubset<T, CategoryFindUniqueArgs<ExtArgs>>): Prisma__CategoryClient<$Result.GetResult<Prisma.$CategoryPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Category that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {CategoryFindUniqueOrThrowArgs} args - Arguments to find a Category
     * @example
     * // Get one Category
     * const category = await prisma.category.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends CategoryFindUniqueOrThrowArgs>(args: SelectSubset<T, CategoryFindUniqueOrThrowArgs<ExtArgs>>): Prisma__CategoryClient<$Result.GetResult<Prisma.$CategoryPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Category that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CategoryFindFirstArgs} args - Arguments to find a Category
     * @example
     * // Get one Category
     * const category = await prisma.category.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends CategoryFindFirstArgs>(args?: SelectSubset<T, CategoryFindFirstArgs<ExtArgs>>): Prisma__CategoryClient<$Result.GetResult<Prisma.$CategoryPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Category that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CategoryFindFirstOrThrowArgs} args - Arguments to find a Category
     * @example
     * // Get one Category
     * const category = await prisma.category.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends CategoryFindFirstOrThrowArgs>(args?: SelectSubset<T, CategoryFindFirstOrThrowArgs<ExtArgs>>): Prisma__CategoryClient<$Result.GetResult<Prisma.$CategoryPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Categories that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CategoryFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Categories
     * const categories = await prisma.category.findMany()
     * 
     * // Get first 10 Categories
     * const categories = await prisma.category.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const categoryWithIdOnly = await prisma.category.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends CategoryFindManyArgs>(args?: SelectSubset<T, CategoryFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CategoryPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Category.
     * @param {CategoryCreateArgs} args - Arguments to create a Category.
     * @example
     * // Create one Category
     * const Category = await prisma.category.create({
     *   data: {
     *     // ... data to create a Category
     *   }
     * })
     * 
     */
    create<T extends CategoryCreateArgs>(args: SelectSubset<T, CategoryCreateArgs<ExtArgs>>): Prisma__CategoryClient<$Result.GetResult<Prisma.$CategoryPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Categories.
     * @param {CategoryCreateManyArgs} args - Arguments to create many Categories.
     * @example
     * // Create many Categories
     * const category = await prisma.category.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends CategoryCreateManyArgs>(args?: SelectSubset<T, CategoryCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Category.
     * @param {CategoryDeleteArgs} args - Arguments to delete one Category.
     * @example
     * // Delete one Category
     * const Category = await prisma.category.delete({
     *   where: {
     *     // ... filter to delete one Category
     *   }
     * })
     * 
     */
    delete<T extends CategoryDeleteArgs>(args: SelectSubset<T, CategoryDeleteArgs<ExtArgs>>): Prisma__CategoryClient<$Result.GetResult<Prisma.$CategoryPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Category.
     * @param {CategoryUpdateArgs} args - Arguments to update one Category.
     * @example
     * // Update one Category
     * const category = await prisma.category.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends CategoryUpdateArgs>(args: SelectSubset<T, CategoryUpdateArgs<ExtArgs>>): Prisma__CategoryClient<$Result.GetResult<Prisma.$CategoryPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Categories.
     * @param {CategoryDeleteManyArgs} args - Arguments to filter Categories to delete.
     * @example
     * // Delete a few Categories
     * const { count } = await prisma.category.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends CategoryDeleteManyArgs>(args?: SelectSubset<T, CategoryDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Categories.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CategoryUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Categories
     * const category = await prisma.category.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends CategoryUpdateManyArgs>(args: SelectSubset<T, CategoryUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Category.
     * @param {CategoryUpsertArgs} args - Arguments to update or create a Category.
     * @example
     * // Update or create a Category
     * const category = await prisma.category.upsert({
     *   create: {
     *     // ... data to create a Category
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Category we want to update
     *   }
     * })
     */
    upsert<T extends CategoryUpsertArgs>(args: SelectSubset<T, CategoryUpsertArgs<ExtArgs>>): Prisma__CategoryClient<$Result.GetResult<Prisma.$CategoryPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Categories.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CategoryCountArgs} args - Arguments to filter Categories to count.
     * @example
     * // Count the number of Categories
     * const count = await prisma.category.count({
     *   where: {
     *     // ... the filter for the Categories we want to count
     *   }
     * })
    **/
    count<T extends CategoryCountArgs>(
      args?: Subset<T, CategoryCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], CategoryCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Category.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CategoryAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends CategoryAggregateArgs>(args: Subset<T, CategoryAggregateArgs>): Prisma.PrismaPromise<GetCategoryAggregateType<T>>

    /**
     * Group by Category.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CategoryGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends CategoryGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: CategoryGroupByArgs['orderBy'] }
        : { orderBy?: CategoryGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, CategoryGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetCategoryGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Category model
   */
  readonly fields: CategoryFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Category.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__CategoryClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    products<T extends Category$productsArgs<ExtArgs> = {}>(args?: Subset<T, Category$productsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ProductPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Category model
   */
  interface CategoryFieldRefs {
    readonly id: FieldRef<"Category", 'String'>
    readonly name: FieldRef<"Category", 'String'>
    readonly status: FieldRef<"Category", 'String'>
    readonly createdAt: FieldRef<"Category", 'DateTime'>
    readonly updatedAt: FieldRef<"Category", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Category findUnique
   */
  export type CategoryFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Category
     */
    select?: CategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Category
     */
    omit?: CategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CategoryInclude<ExtArgs> | null
    /**
     * Filter, which Category to fetch.
     */
    where: CategoryWhereUniqueInput
  }

  /**
   * Category findUniqueOrThrow
   */
  export type CategoryFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Category
     */
    select?: CategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Category
     */
    omit?: CategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CategoryInclude<ExtArgs> | null
    /**
     * Filter, which Category to fetch.
     */
    where: CategoryWhereUniqueInput
  }

  /**
   * Category findFirst
   */
  export type CategoryFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Category
     */
    select?: CategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Category
     */
    omit?: CategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CategoryInclude<ExtArgs> | null
    /**
     * Filter, which Category to fetch.
     */
    where?: CategoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Categories to fetch.
     */
    orderBy?: CategoryOrderByWithRelationInput | CategoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Categories.
     */
    cursor?: CategoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Categories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Categories.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Categories.
     */
    distinct?: CategoryScalarFieldEnum | CategoryScalarFieldEnum[]
  }

  /**
   * Category findFirstOrThrow
   */
  export type CategoryFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Category
     */
    select?: CategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Category
     */
    omit?: CategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CategoryInclude<ExtArgs> | null
    /**
     * Filter, which Category to fetch.
     */
    where?: CategoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Categories to fetch.
     */
    orderBy?: CategoryOrderByWithRelationInput | CategoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Categories.
     */
    cursor?: CategoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Categories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Categories.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Categories.
     */
    distinct?: CategoryScalarFieldEnum | CategoryScalarFieldEnum[]
  }

  /**
   * Category findMany
   */
  export type CategoryFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Category
     */
    select?: CategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Category
     */
    omit?: CategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CategoryInclude<ExtArgs> | null
    /**
     * Filter, which Categories to fetch.
     */
    where?: CategoryWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Categories to fetch.
     */
    orderBy?: CategoryOrderByWithRelationInput | CategoryOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Categories.
     */
    cursor?: CategoryWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Categories from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Categories.
     */
    skip?: number
    distinct?: CategoryScalarFieldEnum | CategoryScalarFieldEnum[]
  }

  /**
   * Category create
   */
  export type CategoryCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Category
     */
    select?: CategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Category
     */
    omit?: CategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CategoryInclude<ExtArgs> | null
    /**
     * The data needed to create a Category.
     */
    data: XOR<CategoryCreateInput, CategoryUncheckedCreateInput>
  }

  /**
   * Category createMany
   */
  export type CategoryCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Categories.
     */
    data: CategoryCreateManyInput | CategoryCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Category update
   */
  export type CategoryUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Category
     */
    select?: CategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Category
     */
    omit?: CategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CategoryInclude<ExtArgs> | null
    /**
     * The data needed to update a Category.
     */
    data: XOR<CategoryUpdateInput, CategoryUncheckedUpdateInput>
    /**
     * Choose, which Category to update.
     */
    where: CategoryWhereUniqueInput
  }

  /**
   * Category updateMany
   */
  export type CategoryUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Categories.
     */
    data: XOR<CategoryUpdateManyMutationInput, CategoryUncheckedUpdateManyInput>
    /**
     * Filter which Categories to update
     */
    where?: CategoryWhereInput
    /**
     * Limit how many Categories to update.
     */
    limit?: number
  }

  /**
   * Category upsert
   */
  export type CategoryUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Category
     */
    select?: CategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Category
     */
    omit?: CategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CategoryInclude<ExtArgs> | null
    /**
     * The filter to search for the Category to update in case it exists.
     */
    where: CategoryWhereUniqueInput
    /**
     * In case the Category found by the `where` argument doesn't exist, create a new Category with this data.
     */
    create: XOR<CategoryCreateInput, CategoryUncheckedCreateInput>
    /**
     * In case the Category was found with the provided `where` argument, update it with this data.
     */
    update: XOR<CategoryUpdateInput, CategoryUncheckedUpdateInput>
  }

  /**
   * Category delete
   */
  export type CategoryDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Category
     */
    select?: CategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Category
     */
    omit?: CategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CategoryInclude<ExtArgs> | null
    /**
     * Filter which Category to delete.
     */
    where: CategoryWhereUniqueInput
  }

  /**
   * Category deleteMany
   */
  export type CategoryDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Categories to delete
     */
    where?: CategoryWhereInput
    /**
     * Limit how many Categories to delete.
     */
    limit?: number
  }

  /**
   * Category.products
   */
  export type Category$productsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Product
     */
    select?: ProductSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Product
     */
    omit?: ProductOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProductInclude<ExtArgs> | null
    where?: ProductWhereInput
    orderBy?: ProductOrderByWithRelationInput | ProductOrderByWithRelationInput[]
    cursor?: ProductWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ProductScalarFieldEnum | ProductScalarFieldEnum[]
  }

  /**
   * Category without action
   */
  export type CategoryDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Category
     */
    select?: CategorySelect<ExtArgs> | null
    /**
     * Omit specific fields from the Category
     */
    omit?: CategoryOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CategoryInclude<ExtArgs> | null
  }


  /**
   * Model Product
   */

  export type AggregateProduct = {
    _count: ProductCountAggregateOutputType | null
    _avg: ProductAvgAggregateOutputType | null
    _sum: ProductSumAggregateOutputType | null
    _min: ProductMinAggregateOutputType | null
    _max: ProductMaxAggregateOutputType | null
  }

  export type ProductAvgAggregateOutputType = {
    price: number | null
    stock: number | null
  }

  export type ProductSumAggregateOutputType = {
    price: number | null
    stock: number | null
  }

  export type ProductMinAggregateOutputType = {
    id: string | null
    categoryId: string | null
    name: string | null
    status: string | null
    price: number | null
    stock: number | null
    description: string | null
    imageFileName: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type ProductMaxAggregateOutputType = {
    id: string | null
    categoryId: string | null
    name: string | null
    status: string | null
    price: number | null
    stock: number | null
    description: string | null
    imageFileName: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type ProductCountAggregateOutputType = {
    id: number
    categoryId: number
    name: number
    status: number
    price: number
    stock: number
    description: number
    imageFileName: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type ProductAvgAggregateInputType = {
    price?: true
    stock?: true
  }

  export type ProductSumAggregateInputType = {
    price?: true
    stock?: true
  }

  export type ProductMinAggregateInputType = {
    id?: true
    categoryId?: true
    name?: true
    status?: true
    price?: true
    stock?: true
    description?: true
    imageFileName?: true
    createdAt?: true
    updatedAt?: true
  }

  export type ProductMaxAggregateInputType = {
    id?: true
    categoryId?: true
    name?: true
    status?: true
    price?: true
    stock?: true
    description?: true
    imageFileName?: true
    createdAt?: true
    updatedAt?: true
  }

  export type ProductCountAggregateInputType = {
    id?: true
    categoryId?: true
    name?: true
    status?: true
    price?: true
    stock?: true
    description?: true
    imageFileName?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type ProductAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Product to aggregate.
     */
    where?: ProductWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Products to fetch.
     */
    orderBy?: ProductOrderByWithRelationInput | ProductOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ProductWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Products from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Products.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Products
    **/
    _count?: true | ProductCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: ProductAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: ProductSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ProductMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ProductMaxAggregateInputType
  }

  export type GetProductAggregateType<T extends ProductAggregateArgs> = {
        [P in keyof T & keyof AggregateProduct]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateProduct[P]>
      : GetScalarType<T[P], AggregateProduct[P]>
  }




  export type ProductGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ProductWhereInput
    orderBy?: ProductOrderByWithAggregationInput | ProductOrderByWithAggregationInput[]
    by: ProductScalarFieldEnum[] | ProductScalarFieldEnum
    having?: ProductScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ProductCountAggregateInputType | true
    _avg?: ProductAvgAggregateInputType
    _sum?: ProductSumAggregateInputType
    _min?: ProductMinAggregateInputType
    _max?: ProductMaxAggregateInputType
  }

  export type ProductGroupByOutputType = {
    id: string
    categoryId: string
    name: string
    status: string
    price: number
    stock: number
    description: string
    imageFileName: string | null
    createdAt: Date
    updatedAt: Date
    _count: ProductCountAggregateOutputType | null
    _avg: ProductAvgAggregateOutputType | null
    _sum: ProductSumAggregateOutputType | null
    _min: ProductMinAggregateOutputType | null
    _max: ProductMaxAggregateOutputType | null
  }

  type GetProductGroupByPayload<T extends ProductGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ProductGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ProductGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ProductGroupByOutputType[P]>
            : GetScalarType<T[P], ProductGroupByOutputType[P]>
        }
      >
    >


  export type ProductSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    categoryId?: boolean
    name?: boolean
    status?: boolean
    price?: boolean
    stock?: boolean
    description?: boolean
    imageFileName?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    category?: boolean | CategoryDefaultArgs<ExtArgs>
    stockMutations?: boolean | Product$stockMutationsArgs<ExtArgs>
    wishlists?: boolean | Product$wishlistsArgs<ExtArgs>
    transactionDetails?: boolean | Product$transactionDetailsArgs<ExtArgs>
    _count?: boolean | ProductCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["product"]>



  export type ProductSelectScalar = {
    id?: boolean
    categoryId?: boolean
    name?: boolean
    status?: boolean
    price?: boolean
    stock?: boolean
    description?: boolean
    imageFileName?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type ProductOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "categoryId" | "name" | "status" | "price" | "stock" | "description" | "imageFileName" | "createdAt" | "updatedAt", ExtArgs["result"]["product"]>
  export type ProductInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    category?: boolean | CategoryDefaultArgs<ExtArgs>
    stockMutations?: boolean | Product$stockMutationsArgs<ExtArgs>
    wishlists?: boolean | Product$wishlistsArgs<ExtArgs>
    transactionDetails?: boolean | Product$transactionDetailsArgs<ExtArgs>
    _count?: boolean | ProductCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $ProductPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Product"
    objects: {
      category: Prisma.$CategoryPayload<ExtArgs>
      stockMutations: Prisma.$StockMutationPayload<ExtArgs>[]
      wishlists: Prisma.$WishlistPayload<ExtArgs>[]
      transactionDetails: Prisma.$TransactionDetailsPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      categoryId: string
      name: string
      status: string
      price: number
      stock: number
      description: string
      imageFileName: string | null
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["product"]>
    composites: {}
  }

  type ProductGetPayload<S extends boolean | null | undefined | ProductDefaultArgs> = $Result.GetResult<Prisma.$ProductPayload, S>

  type ProductCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<ProductFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: ProductCountAggregateInputType | true
    }

  export interface ProductDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Product'], meta: { name: 'Product' } }
    /**
     * Find zero or one Product that matches the filter.
     * @param {ProductFindUniqueArgs} args - Arguments to find a Product
     * @example
     * // Get one Product
     * const product = await prisma.product.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends ProductFindUniqueArgs>(args: SelectSubset<T, ProductFindUniqueArgs<ExtArgs>>): Prisma__ProductClient<$Result.GetResult<Prisma.$ProductPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Product that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {ProductFindUniqueOrThrowArgs} args - Arguments to find a Product
     * @example
     * // Get one Product
     * const product = await prisma.product.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends ProductFindUniqueOrThrowArgs>(args: SelectSubset<T, ProductFindUniqueOrThrowArgs<ExtArgs>>): Prisma__ProductClient<$Result.GetResult<Prisma.$ProductPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Product that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProductFindFirstArgs} args - Arguments to find a Product
     * @example
     * // Get one Product
     * const product = await prisma.product.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends ProductFindFirstArgs>(args?: SelectSubset<T, ProductFindFirstArgs<ExtArgs>>): Prisma__ProductClient<$Result.GetResult<Prisma.$ProductPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Product that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProductFindFirstOrThrowArgs} args - Arguments to find a Product
     * @example
     * // Get one Product
     * const product = await prisma.product.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends ProductFindFirstOrThrowArgs>(args?: SelectSubset<T, ProductFindFirstOrThrowArgs<ExtArgs>>): Prisma__ProductClient<$Result.GetResult<Prisma.$ProductPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Products that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProductFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Products
     * const products = await prisma.product.findMany()
     * 
     * // Get first 10 Products
     * const products = await prisma.product.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const productWithIdOnly = await prisma.product.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends ProductFindManyArgs>(args?: SelectSubset<T, ProductFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ProductPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Product.
     * @param {ProductCreateArgs} args - Arguments to create a Product.
     * @example
     * // Create one Product
     * const Product = await prisma.product.create({
     *   data: {
     *     // ... data to create a Product
     *   }
     * })
     * 
     */
    create<T extends ProductCreateArgs>(args: SelectSubset<T, ProductCreateArgs<ExtArgs>>): Prisma__ProductClient<$Result.GetResult<Prisma.$ProductPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Products.
     * @param {ProductCreateManyArgs} args - Arguments to create many Products.
     * @example
     * // Create many Products
     * const product = await prisma.product.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends ProductCreateManyArgs>(args?: SelectSubset<T, ProductCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Product.
     * @param {ProductDeleteArgs} args - Arguments to delete one Product.
     * @example
     * // Delete one Product
     * const Product = await prisma.product.delete({
     *   where: {
     *     // ... filter to delete one Product
     *   }
     * })
     * 
     */
    delete<T extends ProductDeleteArgs>(args: SelectSubset<T, ProductDeleteArgs<ExtArgs>>): Prisma__ProductClient<$Result.GetResult<Prisma.$ProductPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Product.
     * @param {ProductUpdateArgs} args - Arguments to update one Product.
     * @example
     * // Update one Product
     * const product = await prisma.product.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends ProductUpdateArgs>(args: SelectSubset<T, ProductUpdateArgs<ExtArgs>>): Prisma__ProductClient<$Result.GetResult<Prisma.$ProductPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Products.
     * @param {ProductDeleteManyArgs} args - Arguments to filter Products to delete.
     * @example
     * // Delete a few Products
     * const { count } = await prisma.product.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends ProductDeleteManyArgs>(args?: SelectSubset<T, ProductDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Products.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProductUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Products
     * const product = await prisma.product.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends ProductUpdateManyArgs>(args: SelectSubset<T, ProductUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Product.
     * @param {ProductUpsertArgs} args - Arguments to update or create a Product.
     * @example
     * // Update or create a Product
     * const product = await prisma.product.upsert({
     *   create: {
     *     // ... data to create a Product
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Product we want to update
     *   }
     * })
     */
    upsert<T extends ProductUpsertArgs>(args: SelectSubset<T, ProductUpsertArgs<ExtArgs>>): Prisma__ProductClient<$Result.GetResult<Prisma.$ProductPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Products.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProductCountArgs} args - Arguments to filter Products to count.
     * @example
     * // Count the number of Products
     * const count = await prisma.product.count({
     *   where: {
     *     // ... the filter for the Products we want to count
     *   }
     * })
    **/
    count<T extends ProductCountArgs>(
      args?: Subset<T, ProductCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ProductCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Product.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProductAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ProductAggregateArgs>(args: Subset<T, ProductAggregateArgs>): Prisma.PrismaPromise<GetProductAggregateType<T>>

    /**
     * Group by Product.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProductGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ProductGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ProductGroupByArgs['orderBy'] }
        : { orderBy?: ProductGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ProductGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetProductGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Product model
   */
  readonly fields: ProductFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Product.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ProductClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    category<T extends CategoryDefaultArgs<ExtArgs> = {}>(args?: Subset<T, CategoryDefaultArgs<ExtArgs>>): Prisma__CategoryClient<$Result.GetResult<Prisma.$CategoryPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    stockMutations<T extends Product$stockMutationsArgs<ExtArgs> = {}>(args?: Subset<T, Product$stockMutationsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$StockMutationPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    wishlists<T extends Product$wishlistsArgs<ExtArgs> = {}>(args?: Subset<T, Product$wishlistsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WishlistPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    transactionDetails<T extends Product$transactionDetailsArgs<ExtArgs> = {}>(args?: Subset<T, Product$transactionDetailsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TransactionDetailsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Product model
   */
  interface ProductFieldRefs {
    readonly id: FieldRef<"Product", 'String'>
    readonly categoryId: FieldRef<"Product", 'String'>
    readonly name: FieldRef<"Product", 'String'>
    readonly status: FieldRef<"Product", 'String'>
    readonly price: FieldRef<"Product", 'Int'>
    readonly stock: FieldRef<"Product", 'Int'>
    readonly description: FieldRef<"Product", 'String'>
    readonly imageFileName: FieldRef<"Product", 'String'>
    readonly createdAt: FieldRef<"Product", 'DateTime'>
    readonly updatedAt: FieldRef<"Product", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Product findUnique
   */
  export type ProductFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Product
     */
    select?: ProductSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Product
     */
    omit?: ProductOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProductInclude<ExtArgs> | null
    /**
     * Filter, which Product to fetch.
     */
    where: ProductWhereUniqueInput
  }

  /**
   * Product findUniqueOrThrow
   */
  export type ProductFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Product
     */
    select?: ProductSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Product
     */
    omit?: ProductOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProductInclude<ExtArgs> | null
    /**
     * Filter, which Product to fetch.
     */
    where: ProductWhereUniqueInput
  }

  /**
   * Product findFirst
   */
  export type ProductFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Product
     */
    select?: ProductSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Product
     */
    omit?: ProductOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProductInclude<ExtArgs> | null
    /**
     * Filter, which Product to fetch.
     */
    where?: ProductWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Products to fetch.
     */
    orderBy?: ProductOrderByWithRelationInput | ProductOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Products.
     */
    cursor?: ProductWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Products from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Products.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Products.
     */
    distinct?: ProductScalarFieldEnum | ProductScalarFieldEnum[]
  }

  /**
   * Product findFirstOrThrow
   */
  export type ProductFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Product
     */
    select?: ProductSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Product
     */
    omit?: ProductOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProductInclude<ExtArgs> | null
    /**
     * Filter, which Product to fetch.
     */
    where?: ProductWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Products to fetch.
     */
    orderBy?: ProductOrderByWithRelationInput | ProductOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Products.
     */
    cursor?: ProductWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Products from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Products.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Products.
     */
    distinct?: ProductScalarFieldEnum | ProductScalarFieldEnum[]
  }

  /**
   * Product findMany
   */
  export type ProductFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Product
     */
    select?: ProductSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Product
     */
    omit?: ProductOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProductInclude<ExtArgs> | null
    /**
     * Filter, which Products to fetch.
     */
    where?: ProductWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Products to fetch.
     */
    orderBy?: ProductOrderByWithRelationInput | ProductOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Products.
     */
    cursor?: ProductWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Products from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Products.
     */
    skip?: number
    distinct?: ProductScalarFieldEnum | ProductScalarFieldEnum[]
  }

  /**
   * Product create
   */
  export type ProductCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Product
     */
    select?: ProductSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Product
     */
    omit?: ProductOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProductInclude<ExtArgs> | null
    /**
     * The data needed to create a Product.
     */
    data: XOR<ProductCreateInput, ProductUncheckedCreateInput>
  }

  /**
   * Product createMany
   */
  export type ProductCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Products.
     */
    data: ProductCreateManyInput | ProductCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Product update
   */
  export type ProductUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Product
     */
    select?: ProductSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Product
     */
    omit?: ProductOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProductInclude<ExtArgs> | null
    /**
     * The data needed to update a Product.
     */
    data: XOR<ProductUpdateInput, ProductUncheckedUpdateInput>
    /**
     * Choose, which Product to update.
     */
    where: ProductWhereUniqueInput
  }

  /**
   * Product updateMany
   */
  export type ProductUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Products.
     */
    data: XOR<ProductUpdateManyMutationInput, ProductUncheckedUpdateManyInput>
    /**
     * Filter which Products to update
     */
    where?: ProductWhereInput
    /**
     * Limit how many Products to update.
     */
    limit?: number
  }

  /**
   * Product upsert
   */
  export type ProductUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Product
     */
    select?: ProductSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Product
     */
    omit?: ProductOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProductInclude<ExtArgs> | null
    /**
     * The filter to search for the Product to update in case it exists.
     */
    where: ProductWhereUniqueInput
    /**
     * In case the Product found by the `where` argument doesn't exist, create a new Product with this data.
     */
    create: XOR<ProductCreateInput, ProductUncheckedCreateInput>
    /**
     * In case the Product was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ProductUpdateInput, ProductUncheckedUpdateInput>
  }

  /**
   * Product delete
   */
  export type ProductDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Product
     */
    select?: ProductSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Product
     */
    omit?: ProductOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProductInclude<ExtArgs> | null
    /**
     * Filter which Product to delete.
     */
    where: ProductWhereUniqueInput
  }

  /**
   * Product deleteMany
   */
  export type ProductDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Products to delete
     */
    where?: ProductWhereInput
    /**
     * Limit how many Products to delete.
     */
    limit?: number
  }

  /**
   * Product.stockMutations
   */
  export type Product$stockMutationsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the StockMutation
     */
    select?: StockMutationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the StockMutation
     */
    omit?: StockMutationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: StockMutationInclude<ExtArgs> | null
    where?: StockMutationWhereInput
    orderBy?: StockMutationOrderByWithRelationInput | StockMutationOrderByWithRelationInput[]
    cursor?: StockMutationWhereUniqueInput
    take?: number
    skip?: number
    distinct?: StockMutationScalarFieldEnum | StockMutationScalarFieldEnum[]
  }

  /**
   * Product.wishlists
   */
  export type Product$wishlistsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Wishlist
     */
    select?: WishlistSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Wishlist
     */
    omit?: WishlistOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WishlistInclude<ExtArgs> | null
    where?: WishlistWhereInput
    orderBy?: WishlistOrderByWithRelationInput | WishlistOrderByWithRelationInput[]
    cursor?: WishlistWhereUniqueInput
    take?: number
    skip?: number
    distinct?: WishlistScalarFieldEnum | WishlistScalarFieldEnum[]
  }

  /**
   * Product.transactionDetails
   */
  export type Product$transactionDetailsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TransactionDetails
     */
    select?: TransactionDetailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TransactionDetails
     */
    omit?: TransactionDetailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionDetailsInclude<ExtArgs> | null
    where?: TransactionDetailsWhereInput
    orderBy?: TransactionDetailsOrderByWithRelationInput | TransactionDetailsOrderByWithRelationInput[]
    cursor?: TransactionDetailsWhereUniqueInput
    take?: number
    skip?: number
    distinct?: TransactionDetailsScalarFieldEnum | TransactionDetailsScalarFieldEnum[]
  }

  /**
   * Product without action
   */
  export type ProductDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Product
     */
    select?: ProductSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Product
     */
    omit?: ProductOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProductInclude<ExtArgs> | null
  }


  /**
   * Model StockMutation
   */

  export type AggregateStockMutation = {
    _count: StockMutationCountAggregateOutputType | null
    _avg: StockMutationAvgAggregateOutputType | null
    _sum: StockMutationSumAggregateOutputType | null
    _min: StockMutationMinAggregateOutputType | null
    _max: StockMutationMaxAggregateOutputType | null
  }

  export type StockMutationAvgAggregateOutputType = {
    currentStock: number | null
    quantity: number | null
  }

  export type StockMutationSumAggregateOutputType = {
    currentStock: number | null
    quantity: number | null
  }

  export type StockMutationMinAggregateOutputType = {
    id: string | null
    productId: string | null
    currentStock: number | null
    quantity: number | null
    type: string | null
    notes: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type StockMutationMaxAggregateOutputType = {
    id: string | null
    productId: string | null
    currentStock: number | null
    quantity: number | null
    type: string | null
    notes: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type StockMutationCountAggregateOutputType = {
    id: number
    productId: number
    currentStock: number
    quantity: number
    type: number
    notes: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type StockMutationAvgAggregateInputType = {
    currentStock?: true
    quantity?: true
  }

  export type StockMutationSumAggregateInputType = {
    currentStock?: true
    quantity?: true
  }

  export type StockMutationMinAggregateInputType = {
    id?: true
    productId?: true
    currentStock?: true
    quantity?: true
    type?: true
    notes?: true
    createdAt?: true
    updatedAt?: true
  }

  export type StockMutationMaxAggregateInputType = {
    id?: true
    productId?: true
    currentStock?: true
    quantity?: true
    type?: true
    notes?: true
    createdAt?: true
    updatedAt?: true
  }

  export type StockMutationCountAggregateInputType = {
    id?: true
    productId?: true
    currentStock?: true
    quantity?: true
    type?: true
    notes?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type StockMutationAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which StockMutation to aggregate.
     */
    where?: StockMutationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of StockMutations to fetch.
     */
    orderBy?: StockMutationOrderByWithRelationInput | StockMutationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: StockMutationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` StockMutations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` StockMutations.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned StockMutations
    **/
    _count?: true | StockMutationCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: StockMutationAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: StockMutationSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: StockMutationMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: StockMutationMaxAggregateInputType
  }

  export type GetStockMutationAggregateType<T extends StockMutationAggregateArgs> = {
        [P in keyof T & keyof AggregateStockMutation]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateStockMutation[P]>
      : GetScalarType<T[P], AggregateStockMutation[P]>
  }




  export type StockMutationGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: StockMutationWhereInput
    orderBy?: StockMutationOrderByWithAggregationInput | StockMutationOrderByWithAggregationInput[]
    by: StockMutationScalarFieldEnum[] | StockMutationScalarFieldEnum
    having?: StockMutationScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: StockMutationCountAggregateInputType | true
    _avg?: StockMutationAvgAggregateInputType
    _sum?: StockMutationSumAggregateInputType
    _min?: StockMutationMinAggregateInputType
    _max?: StockMutationMaxAggregateInputType
  }

  export type StockMutationGroupByOutputType = {
    id: string
    productId: string
    currentStock: number
    quantity: number
    type: string
    notes: string | null
    createdAt: Date
    updatedAt: Date
    _count: StockMutationCountAggregateOutputType | null
    _avg: StockMutationAvgAggregateOutputType | null
    _sum: StockMutationSumAggregateOutputType | null
    _min: StockMutationMinAggregateOutputType | null
    _max: StockMutationMaxAggregateOutputType | null
  }

  type GetStockMutationGroupByPayload<T extends StockMutationGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<StockMutationGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof StockMutationGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], StockMutationGroupByOutputType[P]>
            : GetScalarType<T[P], StockMutationGroupByOutputType[P]>
        }
      >
    >


  export type StockMutationSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    productId?: boolean
    currentStock?: boolean
    quantity?: boolean
    type?: boolean
    notes?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    product?: boolean | ProductDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["stockMutation"]>



  export type StockMutationSelectScalar = {
    id?: boolean
    productId?: boolean
    currentStock?: boolean
    quantity?: boolean
    type?: boolean
    notes?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type StockMutationOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "productId" | "currentStock" | "quantity" | "type" | "notes" | "createdAt" | "updatedAt", ExtArgs["result"]["stockMutation"]>
  export type StockMutationInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    product?: boolean | ProductDefaultArgs<ExtArgs>
  }

  export type $StockMutationPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "StockMutation"
    objects: {
      product: Prisma.$ProductPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      productId: string
      currentStock: number
      quantity: number
      type: string
      notes: string | null
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["stockMutation"]>
    composites: {}
  }

  type StockMutationGetPayload<S extends boolean | null | undefined | StockMutationDefaultArgs> = $Result.GetResult<Prisma.$StockMutationPayload, S>

  type StockMutationCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<StockMutationFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: StockMutationCountAggregateInputType | true
    }

  export interface StockMutationDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['StockMutation'], meta: { name: 'StockMutation' } }
    /**
     * Find zero or one StockMutation that matches the filter.
     * @param {StockMutationFindUniqueArgs} args - Arguments to find a StockMutation
     * @example
     * // Get one StockMutation
     * const stockMutation = await prisma.stockMutation.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends StockMutationFindUniqueArgs>(args: SelectSubset<T, StockMutationFindUniqueArgs<ExtArgs>>): Prisma__StockMutationClient<$Result.GetResult<Prisma.$StockMutationPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one StockMutation that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {StockMutationFindUniqueOrThrowArgs} args - Arguments to find a StockMutation
     * @example
     * // Get one StockMutation
     * const stockMutation = await prisma.stockMutation.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends StockMutationFindUniqueOrThrowArgs>(args: SelectSubset<T, StockMutationFindUniqueOrThrowArgs<ExtArgs>>): Prisma__StockMutationClient<$Result.GetResult<Prisma.$StockMutationPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first StockMutation that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {StockMutationFindFirstArgs} args - Arguments to find a StockMutation
     * @example
     * // Get one StockMutation
     * const stockMutation = await prisma.stockMutation.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends StockMutationFindFirstArgs>(args?: SelectSubset<T, StockMutationFindFirstArgs<ExtArgs>>): Prisma__StockMutationClient<$Result.GetResult<Prisma.$StockMutationPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first StockMutation that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {StockMutationFindFirstOrThrowArgs} args - Arguments to find a StockMutation
     * @example
     * // Get one StockMutation
     * const stockMutation = await prisma.stockMutation.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends StockMutationFindFirstOrThrowArgs>(args?: SelectSubset<T, StockMutationFindFirstOrThrowArgs<ExtArgs>>): Prisma__StockMutationClient<$Result.GetResult<Prisma.$StockMutationPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more StockMutations that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {StockMutationFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all StockMutations
     * const stockMutations = await prisma.stockMutation.findMany()
     * 
     * // Get first 10 StockMutations
     * const stockMutations = await prisma.stockMutation.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const stockMutationWithIdOnly = await prisma.stockMutation.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends StockMutationFindManyArgs>(args?: SelectSubset<T, StockMutationFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$StockMutationPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a StockMutation.
     * @param {StockMutationCreateArgs} args - Arguments to create a StockMutation.
     * @example
     * // Create one StockMutation
     * const StockMutation = await prisma.stockMutation.create({
     *   data: {
     *     // ... data to create a StockMutation
     *   }
     * })
     * 
     */
    create<T extends StockMutationCreateArgs>(args: SelectSubset<T, StockMutationCreateArgs<ExtArgs>>): Prisma__StockMutationClient<$Result.GetResult<Prisma.$StockMutationPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many StockMutations.
     * @param {StockMutationCreateManyArgs} args - Arguments to create many StockMutations.
     * @example
     * // Create many StockMutations
     * const stockMutation = await prisma.stockMutation.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends StockMutationCreateManyArgs>(args?: SelectSubset<T, StockMutationCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a StockMutation.
     * @param {StockMutationDeleteArgs} args - Arguments to delete one StockMutation.
     * @example
     * // Delete one StockMutation
     * const StockMutation = await prisma.stockMutation.delete({
     *   where: {
     *     // ... filter to delete one StockMutation
     *   }
     * })
     * 
     */
    delete<T extends StockMutationDeleteArgs>(args: SelectSubset<T, StockMutationDeleteArgs<ExtArgs>>): Prisma__StockMutationClient<$Result.GetResult<Prisma.$StockMutationPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one StockMutation.
     * @param {StockMutationUpdateArgs} args - Arguments to update one StockMutation.
     * @example
     * // Update one StockMutation
     * const stockMutation = await prisma.stockMutation.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends StockMutationUpdateArgs>(args: SelectSubset<T, StockMutationUpdateArgs<ExtArgs>>): Prisma__StockMutationClient<$Result.GetResult<Prisma.$StockMutationPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more StockMutations.
     * @param {StockMutationDeleteManyArgs} args - Arguments to filter StockMutations to delete.
     * @example
     * // Delete a few StockMutations
     * const { count } = await prisma.stockMutation.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends StockMutationDeleteManyArgs>(args?: SelectSubset<T, StockMutationDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more StockMutations.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {StockMutationUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many StockMutations
     * const stockMutation = await prisma.stockMutation.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends StockMutationUpdateManyArgs>(args: SelectSubset<T, StockMutationUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one StockMutation.
     * @param {StockMutationUpsertArgs} args - Arguments to update or create a StockMutation.
     * @example
     * // Update or create a StockMutation
     * const stockMutation = await prisma.stockMutation.upsert({
     *   create: {
     *     // ... data to create a StockMutation
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the StockMutation we want to update
     *   }
     * })
     */
    upsert<T extends StockMutationUpsertArgs>(args: SelectSubset<T, StockMutationUpsertArgs<ExtArgs>>): Prisma__StockMutationClient<$Result.GetResult<Prisma.$StockMutationPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of StockMutations.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {StockMutationCountArgs} args - Arguments to filter StockMutations to count.
     * @example
     * // Count the number of StockMutations
     * const count = await prisma.stockMutation.count({
     *   where: {
     *     // ... the filter for the StockMutations we want to count
     *   }
     * })
    **/
    count<T extends StockMutationCountArgs>(
      args?: Subset<T, StockMutationCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], StockMutationCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a StockMutation.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {StockMutationAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends StockMutationAggregateArgs>(args: Subset<T, StockMutationAggregateArgs>): Prisma.PrismaPromise<GetStockMutationAggregateType<T>>

    /**
     * Group by StockMutation.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {StockMutationGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends StockMutationGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: StockMutationGroupByArgs['orderBy'] }
        : { orderBy?: StockMutationGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, StockMutationGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetStockMutationGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the StockMutation model
   */
  readonly fields: StockMutationFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for StockMutation.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__StockMutationClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    product<T extends ProductDefaultArgs<ExtArgs> = {}>(args?: Subset<T, ProductDefaultArgs<ExtArgs>>): Prisma__ProductClient<$Result.GetResult<Prisma.$ProductPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the StockMutation model
   */
  interface StockMutationFieldRefs {
    readonly id: FieldRef<"StockMutation", 'String'>
    readonly productId: FieldRef<"StockMutation", 'String'>
    readonly currentStock: FieldRef<"StockMutation", 'Int'>
    readonly quantity: FieldRef<"StockMutation", 'Int'>
    readonly type: FieldRef<"StockMutation", 'String'>
    readonly notes: FieldRef<"StockMutation", 'String'>
    readonly createdAt: FieldRef<"StockMutation", 'DateTime'>
    readonly updatedAt: FieldRef<"StockMutation", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * StockMutation findUnique
   */
  export type StockMutationFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the StockMutation
     */
    select?: StockMutationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the StockMutation
     */
    omit?: StockMutationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: StockMutationInclude<ExtArgs> | null
    /**
     * Filter, which StockMutation to fetch.
     */
    where: StockMutationWhereUniqueInput
  }

  /**
   * StockMutation findUniqueOrThrow
   */
  export type StockMutationFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the StockMutation
     */
    select?: StockMutationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the StockMutation
     */
    omit?: StockMutationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: StockMutationInclude<ExtArgs> | null
    /**
     * Filter, which StockMutation to fetch.
     */
    where: StockMutationWhereUniqueInput
  }

  /**
   * StockMutation findFirst
   */
  export type StockMutationFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the StockMutation
     */
    select?: StockMutationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the StockMutation
     */
    omit?: StockMutationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: StockMutationInclude<ExtArgs> | null
    /**
     * Filter, which StockMutation to fetch.
     */
    where?: StockMutationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of StockMutations to fetch.
     */
    orderBy?: StockMutationOrderByWithRelationInput | StockMutationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for StockMutations.
     */
    cursor?: StockMutationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` StockMutations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` StockMutations.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of StockMutations.
     */
    distinct?: StockMutationScalarFieldEnum | StockMutationScalarFieldEnum[]
  }

  /**
   * StockMutation findFirstOrThrow
   */
  export type StockMutationFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the StockMutation
     */
    select?: StockMutationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the StockMutation
     */
    omit?: StockMutationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: StockMutationInclude<ExtArgs> | null
    /**
     * Filter, which StockMutation to fetch.
     */
    where?: StockMutationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of StockMutations to fetch.
     */
    orderBy?: StockMutationOrderByWithRelationInput | StockMutationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for StockMutations.
     */
    cursor?: StockMutationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` StockMutations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` StockMutations.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of StockMutations.
     */
    distinct?: StockMutationScalarFieldEnum | StockMutationScalarFieldEnum[]
  }

  /**
   * StockMutation findMany
   */
  export type StockMutationFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the StockMutation
     */
    select?: StockMutationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the StockMutation
     */
    omit?: StockMutationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: StockMutationInclude<ExtArgs> | null
    /**
     * Filter, which StockMutations to fetch.
     */
    where?: StockMutationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of StockMutations to fetch.
     */
    orderBy?: StockMutationOrderByWithRelationInput | StockMutationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing StockMutations.
     */
    cursor?: StockMutationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` StockMutations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` StockMutations.
     */
    skip?: number
    distinct?: StockMutationScalarFieldEnum | StockMutationScalarFieldEnum[]
  }

  /**
   * StockMutation create
   */
  export type StockMutationCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the StockMutation
     */
    select?: StockMutationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the StockMutation
     */
    omit?: StockMutationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: StockMutationInclude<ExtArgs> | null
    /**
     * The data needed to create a StockMutation.
     */
    data: XOR<StockMutationCreateInput, StockMutationUncheckedCreateInput>
  }

  /**
   * StockMutation createMany
   */
  export type StockMutationCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many StockMutations.
     */
    data: StockMutationCreateManyInput | StockMutationCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * StockMutation update
   */
  export type StockMutationUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the StockMutation
     */
    select?: StockMutationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the StockMutation
     */
    omit?: StockMutationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: StockMutationInclude<ExtArgs> | null
    /**
     * The data needed to update a StockMutation.
     */
    data: XOR<StockMutationUpdateInput, StockMutationUncheckedUpdateInput>
    /**
     * Choose, which StockMutation to update.
     */
    where: StockMutationWhereUniqueInput
  }

  /**
   * StockMutation updateMany
   */
  export type StockMutationUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update StockMutations.
     */
    data: XOR<StockMutationUpdateManyMutationInput, StockMutationUncheckedUpdateManyInput>
    /**
     * Filter which StockMutations to update
     */
    where?: StockMutationWhereInput
    /**
     * Limit how many StockMutations to update.
     */
    limit?: number
  }

  /**
   * StockMutation upsert
   */
  export type StockMutationUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the StockMutation
     */
    select?: StockMutationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the StockMutation
     */
    omit?: StockMutationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: StockMutationInclude<ExtArgs> | null
    /**
     * The filter to search for the StockMutation to update in case it exists.
     */
    where: StockMutationWhereUniqueInput
    /**
     * In case the StockMutation found by the `where` argument doesn't exist, create a new StockMutation with this data.
     */
    create: XOR<StockMutationCreateInput, StockMutationUncheckedCreateInput>
    /**
     * In case the StockMutation was found with the provided `where` argument, update it with this data.
     */
    update: XOR<StockMutationUpdateInput, StockMutationUncheckedUpdateInput>
  }

  /**
   * StockMutation delete
   */
  export type StockMutationDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the StockMutation
     */
    select?: StockMutationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the StockMutation
     */
    omit?: StockMutationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: StockMutationInclude<ExtArgs> | null
    /**
     * Filter which StockMutation to delete.
     */
    where: StockMutationWhereUniqueInput
  }

  /**
   * StockMutation deleteMany
   */
  export type StockMutationDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which StockMutations to delete
     */
    where?: StockMutationWhereInput
    /**
     * Limit how many StockMutations to delete.
     */
    limit?: number
  }

  /**
   * StockMutation without action
   */
  export type StockMutationDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the StockMutation
     */
    select?: StockMutationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the StockMutation
     */
    omit?: StockMutationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: StockMutationInclude<ExtArgs> | null
  }


  /**
   * Model PaymentTerm
   */

  export type AggregatePaymentTerm = {
    _count: PaymentTermCountAggregateOutputType | null
    _min: PaymentTermMinAggregateOutputType | null
    _max: PaymentTermMaxAggregateOutputType | null
  }

  export type PaymentTermMinAggregateOutputType = {
    id: string | null
    name: string | null
    status: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type PaymentTermMaxAggregateOutputType = {
    id: string | null
    name: string | null
    status: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type PaymentTermCountAggregateOutputType = {
    id: number
    name: number
    status: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type PaymentTermMinAggregateInputType = {
    id?: true
    name?: true
    status?: true
    createdAt?: true
    updatedAt?: true
  }

  export type PaymentTermMaxAggregateInputType = {
    id?: true
    name?: true
    status?: true
    createdAt?: true
    updatedAt?: true
  }

  export type PaymentTermCountAggregateInputType = {
    id?: true
    name?: true
    status?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type PaymentTermAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PaymentTerm to aggregate.
     */
    where?: PaymentTermWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PaymentTerms to fetch.
     */
    orderBy?: PaymentTermOrderByWithRelationInput | PaymentTermOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: PaymentTermWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PaymentTerms from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PaymentTerms.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned PaymentTerms
    **/
    _count?: true | PaymentTermCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: PaymentTermMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: PaymentTermMaxAggregateInputType
  }

  export type GetPaymentTermAggregateType<T extends PaymentTermAggregateArgs> = {
        [P in keyof T & keyof AggregatePaymentTerm]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregatePaymentTerm[P]>
      : GetScalarType<T[P], AggregatePaymentTerm[P]>
  }




  export type PaymentTermGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PaymentTermWhereInput
    orderBy?: PaymentTermOrderByWithAggregationInput | PaymentTermOrderByWithAggregationInput[]
    by: PaymentTermScalarFieldEnum[] | PaymentTermScalarFieldEnum
    having?: PaymentTermScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: PaymentTermCountAggregateInputType | true
    _min?: PaymentTermMinAggregateInputType
    _max?: PaymentTermMaxAggregateInputType
  }

  export type PaymentTermGroupByOutputType = {
    id: string
    name: string
    status: string
    createdAt: Date
    updatedAt: Date
    _count: PaymentTermCountAggregateOutputType | null
    _min: PaymentTermMinAggregateOutputType | null
    _max: PaymentTermMaxAggregateOutputType | null
  }

  type GetPaymentTermGroupByPayload<T extends PaymentTermGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<PaymentTermGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof PaymentTermGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], PaymentTermGroupByOutputType[P]>
            : GetScalarType<T[P], PaymentTermGroupByOutputType[P]>
        }
      >
    >


  export type PaymentTermSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    status?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    PaymentAccounts?: boolean | PaymentTerm$PaymentAccountsArgs<ExtArgs>
    TopUps?: boolean | PaymentTerm$TopUpsArgs<ExtArgs>
    _count?: boolean | PaymentTermCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["paymentTerm"]>



  export type PaymentTermSelectScalar = {
    id?: boolean
    name?: boolean
    status?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type PaymentTermOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "status" | "createdAt" | "updatedAt", ExtArgs["result"]["paymentTerm"]>
  export type PaymentTermInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    PaymentAccounts?: boolean | PaymentTerm$PaymentAccountsArgs<ExtArgs>
    TopUps?: boolean | PaymentTerm$TopUpsArgs<ExtArgs>
    _count?: boolean | PaymentTermCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $PaymentTermPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "PaymentTerm"
    objects: {
      PaymentAccounts: Prisma.$PaymentAccountPayload<ExtArgs>[]
      TopUps: Prisma.$TopUpPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string
      status: string
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["paymentTerm"]>
    composites: {}
  }

  type PaymentTermGetPayload<S extends boolean | null | undefined | PaymentTermDefaultArgs> = $Result.GetResult<Prisma.$PaymentTermPayload, S>

  type PaymentTermCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<PaymentTermFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: PaymentTermCountAggregateInputType | true
    }

  export interface PaymentTermDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['PaymentTerm'], meta: { name: 'PaymentTerm' } }
    /**
     * Find zero or one PaymentTerm that matches the filter.
     * @param {PaymentTermFindUniqueArgs} args - Arguments to find a PaymentTerm
     * @example
     * // Get one PaymentTerm
     * const paymentTerm = await prisma.paymentTerm.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends PaymentTermFindUniqueArgs>(args: SelectSubset<T, PaymentTermFindUniqueArgs<ExtArgs>>): Prisma__PaymentTermClient<$Result.GetResult<Prisma.$PaymentTermPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one PaymentTerm that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {PaymentTermFindUniqueOrThrowArgs} args - Arguments to find a PaymentTerm
     * @example
     * // Get one PaymentTerm
     * const paymentTerm = await prisma.paymentTerm.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends PaymentTermFindUniqueOrThrowArgs>(args: SelectSubset<T, PaymentTermFindUniqueOrThrowArgs<ExtArgs>>): Prisma__PaymentTermClient<$Result.GetResult<Prisma.$PaymentTermPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PaymentTerm that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentTermFindFirstArgs} args - Arguments to find a PaymentTerm
     * @example
     * // Get one PaymentTerm
     * const paymentTerm = await prisma.paymentTerm.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends PaymentTermFindFirstArgs>(args?: SelectSubset<T, PaymentTermFindFirstArgs<ExtArgs>>): Prisma__PaymentTermClient<$Result.GetResult<Prisma.$PaymentTermPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PaymentTerm that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentTermFindFirstOrThrowArgs} args - Arguments to find a PaymentTerm
     * @example
     * // Get one PaymentTerm
     * const paymentTerm = await prisma.paymentTerm.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends PaymentTermFindFirstOrThrowArgs>(args?: SelectSubset<T, PaymentTermFindFirstOrThrowArgs<ExtArgs>>): Prisma__PaymentTermClient<$Result.GetResult<Prisma.$PaymentTermPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more PaymentTerms that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentTermFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all PaymentTerms
     * const paymentTerms = await prisma.paymentTerm.findMany()
     * 
     * // Get first 10 PaymentTerms
     * const paymentTerms = await prisma.paymentTerm.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const paymentTermWithIdOnly = await prisma.paymentTerm.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends PaymentTermFindManyArgs>(args?: SelectSubset<T, PaymentTermFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PaymentTermPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a PaymentTerm.
     * @param {PaymentTermCreateArgs} args - Arguments to create a PaymentTerm.
     * @example
     * // Create one PaymentTerm
     * const PaymentTerm = await prisma.paymentTerm.create({
     *   data: {
     *     // ... data to create a PaymentTerm
     *   }
     * })
     * 
     */
    create<T extends PaymentTermCreateArgs>(args: SelectSubset<T, PaymentTermCreateArgs<ExtArgs>>): Prisma__PaymentTermClient<$Result.GetResult<Prisma.$PaymentTermPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many PaymentTerms.
     * @param {PaymentTermCreateManyArgs} args - Arguments to create many PaymentTerms.
     * @example
     * // Create many PaymentTerms
     * const paymentTerm = await prisma.paymentTerm.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends PaymentTermCreateManyArgs>(args?: SelectSubset<T, PaymentTermCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a PaymentTerm.
     * @param {PaymentTermDeleteArgs} args - Arguments to delete one PaymentTerm.
     * @example
     * // Delete one PaymentTerm
     * const PaymentTerm = await prisma.paymentTerm.delete({
     *   where: {
     *     // ... filter to delete one PaymentTerm
     *   }
     * })
     * 
     */
    delete<T extends PaymentTermDeleteArgs>(args: SelectSubset<T, PaymentTermDeleteArgs<ExtArgs>>): Prisma__PaymentTermClient<$Result.GetResult<Prisma.$PaymentTermPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one PaymentTerm.
     * @param {PaymentTermUpdateArgs} args - Arguments to update one PaymentTerm.
     * @example
     * // Update one PaymentTerm
     * const paymentTerm = await prisma.paymentTerm.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends PaymentTermUpdateArgs>(args: SelectSubset<T, PaymentTermUpdateArgs<ExtArgs>>): Prisma__PaymentTermClient<$Result.GetResult<Prisma.$PaymentTermPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more PaymentTerms.
     * @param {PaymentTermDeleteManyArgs} args - Arguments to filter PaymentTerms to delete.
     * @example
     * // Delete a few PaymentTerms
     * const { count } = await prisma.paymentTerm.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends PaymentTermDeleteManyArgs>(args?: SelectSubset<T, PaymentTermDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more PaymentTerms.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentTermUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many PaymentTerms
     * const paymentTerm = await prisma.paymentTerm.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends PaymentTermUpdateManyArgs>(args: SelectSubset<T, PaymentTermUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one PaymentTerm.
     * @param {PaymentTermUpsertArgs} args - Arguments to update or create a PaymentTerm.
     * @example
     * // Update or create a PaymentTerm
     * const paymentTerm = await prisma.paymentTerm.upsert({
     *   create: {
     *     // ... data to create a PaymentTerm
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the PaymentTerm we want to update
     *   }
     * })
     */
    upsert<T extends PaymentTermUpsertArgs>(args: SelectSubset<T, PaymentTermUpsertArgs<ExtArgs>>): Prisma__PaymentTermClient<$Result.GetResult<Prisma.$PaymentTermPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of PaymentTerms.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentTermCountArgs} args - Arguments to filter PaymentTerms to count.
     * @example
     * // Count the number of PaymentTerms
     * const count = await prisma.paymentTerm.count({
     *   where: {
     *     // ... the filter for the PaymentTerms we want to count
     *   }
     * })
    **/
    count<T extends PaymentTermCountArgs>(
      args?: Subset<T, PaymentTermCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], PaymentTermCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a PaymentTerm.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentTermAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends PaymentTermAggregateArgs>(args: Subset<T, PaymentTermAggregateArgs>): Prisma.PrismaPromise<GetPaymentTermAggregateType<T>>

    /**
     * Group by PaymentTerm.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentTermGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends PaymentTermGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: PaymentTermGroupByArgs['orderBy'] }
        : { orderBy?: PaymentTermGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, PaymentTermGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetPaymentTermGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the PaymentTerm model
   */
  readonly fields: PaymentTermFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for PaymentTerm.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__PaymentTermClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    PaymentAccounts<T extends PaymentTerm$PaymentAccountsArgs<ExtArgs> = {}>(args?: Subset<T, PaymentTerm$PaymentAccountsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PaymentAccountPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    TopUps<T extends PaymentTerm$TopUpsArgs<ExtArgs> = {}>(args?: Subset<T, PaymentTerm$TopUpsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TopUpPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the PaymentTerm model
   */
  interface PaymentTermFieldRefs {
    readonly id: FieldRef<"PaymentTerm", 'String'>
    readonly name: FieldRef<"PaymentTerm", 'String'>
    readonly status: FieldRef<"PaymentTerm", 'String'>
    readonly createdAt: FieldRef<"PaymentTerm", 'DateTime'>
    readonly updatedAt: FieldRef<"PaymentTerm", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * PaymentTerm findUnique
   */
  export type PaymentTermFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentTerm
     */
    select?: PaymentTermSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaymentTerm
     */
    omit?: PaymentTermOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentTermInclude<ExtArgs> | null
    /**
     * Filter, which PaymentTerm to fetch.
     */
    where: PaymentTermWhereUniqueInput
  }

  /**
   * PaymentTerm findUniqueOrThrow
   */
  export type PaymentTermFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentTerm
     */
    select?: PaymentTermSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaymentTerm
     */
    omit?: PaymentTermOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentTermInclude<ExtArgs> | null
    /**
     * Filter, which PaymentTerm to fetch.
     */
    where: PaymentTermWhereUniqueInput
  }

  /**
   * PaymentTerm findFirst
   */
  export type PaymentTermFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentTerm
     */
    select?: PaymentTermSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaymentTerm
     */
    omit?: PaymentTermOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentTermInclude<ExtArgs> | null
    /**
     * Filter, which PaymentTerm to fetch.
     */
    where?: PaymentTermWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PaymentTerms to fetch.
     */
    orderBy?: PaymentTermOrderByWithRelationInput | PaymentTermOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PaymentTerms.
     */
    cursor?: PaymentTermWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PaymentTerms from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PaymentTerms.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PaymentTerms.
     */
    distinct?: PaymentTermScalarFieldEnum | PaymentTermScalarFieldEnum[]
  }

  /**
   * PaymentTerm findFirstOrThrow
   */
  export type PaymentTermFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentTerm
     */
    select?: PaymentTermSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaymentTerm
     */
    omit?: PaymentTermOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentTermInclude<ExtArgs> | null
    /**
     * Filter, which PaymentTerm to fetch.
     */
    where?: PaymentTermWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PaymentTerms to fetch.
     */
    orderBy?: PaymentTermOrderByWithRelationInput | PaymentTermOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PaymentTerms.
     */
    cursor?: PaymentTermWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PaymentTerms from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PaymentTerms.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PaymentTerms.
     */
    distinct?: PaymentTermScalarFieldEnum | PaymentTermScalarFieldEnum[]
  }

  /**
   * PaymentTerm findMany
   */
  export type PaymentTermFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentTerm
     */
    select?: PaymentTermSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaymentTerm
     */
    omit?: PaymentTermOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentTermInclude<ExtArgs> | null
    /**
     * Filter, which PaymentTerms to fetch.
     */
    where?: PaymentTermWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PaymentTerms to fetch.
     */
    orderBy?: PaymentTermOrderByWithRelationInput | PaymentTermOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing PaymentTerms.
     */
    cursor?: PaymentTermWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PaymentTerms from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PaymentTerms.
     */
    skip?: number
    distinct?: PaymentTermScalarFieldEnum | PaymentTermScalarFieldEnum[]
  }

  /**
   * PaymentTerm create
   */
  export type PaymentTermCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentTerm
     */
    select?: PaymentTermSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaymentTerm
     */
    omit?: PaymentTermOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentTermInclude<ExtArgs> | null
    /**
     * The data needed to create a PaymentTerm.
     */
    data: XOR<PaymentTermCreateInput, PaymentTermUncheckedCreateInput>
  }

  /**
   * PaymentTerm createMany
   */
  export type PaymentTermCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many PaymentTerms.
     */
    data: PaymentTermCreateManyInput | PaymentTermCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * PaymentTerm update
   */
  export type PaymentTermUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentTerm
     */
    select?: PaymentTermSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaymentTerm
     */
    omit?: PaymentTermOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentTermInclude<ExtArgs> | null
    /**
     * The data needed to update a PaymentTerm.
     */
    data: XOR<PaymentTermUpdateInput, PaymentTermUncheckedUpdateInput>
    /**
     * Choose, which PaymentTerm to update.
     */
    where: PaymentTermWhereUniqueInput
  }

  /**
   * PaymentTerm updateMany
   */
  export type PaymentTermUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update PaymentTerms.
     */
    data: XOR<PaymentTermUpdateManyMutationInput, PaymentTermUncheckedUpdateManyInput>
    /**
     * Filter which PaymentTerms to update
     */
    where?: PaymentTermWhereInput
    /**
     * Limit how many PaymentTerms to update.
     */
    limit?: number
  }

  /**
   * PaymentTerm upsert
   */
  export type PaymentTermUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentTerm
     */
    select?: PaymentTermSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaymentTerm
     */
    omit?: PaymentTermOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentTermInclude<ExtArgs> | null
    /**
     * The filter to search for the PaymentTerm to update in case it exists.
     */
    where: PaymentTermWhereUniqueInput
    /**
     * In case the PaymentTerm found by the `where` argument doesn't exist, create a new PaymentTerm with this data.
     */
    create: XOR<PaymentTermCreateInput, PaymentTermUncheckedCreateInput>
    /**
     * In case the PaymentTerm was found with the provided `where` argument, update it with this data.
     */
    update: XOR<PaymentTermUpdateInput, PaymentTermUncheckedUpdateInput>
  }

  /**
   * PaymentTerm delete
   */
  export type PaymentTermDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentTerm
     */
    select?: PaymentTermSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaymentTerm
     */
    omit?: PaymentTermOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentTermInclude<ExtArgs> | null
    /**
     * Filter which PaymentTerm to delete.
     */
    where: PaymentTermWhereUniqueInput
  }

  /**
   * PaymentTerm deleteMany
   */
  export type PaymentTermDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PaymentTerms to delete
     */
    where?: PaymentTermWhereInput
    /**
     * Limit how many PaymentTerms to delete.
     */
    limit?: number
  }

  /**
   * PaymentTerm.PaymentAccounts
   */
  export type PaymentTerm$PaymentAccountsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentAccount
     */
    select?: PaymentAccountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaymentAccount
     */
    omit?: PaymentAccountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentAccountInclude<ExtArgs> | null
    where?: PaymentAccountWhereInput
    orderBy?: PaymentAccountOrderByWithRelationInput | PaymentAccountOrderByWithRelationInput[]
    cursor?: PaymentAccountWhereUniqueInput
    take?: number
    skip?: number
    distinct?: PaymentAccountScalarFieldEnum | PaymentAccountScalarFieldEnum[]
  }

  /**
   * PaymentTerm.TopUps
   */
  export type PaymentTerm$TopUpsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TopUp
     */
    select?: TopUpSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TopUp
     */
    omit?: TopUpOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TopUpInclude<ExtArgs> | null
    where?: TopUpWhereInput
    orderBy?: TopUpOrderByWithRelationInput | TopUpOrderByWithRelationInput[]
    cursor?: TopUpWhereUniqueInput
    take?: number
    skip?: number
    distinct?: TopUpScalarFieldEnum | TopUpScalarFieldEnum[]
  }

  /**
   * PaymentTerm without action
   */
  export type PaymentTermDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentTerm
     */
    select?: PaymentTermSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaymentTerm
     */
    omit?: PaymentTermOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentTermInclude<ExtArgs> | null
  }


  /**
   * Model PaymentAccount
   */

  export type AggregatePaymentAccount = {
    _count: PaymentAccountCountAggregateOutputType | null
    _min: PaymentAccountMinAggregateOutputType | null
    _max: PaymentAccountMaxAggregateOutputType | null
  }

  export type PaymentAccountMinAggregateOutputType = {
    id: string | null
    paymentTermId: string | null
    accountHolderName: string | null
    accountNumber: string | null
    status: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type PaymentAccountMaxAggregateOutputType = {
    id: string | null
    paymentTermId: string | null
    accountHolderName: string | null
    accountNumber: string | null
    status: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type PaymentAccountCountAggregateOutputType = {
    id: number
    paymentTermId: number
    accountHolderName: number
    accountNumber: number
    status: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type PaymentAccountMinAggregateInputType = {
    id?: true
    paymentTermId?: true
    accountHolderName?: true
    accountNumber?: true
    status?: true
    createdAt?: true
    updatedAt?: true
  }

  export type PaymentAccountMaxAggregateInputType = {
    id?: true
    paymentTermId?: true
    accountHolderName?: true
    accountNumber?: true
    status?: true
    createdAt?: true
    updatedAt?: true
  }

  export type PaymentAccountCountAggregateInputType = {
    id?: true
    paymentTermId?: true
    accountHolderName?: true
    accountNumber?: true
    status?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type PaymentAccountAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PaymentAccount to aggregate.
     */
    where?: PaymentAccountWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PaymentAccounts to fetch.
     */
    orderBy?: PaymentAccountOrderByWithRelationInput | PaymentAccountOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: PaymentAccountWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PaymentAccounts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PaymentAccounts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned PaymentAccounts
    **/
    _count?: true | PaymentAccountCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: PaymentAccountMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: PaymentAccountMaxAggregateInputType
  }

  export type GetPaymentAccountAggregateType<T extends PaymentAccountAggregateArgs> = {
        [P in keyof T & keyof AggregatePaymentAccount]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregatePaymentAccount[P]>
      : GetScalarType<T[P], AggregatePaymentAccount[P]>
  }




  export type PaymentAccountGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PaymentAccountWhereInput
    orderBy?: PaymentAccountOrderByWithAggregationInput | PaymentAccountOrderByWithAggregationInput[]
    by: PaymentAccountScalarFieldEnum[] | PaymentAccountScalarFieldEnum
    having?: PaymentAccountScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: PaymentAccountCountAggregateInputType | true
    _min?: PaymentAccountMinAggregateInputType
    _max?: PaymentAccountMaxAggregateInputType
  }

  export type PaymentAccountGroupByOutputType = {
    id: string
    paymentTermId: string
    accountHolderName: string
    accountNumber: string
    status: string
    createdAt: Date
    updatedAt: Date
    _count: PaymentAccountCountAggregateOutputType | null
    _min: PaymentAccountMinAggregateOutputType | null
    _max: PaymentAccountMaxAggregateOutputType | null
  }

  type GetPaymentAccountGroupByPayload<T extends PaymentAccountGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<PaymentAccountGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof PaymentAccountGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], PaymentAccountGroupByOutputType[P]>
            : GetScalarType<T[P], PaymentAccountGroupByOutputType[P]>
        }
      >
    >


  export type PaymentAccountSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    paymentTermId?: boolean
    accountHolderName?: boolean
    accountNumber?: boolean
    status?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    paymentTerm?: boolean | PaymentTermDefaultArgs<ExtArgs>
    TopUps?: boolean | PaymentAccount$TopUpsArgs<ExtArgs>
    _count?: boolean | PaymentAccountCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["paymentAccount"]>



  export type PaymentAccountSelectScalar = {
    id?: boolean
    paymentTermId?: boolean
    accountHolderName?: boolean
    accountNumber?: boolean
    status?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type PaymentAccountOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "paymentTermId" | "accountHolderName" | "accountNumber" | "status" | "createdAt" | "updatedAt", ExtArgs["result"]["paymentAccount"]>
  export type PaymentAccountInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    paymentTerm?: boolean | PaymentTermDefaultArgs<ExtArgs>
    TopUps?: boolean | PaymentAccount$TopUpsArgs<ExtArgs>
    _count?: boolean | PaymentAccountCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $PaymentAccountPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "PaymentAccount"
    objects: {
      paymentTerm: Prisma.$PaymentTermPayload<ExtArgs>
      TopUps: Prisma.$TopUpPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      paymentTermId: string
      accountHolderName: string
      accountNumber: string
      status: string
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["paymentAccount"]>
    composites: {}
  }

  type PaymentAccountGetPayload<S extends boolean | null | undefined | PaymentAccountDefaultArgs> = $Result.GetResult<Prisma.$PaymentAccountPayload, S>

  type PaymentAccountCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<PaymentAccountFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: PaymentAccountCountAggregateInputType | true
    }

  export interface PaymentAccountDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['PaymentAccount'], meta: { name: 'PaymentAccount' } }
    /**
     * Find zero or one PaymentAccount that matches the filter.
     * @param {PaymentAccountFindUniqueArgs} args - Arguments to find a PaymentAccount
     * @example
     * // Get one PaymentAccount
     * const paymentAccount = await prisma.paymentAccount.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends PaymentAccountFindUniqueArgs>(args: SelectSubset<T, PaymentAccountFindUniqueArgs<ExtArgs>>): Prisma__PaymentAccountClient<$Result.GetResult<Prisma.$PaymentAccountPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one PaymentAccount that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {PaymentAccountFindUniqueOrThrowArgs} args - Arguments to find a PaymentAccount
     * @example
     * // Get one PaymentAccount
     * const paymentAccount = await prisma.paymentAccount.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends PaymentAccountFindUniqueOrThrowArgs>(args: SelectSubset<T, PaymentAccountFindUniqueOrThrowArgs<ExtArgs>>): Prisma__PaymentAccountClient<$Result.GetResult<Prisma.$PaymentAccountPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PaymentAccount that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentAccountFindFirstArgs} args - Arguments to find a PaymentAccount
     * @example
     * // Get one PaymentAccount
     * const paymentAccount = await prisma.paymentAccount.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends PaymentAccountFindFirstArgs>(args?: SelectSubset<T, PaymentAccountFindFirstArgs<ExtArgs>>): Prisma__PaymentAccountClient<$Result.GetResult<Prisma.$PaymentAccountPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PaymentAccount that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentAccountFindFirstOrThrowArgs} args - Arguments to find a PaymentAccount
     * @example
     * // Get one PaymentAccount
     * const paymentAccount = await prisma.paymentAccount.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends PaymentAccountFindFirstOrThrowArgs>(args?: SelectSubset<T, PaymentAccountFindFirstOrThrowArgs<ExtArgs>>): Prisma__PaymentAccountClient<$Result.GetResult<Prisma.$PaymentAccountPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more PaymentAccounts that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentAccountFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all PaymentAccounts
     * const paymentAccounts = await prisma.paymentAccount.findMany()
     * 
     * // Get first 10 PaymentAccounts
     * const paymentAccounts = await prisma.paymentAccount.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const paymentAccountWithIdOnly = await prisma.paymentAccount.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends PaymentAccountFindManyArgs>(args?: SelectSubset<T, PaymentAccountFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PaymentAccountPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a PaymentAccount.
     * @param {PaymentAccountCreateArgs} args - Arguments to create a PaymentAccount.
     * @example
     * // Create one PaymentAccount
     * const PaymentAccount = await prisma.paymentAccount.create({
     *   data: {
     *     // ... data to create a PaymentAccount
     *   }
     * })
     * 
     */
    create<T extends PaymentAccountCreateArgs>(args: SelectSubset<T, PaymentAccountCreateArgs<ExtArgs>>): Prisma__PaymentAccountClient<$Result.GetResult<Prisma.$PaymentAccountPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many PaymentAccounts.
     * @param {PaymentAccountCreateManyArgs} args - Arguments to create many PaymentAccounts.
     * @example
     * // Create many PaymentAccounts
     * const paymentAccount = await prisma.paymentAccount.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends PaymentAccountCreateManyArgs>(args?: SelectSubset<T, PaymentAccountCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a PaymentAccount.
     * @param {PaymentAccountDeleteArgs} args - Arguments to delete one PaymentAccount.
     * @example
     * // Delete one PaymentAccount
     * const PaymentAccount = await prisma.paymentAccount.delete({
     *   where: {
     *     // ... filter to delete one PaymentAccount
     *   }
     * })
     * 
     */
    delete<T extends PaymentAccountDeleteArgs>(args: SelectSubset<T, PaymentAccountDeleteArgs<ExtArgs>>): Prisma__PaymentAccountClient<$Result.GetResult<Prisma.$PaymentAccountPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one PaymentAccount.
     * @param {PaymentAccountUpdateArgs} args - Arguments to update one PaymentAccount.
     * @example
     * // Update one PaymentAccount
     * const paymentAccount = await prisma.paymentAccount.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends PaymentAccountUpdateArgs>(args: SelectSubset<T, PaymentAccountUpdateArgs<ExtArgs>>): Prisma__PaymentAccountClient<$Result.GetResult<Prisma.$PaymentAccountPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more PaymentAccounts.
     * @param {PaymentAccountDeleteManyArgs} args - Arguments to filter PaymentAccounts to delete.
     * @example
     * // Delete a few PaymentAccounts
     * const { count } = await prisma.paymentAccount.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends PaymentAccountDeleteManyArgs>(args?: SelectSubset<T, PaymentAccountDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more PaymentAccounts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentAccountUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many PaymentAccounts
     * const paymentAccount = await prisma.paymentAccount.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends PaymentAccountUpdateManyArgs>(args: SelectSubset<T, PaymentAccountUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one PaymentAccount.
     * @param {PaymentAccountUpsertArgs} args - Arguments to update or create a PaymentAccount.
     * @example
     * // Update or create a PaymentAccount
     * const paymentAccount = await prisma.paymentAccount.upsert({
     *   create: {
     *     // ... data to create a PaymentAccount
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the PaymentAccount we want to update
     *   }
     * })
     */
    upsert<T extends PaymentAccountUpsertArgs>(args: SelectSubset<T, PaymentAccountUpsertArgs<ExtArgs>>): Prisma__PaymentAccountClient<$Result.GetResult<Prisma.$PaymentAccountPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of PaymentAccounts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentAccountCountArgs} args - Arguments to filter PaymentAccounts to count.
     * @example
     * // Count the number of PaymentAccounts
     * const count = await prisma.paymentAccount.count({
     *   where: {
     *     // ... the filter for the PaymentAccounts we want to count
     *   }
     * })
    **/
    count<T extends PaymentAccountCountArgs>(
      args?: Subset<T, PaymentAccountCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], PaymentAccountCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a PaymentAccount.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentAccountAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends PaymentAccountAggregateArgs>(args: Subset<T, PaymentAccountAggregateArgs>): Prisma.PrismaPromise<GetPaymentAccountAggregateType<T>>

    /**
     * Group by PaymentAccount.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentAccountGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends PaymentAccountGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: PaymentAccountGroupByArgs['orderBy'] }
        : { orderBy?: PaymentAccountGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, PaymentAccountGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetPaymentAccountGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the PaymentAccount model
   */
  readonly fields: PaymentAccountFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for PaymentAccount.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__PaymentAccountClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    paymentTerm<T extends PaymentTermDefaultArgs<ExtArgs> = {}>(args?: Subset<T, PaymentTermDefaultArgs<ExtArgs>>): Prisma__PaymentTermClient<$Result.GetResult<Prisma.$PaymentTermPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    TopUps<T extends PaymentAccount$TopUpsArgs<ExtArgs> = {}>(args?: Subset<T, PaymentAccount$TopUpsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TopUpPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the PaymentAccount model
   */
  interface PaymentAccountFieldRefs {
    readonly id: FieldRef<"PaymentAccount", 'String'>
    readonly paymentTermId: FieldRef<"PaymentAccount", 'String'>
    readonly accountHolderName: FieldRef<"PaymentAccount", 'String'>
    readonly accountNumber: FieldRef<"PaymentAccount", 'String'>
    readonly status: FieldRef<"PaymentAccount", 'String'>
    readonly createdAt: FieldRef<"PaymentAccount", 'DateTime'>
    readonly updatedAt: FieldRef<"PaymentAccount", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * PaymentAccount findUnique
   */
  export type PaymentAccountFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentAccount
     */
    select?: PaymentAccountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaymentAccount
     */
    omit?: PaymentAccountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentAccountInclude<ExtArgs> | null
    /**
     * Filter, which PaymentAccount to fetch.
     */
    where: PaymentAccountWhereUniqueInput
  }

  /**
   * PaymentAccount findUniqueOrThrow
   */
  export type PaymentAccountFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentAccount
     */
    select?: PaymentAccountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaymentAccount
     */
    omit?: PaymentAccountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentAccountInclude<ExtArgs> | null
    /**
     * Filter, which PaymentAccount to fetch.
     */
    where: PaymentAccountWhereUniqueInput
  }

  /**
   * PaymentAccount findFirst
   */
  export type PaymentAccountFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentAccount
     */
    select?: PaymentAccountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaymentAccount
     */
    omit?: PaymentAccountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentAccountInclude<ExtArgs> | null
    /**
     * Filter, which PaymentAccount to fetch.
     */
    where?: PaymentAccountWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PaymentAccounts to fetch.
     */
    orderBy?: PaymentAccountOrderByWithRelationInput | PaymentAccountOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PaymentAccounts.
     */
    cursor?: PaymentAccountWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PaymentAccounts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PaymentAccounts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PaymentAccounts.
     */
    distinct?: PaymentAccountScalarFieldEnum | PaymentAccountScalarFieldEnum[]
  }

  /**
   * PaymentAccount findFirstOrThrow
   */
  export type PaymentAccountFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentAccount
     */
    select?: PaymentAccountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaymentAccount
     */
    omit?: PaymentAccountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentAccountInclude<ExtArgs> | null
    /**
     * Filter, which PaymentAccount to fetch.
     */
    where?: PaymentAccountWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PaymentAccounts to fetch.
     */
    orderBy?: PaymentAccountOrderByWithRelationInput | PaymentAccountOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PaymentAccounts.
     */
    cursor?: PaymentAccountWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PaymentAccounts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PaymentAccounts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PaymentAccounts.
     */
    distinct?: PaymentAccountScalarFieldEnum | PaymentAccountScalarFieldEnum[]
  }

  /**
   * PaymentAccount findMany
   */
  export type PaymentAccountFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentAccount
     */
    select?: PaymentAccountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaymentAccount
     */
    omit?: PaymentAccountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentAccountInclude<ExtArgs> | null
    /**
     * Filter, which PaymentAccounts to fetch.
     */
    where?: PaymentAccountWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PaymentAccounts to fetch.
     */
    orderBy?: PaymentAccountOrderByWithRelationInput | PaymentAccountOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing PaymentAccounts.
     */
    cursor?: PaymentAccountWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PaymentAccounts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PaymentAccounts.
     */
    skip?: number
    distinct?: PaymentAccountScalarFieldEnum | PaymentAccountScalarFieldEnum[]
  }

  /**
   * PaymentAccount create
   */
  export type PaymentAccountCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentAccount
     */
    select?: PaymentAccountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaymentAccount
     */
    omit?: PaymentAccountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentAccountInclude<ExtArgs> | null
    /**
     * The data needed to create a PaymentAccount.
     */
    data: XOR<PaymentAccountCreateInput, PaymentAccountUncheckedCreateInput>
  }

  /**
   * PaymentAccount createMany
   */
  export type PaymentAccountCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many PaymentAccounts.
     */
    data: PaymentAccountCreateManyInput | PaymentAccountCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * PaymentAccount update
   */
  export type PaymentAccountUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentAccount
     */
    select?: PaymentAccountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaymentAccount
     */
    omit?: PaymentAccountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentAccountInclude<ExtArgs> | null
    /**
     * The data needed to update a PaymentAccount.
     */
    data: XOR<PaymentAccountUpdateInput, PaymentAccountUncheckedUpdateInput>
    /**
     * Choose, which PaymentAccount to update.
     */
    where: PaymentAccountWhereUniqueInput
  }

  /**
   * PaymentAccount updateMany
   */
  export type PaymentAccountUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update PaymentAccounts.
     */
    data: XOR<PaymentAccountUpdateManyMutationInput, PaymentAccountUncheckedUpdateManyInput>
    /**
     * Filter which PaymentAccounts to update
     */
    where?: PaymentAccountWhereInput
    /**
     * Limit how many PaymentAccounts to update.
     */
    limit?: number
  }

  /**
   * PaymentAccount upsert
   */
  export type PaymentAccountUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentAccount
     */
    select?: PaymentAccountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaymentAccount
     */
    omit?: PaymentAccountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentAccountInclude<ExtArgs> | null
    /**
     * The filter to search for the PaymentAccount to update in case it exists.
     */
    where: PaymentAccountWhereUniqueInput
    /**
     * In case the PaymentAccount found by the `where` argument doesn't exist, create a new PaymentAccount with this data.
     */
    create: XOR<PaymentAccountCreateInput, PaymentAccountUncheckedCreateInput>
    /**
     * In case the PaymentAccount was found with the provided `where` argument, update it with this data.
     */
    update: XOR<PaymentAccountUpdateInput, PaymentAccountUncheckedUpdateInput>
  }

  /**
   * PaymentAccount delete
   */
  export type PaymentAccountDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentAccount
     */
    select?: PaymentAccountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaymentAccount
     */
    omit?: PaymentAccountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentAccountInclude<ExtArgs> | null
    /**
     * Filter which PaymentAccount to delete.
     */
    where: PaymentAccountWhereUniqueInput
  }

  /**
   * PaymentAccount deleteMany
   */
  export type PaymentAccountDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PaymentAccounts to delete
     */
    where?: PaymentAccountWhereInput
    /**
     * Limit how many PaymentAccounts to delete.
     */
    limit?: number
  }

  /**
   * PaymentAccount.TopUps
   */
  export type PaymentAccount$TopUpsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TopUp
     */
    select?: TopUpSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TopUp
     */
    omit?: TopUpOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TopUpInclude<ExtArgs> | null
    where?: TopUpWhereInput
    orderBy?: TopUpOrderByWithRelationInput | TopUpOrderByWithRelationInput[]
    cursor?: TopUpWhereUniqueInput
    take?: number
    skip?: number
    distinct?: TopUpScalarFieldEnum | TopUpScalarFieldEnum[]
  }

  /**
   * PaymentAccount without action
   */
  export type PaymentAccountDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentAccount
     */
    select?: PaymentAccountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaymentAccount
     */
    omit?: PaymentAccountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentAccountInclude<ExtArgs> | null
  }


  /**
   * Model Wishlist
   */

  export type AggregateWishlist = {
    _count: WishlistCountAggregateOutputType | null
    _min: WishlistMinAggregateOutputType | null
    _max: WishlistMaxAggregateOutputType | null
  }

  export type WishlistMinAggregateOutputType = {
    id: string | null
    userId: string | null
    productId: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type WishlistMaxAggregateOutputType = {
    id: string | null
    userId: string | null
    productId: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type WishlistCountAggregateOutputType = {
    id: number
    userId: number
    productId: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type WishlistMinAggregateInputType = {
    id?: true
    userId?: true
    productId?: true
    createdAt?: true
    updatedAt?: true
  }

  export type WishlistMaxAggregateInputType = {
    id?: true
    userId?: true
    productId?: true
    createdAt?: true
    updatedAt?: true
  }

  export type WishlistCountAggregateInputType = {
    id?: true
    userId?: true
    productId?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type WishlistAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Wishlist to aggregate.
     */
    where?: WishlistWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Wishlists to fetch.
     */
    orderBy?: WishlistOrderByWithRelationInput | WishlistOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: WishlistWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Wishlists from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Wishlists.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Wishlists
    **/
    _count?: true | WishlistCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: WishlistMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: WishlistMaxAggregateInputType
  }

  export type GetWishlistAggregateType<T extends WishlistAggregateArgs> = {
        [P in keyof T & keyof AggregateWishlist]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateWishlist[P]>
      : GetScalarType<T[P], AggregateWishlist[P]>
  }




  export type WishlistGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: WishlistWhereInput
    orderBy?: WishlistOrderByWithAggregationInput | WishlistOrderByWithAggregationInput[]
    by: WishlistScalarFieldEnum[] | WishlistScalarFieldEnum
    having?: WishlistScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: WishlistCountAggregateInputType | true
    _min?: WishlistMinAggregateInputType
    _max?: WishlistMaxAggregateInputType
  }

  export type WishlistGroupByOutputType = {
    id: string
    userId: string
    productId: string
    createdAt: Date
    updatedAt: Date
    _count: WishlistCountAggregateOutputType | null
    _min: WishlistMinAggregateOutputType | null
    _max: WishlistMaxAggregateOutputType | null
  }

  type GetWishlistGroupByPayload<T extends WishlistGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<WishlistGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof WishlistGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], WishlistGroupByOutputType[P]>
            : GetScalarType<T[P], WishlistGroupByOutputType[P]>
        }
      >
    >


  export type WishlistSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    productId?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    product?: boolean | ProductDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["wishlist"]>



  export type WishlistSelectScalar = {
    id?: boolean
    userId?: boolean
    productId?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type WishlistOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "userId" | "productId" | "createdAt" | "updatedAt", ExtArgs["result"]["wishlist"]>
  export type WishlistInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    product?: boolean | ProductDefaultArgs<ExtArgs>
  }

  export type $WishlistPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Wishlist"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
      product: Prisma.$ProductPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      userId: string
      productId: string
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["wishlist"]>
    composites: {}
  }

  type WishlistGetPayload<S extends boolean | null | undefined | WishlistDefaultArgs> = $Result.GetResult<Prisma.$WishlistPayload, S>

  type WishlistCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<WishlistFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: WishlistCountAggregateInputType | true
    }

  export interface WishlistDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Wishlist'], meta: { name: 'Wishlist' } }
    /**
     * Find zero or one Wishlist that matches the filter.
     * @param {WishlistFindUniqueArgs} args - Arguments to find a Wishlist
     * @example
     * // Get one Wishlist
     * const wishlist = await prisma.wishlist.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends WishlistFindUniqueArgs>(args: SelectSubset<T, WishlistFindUniqueArgs<ExtArgs>>): Prisma__WishlistClient<$Result.GetResult<Prisma.$WishlistPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Wishlist that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {WishlistFindUniqueOrThrowArgs} args - Arguments to find a Wishlist
     * @example
     * // Get one Wishlist
     * const wishlist = await prisma.wishlist.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends WishlistFindUniqueOrThrowArgs>(args: SelectSubset<T, WishlistFindUniqueOrThrowArgs<ExtArgs>>): Prisma__WishlistClient<$Result.GetResult<Prisma.$WishlistPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Wishlist that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WishlistFindFirstArgs} args - Arguments to find a Wishlist
     * @example
     * // Get one Wishlist
     * const wishlist = await prisma.wishlist.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends WishlistFindFirstArgs>(args?: SelectSubset<T, WishlistFindFirstArgs<ExtArgs>>): Prisma__WishlistClient<$Result.GetResult<Prisma.$WishlistPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Wishlist that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WishlistFindFirstOrThrowArgs} args - Arguments to find a Wishlist
     * @example
     * // Get one Wishlist
     * const wishlist = await prisma.wishlist.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends WishlistFindFirstOrThrowArgs>(args?: SelectSubset<T, WishlistFindFirstOrThrowArgs<ExtArgs>>): Prisma__WishlistClient<$Result.GetResult<Prisma.$WishlistPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Wishlists that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WishlistFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Wishlists
     * const wishlists = await prisma.wishlist.findMany()
     * 
     * // Get first 10 Wishlists
     * const wishlists = await prisma.wishlist.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const wishlistWithIdOnly = await prisma.wishlist.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends WishlistFindManyArgs>(args?: SelectSubset<T, WishlistFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$WishlistPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Wishlist.
     * @param {WishlistCreateArgs} args - Arguments to create a Wishlist.
     * @example
     * // Create one Wishlist
     * const Wishlist = await prisma.wishlist.create({
     *   data: {
     *     // ... data to create a Wishlist
     *   }
     * })
     * 
     */
    create<T extends WishlistCreateArgs>(args: SelectSubset<T, WishlistCreateArgs<ExtArgs>>): Prisma__WishlistClient<$Result.GetResult<Prisma.$WishlistPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Wishlists.
     * @param {WishlistCreateManyArgs} args - Arguments to create many Wishlists.
     * @example
     * // Create many Wishlists
     * const wishlist = await prisma.wishlist.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends WishlistCreateManyArgs>(args?: SelectSubset<T, WishlistCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Wishlist.
     * @param {WishlistDeleteArgs} args - Arguments to delete one Wishlist.
     * @example
     * // Delete one Wishlist
     * const Wishlist = await prisma.wishlist.delete({
     *   where: {
     *     // ... filter to delete one Wishlist
     *   }
     * })
     * 
     */
    delete<T extends WishlistDeleteArgs>(args: SelectSubset<T, WishlistDeleteArgs<ExtArgs>>): Prisma__WishlistClient<$Result.GetResult<Prisma.$WishlistPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Wishlist.
     * @param {WishlistUpdateArgs} args - Arguments to update one Wishlist.
     * @example
     * // Update one Wishlist
     * const wishlist = await prisma.wishlist.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends WishlistUpdateArgs>(args: SelectSubset<T, WishlistUpdateArgs<ExtArgs>>): Prisma__WishlistClient<$Result.GetResult<Prisma.$WishlistPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Wishlists.
     * @param {WishlistDeleteManyArgs} args - Arguments to filter Wishlists to delete.
     * @example
     * // Delete a few Wishlists
     * const { count } = await prisma.wishlist.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends WishlistDeleteManyArgs>(args?: SelectSubset<T, WishlistDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Wishlists.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WishlistUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Wishlists
     * const wishlist = await prisma.wishlist.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends WishlistUpdateManyArgs>(args: SelectSubset<T, WishlistUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Wishlist.
     * @param {WishlistUpsertArgs} args - Arguments to update or create a Wishlist.
     * @example
     * // Update or create a Wishlist
     * const wishlist = await prisma.wishlist.upsert({
     *   create: {
     *     // ... data to create a Wishlist
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Wishlist we want to update
     *   }
     * })
     */
    upsert<T extends WishlistUpsertArgs>(args: SelectSubset<T, WishlistUpsertArgs<ExtArgs>>): Prisma__WishlistClient<$Result.GetResult<Prisma.$WishlistPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Wishlists.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WishlistCountArgs} args - Arguments to filter Wishlists to count.
     * @example
     * // Count the number of Wishlists
     * const count = await prisma.wishlist.count({
     *   where: {
     *     // ... the filter for the Wishlists we want to count
     *   }
     * })
    **/
    count<T extends WishlistCountArgs>(
      args?: Subset<T, WishlistCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], WishlistCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Wishlist.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WishlistAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends WishlistAggregateArgs>(args: Subset<T, WishlistAggregateArgs>): Prisma.PrismaPromise<GetWishlistAggregateType<T>>

    /**
     * Group by Wishlist.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WishlistGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends WishlistGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: WishlistGroupByArgs['orderBy'] }
        : { orderBy?: WishlistGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, WishlistGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetWishlistGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Wishlist model
   */
  readonly fields: WishlistFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Wishlist.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__WishlistClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    product<T extends ProductDefaultArgs<ExtArgs> = {}>(args?: Subset<T, ProductDefaultArgs<ExtArgs>>): Prisma__ProductClient<$Result.GetResult<Prisma.$ProductPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Wishlist model
   */
  interface WishlistFieldRefs {
    readonly id: FieldRef<"Wishlist", 'String'>
    readonly userId: FieldRef<"Wishlist", 'String'>
    readonly productId: FieldRef<"Wishlist", 'String'>
    readonly createdAt: FieldRef<"Wishlist", 'DateTime'>
    readonly updatedAt: FieldRef<"Wishlist", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Wishlist findUnique
   */
  export type WishlistFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Wishlist
     */
    select?: WishlistSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Wishlist
     */
    omit?: WishlistOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WishlistInclude<ExtArgs> | null
    /**
     * Filter, which Wishlist to fetch.
     */
    where: WishlistWhereUniqueInput
  }

  /**
   * Wishlist findUniqueOrThrow
   */
  export type WishlistFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Wishlist
     */
    select?: WishlistSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Wishlist
     */
    omit?: WishlistOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WishlistInclude<ExtArgs> | null
    /**
     * Filter, which Wishlist to fetch.
     */
    where: WishlistWhereUniqueInput
  }

  /**
   * Wishlist findFirst
   */
  export type WishlistFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Wishlist
     */
    select?: WishlistSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Wishlist
     */
    omit?: WishlistOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WishlistInclude<ExtArgs> | null
    /**
     * Filter, which Wishlist to fetch.
     */
    where?: WishlistWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Wishlists to fetch.
     */
    orderBy?: WishlistOrderByWithRelationInput | WishlistOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Wishlists.
     */
    cursor?: WishlistWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Wishlists from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Wishlists.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Wishlists.
     */
    distinct?: WishlistScalarFieldEnum | WishlistScalarFieldEnum[]
  }

  /**
   * Wishlist findFirstOrThrow
   */
  export type WishlistFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Wishlist
     */
    select?: WishlistSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Wishlist
     */
    omit?: WishlistOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WishlistInclude<ExtArgs> | null
    /**
     * Filter, which Wishlist to fetch.
     */
    where?: WishlistWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Wishlists to fetch.
     */
    orderBy?: WishlistOrderByWithRelationInput | WishlistOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Wishlists.
     */
    cursor?: WishlistWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Wishlists from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Wishlists.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Wishlists.
     */
    distinct?: WishlistScalarFieldEnum | WishlistScalarFieldEnum[]
  }

  /**
   * Wishlist findMany
   */
  export type WishlistFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Wishlist
     */
    select?: WishlistSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Wishlist
     */
    omit?: WishlistOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WishlistInclude<ExtArgs> | null
    /**
     * Filter, which Wishlists to fetch.
     */
    where?: WishlistWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Wishlists to fetch.
     */
    orderBy?: WishlistOrderByWithRelationInput | WishlistOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Wishlists.
     */
    cursor?: WishlistWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Wishlists from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Wishlists.
     */
    skip?: number
    distinct?: WishlistScalarFieldEnum | WishlistScalarFieldEnum[]
  }

  /**
   * Wishlist create
   */
  export type WishlistCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Wishlist
     */
    select?: WishlistSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Wishlist
     */
    omit?: WishlistOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WishlistInclude<ExtArgs> | null
    /**
     * The data needed to create a Wishlist.
     */
    data: XOR<WishlistCreateInput, WishlistUncheckedCreateInput>
  }

  /**
   * Wishlist createMany
   */
  export type WishlistCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Wishlists.
     */
    data: WishlistCreateManyInput | WishlistCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Wishlist update
   */
  export type WishlistUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Wishlist
     */
    select?: WishlistSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Wishlist
     */
    omit?: WishlistOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WishlistInclude<ExtArgs> | null
    /**
     * The data needed to update a Wishlist.
     */
    data: XOR<WishlistUpdateInput, WishlistUncheckedUpdateInput>
    /**
     * Choose, which Wishlist to update.
     */
    where: WishlistWhereUniqueInput
  }

  /**
   * Wishlist updateMany
   */
  export type WishlistUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Wishlists.
     */
    data: XOR<WishlistUpdateManyMutationInput, WishlistUncheckedUpdateManyInput>
    /**
     * Filter which Wishlists to update
     */
    where?: WishlistWhereInput
    /**
     * Limit how many Wishlists to update.
     */
    limit?: number
  }

  /**
   * Wishlist upsert
   */
  export type WishlistUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Wishlist
     */
    select?: WishlistSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Wishlist
     */
    omit?: WishlistOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WishlistInclude<ExtArgs> | null
    /**
     * The filter to search for the Wishlist to update in case it exists.
     */
    where: WishlistWhereUniqueInput
    /**
     * In case the Wishlist found by the `where` argument doesn't exist, create a new Wishlist with this data.
     */
    create: XOR<WishlistCreateInput, WishlistUncheckedCreateInput>
    /**
     * In case the Wishlist was found with the provided `where` argument, update it with this data.
     */
    update: XOR<WishlistUpdateInput, WishlistUncheckedUpdateInput>
  }

  /**
   * Wishlist delete
   */
  export type WishlistDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Wishlist
     */
    select?: WishlistSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Wishlist
     */
    omit?: WishlistOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WishlistInclude<ExtArgs> | null
    /**
     * Filter which Wishlist to delete.
     */
    where: WishlistWhereUniqueInput
  }

  /**
   * Wishlist deleteMany
   */
  export type WishlistDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Wishlists to delete
     */
    where?: WishlistWhereInput
    /**
     * Limit how many Wishlists to delete.
     */
    limit?: number
  }

  /**
   * Wishlist without action
   */
  export type WishlistDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Wishlist
     */
    select?: WishlistSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Wishlist
     */
    omit?: WishlistOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: WishlistInclude<ExtArgs> | null
  }


  /**
   * Model TopUp
   */

  export type AggregateTopUp = {
    _count: TopUpCountAggregateOutputType | null
    _avg: TopUpAvgAggregateOutputType | null
    _sum: TopUpSumAggregateOutputType | null
    _min: TopUpMinAggregateOutputType | null
    _max: TopUpMaxAggregateOutputType | null
  }

  export type TopUpAvgAggregateOutputType = {
    nominal: number | null
  }

  export type TopUpSumAggregateOutputType = {
    nominal: number | null
  }

  export type TopUpMinAggregateOutputType = {
    id: string | null
    nominal: number | null
    adminId: string | null
    userId: string | null
    proofOfTransferFileName: string | null
    status: string | null
    createdAt: Date | null
    updatedAt: Date | null
    paymentAccountId: string | null
    paymentTermId: string | null
  }

  export type TopUpMaxAggregateOutputType = {
    id: string | null
    nominal: number | null
    adminId: string | null
    userId: string | null
    proofOfTransferFileName: string | null
    status: string | null
    createdAt: Date | null
    updatedAt: Date | null
    paymentAccountId: string | null
    paymentTermId: string | null
  }

  export type TopUpCountAggregateOutputType = {
    id: number
    nominal: number
    adminId: number
    userId: number
    proofOfTransferFileName: number
    status: number
    createdAt: number
    updatedAt: number
    paymentAccountId: number
    paymentTermId: number
    _all: number
  }


  export type TopUpAvgAggregateInputType = {
    nominal?: true
  }

  export type TopUpSumAggregateInputType = {
    nominal?: true
  }

  export type TopUpMinAggregateInputType = {
    id?: true
    nominal?: true
    adminId?: true
    userId?: true
    proofOfTransferFileName?: true
    status?: true
    createdAt?: true
    updatedAt?: true
    paymentAccountId?: true
    paymentTermId?: true
  }

  export type TopUpMaxAggregateInputType = {
    id?: true
    nominal?: true
    adminId?: true
    userId?: true
    proofOfTransferFileName?: true
    status?: true
    createdAt?: true
    updatedAt?: true
    paymentAccountId?: true
    paymentTermId?: true
  }

  export type TopUpCountAggregateInputType = {
    id?: true
    nominal?: true
    adminId?: true
    userId?: true
    proofOfTransferFileName?: true
    status?: true
    createdAt?: true
    updatedAt?: true
    paymentAccountId?: true
    paymentTermId?: true
    _all?: true
  }

  export type TopUpAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which TopUp to aggregate.
     */
    where?: TopUpWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TopUps to fetch.
     */
    orderBy?: TopUpOrderByWithRelationInput | TopUpOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: TopUpWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TopUps from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TopUps.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned TopUps
    **/
    _count?: true | TopUpCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: TopUpAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: TopUpSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: TopUpMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: TopUpMaxAggregateInputType
  }

  export type GetTopUpAggregateType<T extends TopUpAggregateArgs> = {
        [P in keyof T & keyof AggregateTopUp]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateTopUp[P]>
      : GetScalarType<T[P], AggregateTopUp[P]>
  }




  export type TopUpGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TopUpWhereInput
    orderBy?: TopUpOrderByWithAggregationInput | TopUpOrderByWithAggregationInput[]
    by: TopUpScalarFieldEnum[] | TopUpScalarFieldEnum
    having?: TopUpScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: TopUpCountAggregateInputType | true
    _avg?: TopUpAvgAggregateInputType
    _sum?: TopUpSumAggregateInputType
    _min?: TopUpMinAggregateInputType
    _max?: TopUpMaxAggregateInputType
  }

  export type TopUpGroupByOutputType = {
    id: string
    nominal: number
    adminId: string | null
    userId: string
    proofOfTransferFileName: string
    status: string
    createdAt: Date
    updatedAt: Date
    paymentAccountId: string
    paymentTermId: string
    _count: TopUpCountAggregateOutputType | null
    _avg: TopUpAvgAggregateOutputType | null
    _sum: TopUpSumAggregateOutputType | null
    _min: TopUpMinAggregateOutputType | null
    _max: TopUpMaxAggregateOutputType | null
  }

  type GetTopUpGroupByPayload<T extends TopUpGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<TopUpGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof TopUpGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], TopUpGroupByOutputType[P]>
            : GetScalarType<T[P], TopUpGroupByOutputType[P]>
        }
      >
    >


  export type TopUpSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    nominal?: boolean
    adminId?: boolean
    userId?: boolean
    proofOfTransferFileName?: boolean
    status?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    paymentAccountId?: boolean
    paymentTermId?: boolean
    admin?: boolean | TopUp$adminArgs<ExtArgs>
    user?: boolean | UserDefaultArgs<ExtArgs>
    PaymentAccount?: boolean | PaymentAccountDefaultArgs<ExtArgs>
    paymentTerm?: boolean | PaymentTermDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["topUp"]>



  export type TopUpSelectScalar = {
    id?: boolean
    nominal?: boolean
    adminId?: boolean
    userId?: boolean
    proofOfTransferFileName?: boolean
    status?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    paymentAccountId?: boolean
    paymentTermId?: boolean
  }

  export type TopUpOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "nominal" | "adminId" | "userId" | "proofOfTransferFileName" | "status" | "createdAt" | "updatedAt" | "paymentAccountId" | "paymentTermId", ExtArgs["result"]["topUp"]>
  export type TopUpInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    admin?: boolean | TopUp$adminArgs<ExtArgs>
    user?: boolean | UserDefaultArgs<ExtArgs>
    PaymentAccount?: boolean | PaymentAccountDefaultArgs<ExtArgs>
    paymentTerm?: boolean | PaymentTermDefaultArgs<ExtArgs>
  }

  export type $TopUpPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "TopUp"
    objects: {
      admin: Prisma.$AdminPayload<ExtArgs> | null
      user: Prisma.$UserPayload<ExtArgs>
      PaymentAccount: Prisma.$PaymentAccountPayload<ExtArgs>
      paymentTerm: Prisma.$PaymentTermPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      nominal: number
      adminId: string | null
      userId: string
      proofOfTransferFileName: string
      status: string
      createdAt: Date
      updatedAt: Date
      paymentAccountId: string
      paymentTermId: string
    }, ExtArgs["result"]["topUp"]>
    composites: {}
  }

  type TopUpGetPayload<S extends boolean | null | undefined | TopUpDefaultArgs> = $Result.GetResult<Prisma.$TopUpPayload, S>

  type TopUpCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<TopUpFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: TopUpCountAggregateInputType | true
    }

  export interface TopUpDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['TopUp'], meta: { name: 'TopUp' } }
    /**
     * Find zero or one TopUp that matches the filter.
     * @param {TopUpFindUniqueArgs} args - Arguments to find a TopUp
     * @example
     * // Get one TopUp
     * const topUp = await prisma.topUp.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends TopUpFindUniqueArgs>(args: SelectSubset<T, TopUpFindUniqueArgs<ExtArgs>>): Prisma__TopUpClient<$Result.GetResult<Prisma.$TopUpPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one TopUp that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {TopUpFindUniqueOrThrowArgs} args - Arguments to find a TopUp
     * @example
     * // Get one TopUp
     * const topUp = await prisma.topUp.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends TopUpFindUniqueOrThrowArgs>(args: SelectSubset<T, TopUpFindUniqueOrThrowArgs<ExtArgs>>): Prisma__TopUpClient<$Result.GetResult<Prisma.$TopUpPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first TopUp that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TopUpFindFirstArgs} args - Arguments to find a TopUp
     * @example
     * // Get one TopUp
     * const topUp = await prisma.topUp.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends TopUpFindFirstArgs>(args?: SelectSubset<T, TopUpFindFirstArgs<ExtArgs>>): Prisma__TopUpClient<$Result.GetResult<Prisma.$TopUpPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first TopUp that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TopUpFindFirstOrThrowArgs} args - Arguments to find a TopUp
     * @example
     * // Get one TopUp
     * const topUp = await prisma.topUp.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends TopUpFindFirstOrThrowArgs>(args?: SelectSubset<T, TopUpFindFirstOrThrowArgs<ExtArgs>>): Prisma__TopUpClient<$Result.GetResult<Prisma.$TopUpPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more TopUps that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TopUpFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all TopUps
     * const topUps = await prisma.topUp.findMany()
     * 
     * // Get first 10 TopUps
     * const topUps = await prisma.topUp.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const topUpWithIdOnly = await prisma.topUp.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends TopUpFindManyArgs>(args?: SelectSubset<T, TopUpFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TopUpPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a TopUp.
     * @param {TopUpCreateArgs} args - Arguments to create a TopUp.
     * @example
     * // Create one TopUp
     * const TopUp = await prisma.topUp.create({
     *   data: {
     *     // ... data to create a TopUp
     *   }
     * })
     * 
     */
    create<T extends TopUpCreateArgs>(args: SelectSubset<T, TopUpCreateArgs<ExtArgs>>): Prisma__TopUpClient<$Result.GetResult<Prisma.$TopUpPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many TopUps.
     * @param {TopUpCreateManyArgs} args - Arguments to create many TopUps.
     * @example
     * // Create many TopUps
     * const topUp = await prisma.topUp.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends TopUpCreateManyArgs>(args?: SelectSubset<T, TopUpCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a TopUp.
     * @param {TopUpDeleteArgs} args - Arguments to delete one TopUp.
     * @example
     * // Delete one TopUp
     * const TopUp = await prisma.topUp.delete({
     *   where: {
     *     // ... filter to delete one TopUp
     *   }
     * })
     * 
     */
    delete<T extends TopUpDeleteArgs>(args: SelectSubset<T, TopUpDeleteArgs<ExtArgs>>): Prisma__TopUpClient<$Result.GetResult<Prisma.$TopUpPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one TopUp.
     * @param {TopUpUpdateArgs} args - Arguments to update one TopUp.
     * @example
     * // Update one TopUp
     * const topUp = await prisma.topUp.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends TopUpUpdateArgs>(args: SelectSubset<T, TopUpUpdateArgs<ExtArgs>>): Prisma__TopUpClient<$Result.GetResult<Prisma.$TopUpPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more TopUps.
     * @param {TopUpDeleteManyArgs} args - Arguments to filter TopUps to delete.
     * @example
     * // Delete a few TopUps
     * const { count } = await prisma.topUp.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends TopUpDeleteManyArgs>(args?: SelectSubset<T, TopUpDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more TopUps.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TopUpUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many TopUps
     * const topUp = await prisma.topUp.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends TopUpUpdateManyArgs>(args: SelectSubset<T, TopUpUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one TopUp.
     * @param {TopUpUpsertArgs} args - Arguments to update or create a TopUp.
     * @example
     * // Update or create a TopUp
     * const topUp = await prisma.topUp.upsert({
     *   create: {
     *     // ... data to create a TopUp
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the TopUp we want to update
     *   }
     * })
     */
    upsert<T extends TopUpUpsertArgs>(args: SelectSubset<T, TopUpUpsertArgs<ExtArgs>>): Prisma__TopUpClient<$Result.GetResult<Prisma.$TopUpPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of TopUps.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TopUpCountArgs} args - Arguments to filter TopUps to count.
     * @example
     * // Count the number of TopUps
     * const count = await prisma.topUp.count({
     *   where: {
     *     // ... the filter for the TopUps we want to count
     *   }
     * })
    **/
    count<T extends TopUpCountArgs>(
      args?: Subset<T, TopUpCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], TopUpCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a TopUp.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TopUpAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends TopUpAggregateArgs>(args: Subset<T, TopUpAggregateArgs>): Prisma.PrismaPromise<GetTopUpAggregateType<T>>

    /**
     * Group by TopUp.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TopUpGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends TopUpGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: TopUpGroupByArgs['orderBy'] }
        : { orderBy?: TopUpGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, TopUpGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetTopUpGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the TopUp model
   */
  readonly fields: TopUpFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for TopUp.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__TopUpClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    admin<T extends TopUp$adminArgs<ExtArgs> = {}>(args?: Subset<T, TopUp$adminArgs<ExtArgs>>): Prisma__AdminClient<$Result.GetResult<Prisma.$AdminPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    PaymentAccount<T extends PaymentAccountDefaultArgs<ExtArgs> = {}>(args?: Subset<T, PaymentAccountDefaultArgs<ExtArgs>>): Prisma__PaymentAccountClient<$Result.GetResult<Prisma.$PaymentAccountPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    paymentTerm<T extends PaymentTermDefaultArgs<ExtArgs> = {}>(args?: Subset<T, PaymentTermDefaultArgs<ExtArgs>>): Prisma__PaymentTermClient<$Result.GetResult<Prisma.$PaymentTermPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the TopUp model
   */
  interface TopUpFieldRefs {
    readonly id: FieldRef<"TopUp", 'String'>
    readonly nominal: FieldRef<"TopUp", 'Int'>
    readonly adminId: FieldRef<"TopUp", 'String'>
    readonly userId: FieldRef<"TopUp", 'String'>
    readonly proofOfTransferFileName: FieldRef<"TopUp", 'String'>
    readonly status: FieldRef<"TopUp", 'String'>
    readonly createdAt: FieldRef<"TopUp", 'DateTime'>
    readonly updatedAt: FieldRef<"TopUp", 'DateTime'>
    readonly paymentAccountId: FieldRef<"TopUp", 'String'>
    readonly paymentTermId: FieldRef<"TopUp", 'String'>
  }
    

  // Custom InputTypes
  /**
   * TopUp findUnique
   */
  export type TopUpFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TopUp
     */
    select?: TopUpSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TopUp
     */
    omit?: TopUpOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TopUpInclude<ExtArgs> | null
    /**
     * Filter, which TopUp to fetch.
     */
    where: TopUpWhereUniqueInput
  }

  /**
   * TopUp findUniqueOrThrow
   */
  export type TopUpFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TopUp
     */
    select?: TopUpSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TopUp
     */
    omit?: TopUpOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TopUpInclude<ExtArgs> | null
    /**
     * Filter, which TopUp to fetch.
     */
    where: TopUpWhereUniqueInput
  }

  /**
   * TopUp findFirst
   */
  export type TopUpFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TopUp
     */
    select?: TopUpSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TopUp
     */
    omit?: TopUpOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TopUpInclude<ExtArgs> | null
    /**
     * Filter, which TopUp to fetch.
     */
    where?: TopUpWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TopUps to fetch.
     */
    orderBy?: TopUpOrderByWithRelationInput | TopUpOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for TopUps.
     */
    cursor?: TopUpWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TopUps from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TopUps.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of TopUps.
     */
    distinct?: TopUpScalarFieldEnum | TopUpScalarFieldEnum[]
  }

  /**
   * TopUp findFirstOrThrow
   */
  export type TopUpFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TopUp
     */
    select?: TopUpSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TopUp
     */
    omit?: TopUpOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TopUpInclude<ExtArgs> | null
    /**
     * Filter, which TopUp to fetch.
     */
    where?: TopUpWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TopUps to fetch.
     */
    orderBy?: TopUpOrderByWithRelationInput | TopUpOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for TopUps.
     */
    cursor?: TopUpWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TopUps from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TopUps.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of TopUps.
     */
    distinct?: TopUpScalarFieldEnum | TopUpScalarFieldEnum[]
  }

  /**
   * TopUp findMany
   */
  export type TopUpFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TopUp
     */
    select?: TopUpSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TopUp
     */
    omit?: TopUpOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TopUpInclude<ExtArgs> | null
    /**
     * Filter, which TopUps to fetch.
     */
    where?: TopUpWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TopUps to fetch.
     */
    orderBy?: TopUpOrderByWithRelationInput | TopUpOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing TopUps.
     */
    cursor?: TopUpWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TopUps from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TopUps.
     */
    skip?: number
    distinct?: TopUpScalarFieldEnum | TopUpScalarFieldEnum[]
  }

  /**
   * TopUp create
   */
  export type TopUpCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TopUp
     */
    select?: TopUpSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TopUp
     */
    omit?: TopUpOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TopUpInclude<ExtArgs> | null
    /**
     * The data needed to create a TopUp.
     */
    data: XOR<TopUpCreateInput, TopUpUncheckedCreateInput>
  }

  /**
   * TopUp createMany
   */
  export type TopUpCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many TopUps.
     */
    data: TopUpCreateManyInput | TopUpCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * TopUp update
   */
  export type TopUpUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TopUp
     */
    select?: TopUpSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TopUp
     */
    omit?: TopUpOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TopUpInclude<ExtArgs> | null
    /**
     * The data needed to update a TopUp.
     */
    data: XOR<TopUpUpdateInput, TopUpUncheckedUpdateInput>
    /**
     * Choose, which TopUp to update.
     */
    where: TopUpWhereUniqueInput
  }

  /**
   * TopUp updateMany
   */
  export type TopUpUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update TopUps.
     */
    data: XOR<TopUpUpdateManyMutationInput, TopUpUncheckedUpdateManyInput>
    /**
     * Filter which TopUps to update
     */
    where?: TopUpWhereInput
    /**
     * Limit how many TopUps to update.
     */
    limit?: number
  }

  /**
   * TopUp upsert
   */
  export type TopUpUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TopUp
     */
    select?: TopUpSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TopUp
     */
    omit?: TopUpOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TopUpInclude<ExtArgs> | null
    /**
     * The filter to search for the TopUp to update in case it exists.
     */
    where: TopUpWhereUniqueInput
    /**
     * In case the TopUp found by the `where` argument doesn't exist, create a new TopUp with this data.
     */
    create: XOR<TopUpCreateInput, TopUpUncheckedCreateInput>
    /**
     * In case the TopUp was found with the provided `where` argument, update it with this data.
     */
    update: XOR<TopUpUpdateInput, TopUpUncheckedUpdateInput>
  }

  /**
   * TopUp delete
   */
  export type TopUpDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TopUp
     */
    select?: TopUpSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TopUp
     */
    omit?: TopUpOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TopUpInclude<ExtArgs> | null
    /**
     * Filter which TopUp to delete.
     */
    where: TopUpWhereUniqueInput
  }

  /**
   * TopUp deleteMany
   */
  export type TopUpDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which TopUps to delete
     */
    where?: TopUpWhereInput
    /**
     * Limit how many TopUps to delete.
     */
    limit?: number
  }

  /**
   * TopUp.admin
   */
  export type TopUp$adminArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Admin
     */
    select?: AdminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Admin
     */
    omit?: AdminOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AdminInclude<ExtArgs> | null
    where?: AdminWhereInput
  }

  /**
   * TopUp without action
   */
  export type TopUpDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TopUp
     */
    select?: TopUpSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TopUp
     */
    omit?: TopUpOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TopUpInclude<ExtArgs> | null
  }


  /**
   * Model Transaction
   */

  export type AggregateTransaction = {
    _count: TransactionCountAggregateOutputType | null
    _avg: TransactionAvgAggregateOutputType | null
    _sum: TransactionSumAggregateOutputType | null
    _min: TransactionMinAggregateOutputType | null
    _max: TransactionMaxAggregateOutputType | null
  }

  export type TransactionAvgAggregateOutputType = {
    total: number | null
  }

  export type TransactionSumAggregateOutputType = {
    total: number | null
  }

  export type TransactionMinAggregateOutputType = {
    id: string | null
    userId: string | null
    total: number | null
    status: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type TransactionMaxAggregateOutputType = {
    id: string | null
    userId: string | null
    total: number | null
    status: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type TransactionCountAggregateOutputType = {
    id: number
    userId: number
    total: number
    status: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type TransactionAvgAggregateInputType = {
    total?: true
  }

  export type TransactionSumAggregateInputType = {
    total?: true
  }

  export type TransactionMinAggregateInputType = {
    id?: true
    userId?: true
    total?: true
    status?: true
    createdAt?: true
    updatedAt?: true
  }

  export type TransactionMaxAggregateInputType = {
    id?: true
    userId?: true
    total?: true
    status?: true
    createdAt?: true
    updatedAt?: true
  }

  export type TransactionCountAggregateInputType = {
    id?: true
    userId?: true
    total?: true
    status?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type TransactionAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Transaction to aggregate.
     */
    where?: TransactionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Transactions to fetch.
     */
    orderBy?: TransactionOrderByWithRelationInput | TransactionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: TransactionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Transactions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Transactions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Transactions
    **/
    _count?: true | TransactionCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: TransactionAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: TransactionSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: TransactionMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: TransactionMaxAggregateInputType
  }

  export type GetTransactionAggregateType<T extends TransactionAggregateArgs> = {
        [P in keyof T & keyof AggregateTransaction]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateTransaction[P]>
      : GetScalarType<T[P], AggregateTransaction[P]>
  }




  export type TransactionGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TransactionWhereInput
    orderBy?: TransactionOrderByWithAggregationInput | TransactionOrderByWithAggregationInput[]
    by: TransactionScalarFieldEnum[] | TransactionScalarFieldEnum
    having?: TransactionScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: TransactionCountAggregateInputType | true
    _avg?: TransactionAvgAggregateInputType
    _sum?: TransactionSumAggregateInputType
    _min?: TransactionMinAggregateInputType
    _max?: TransactionMaxAggregateInputType
  }

  export type TransactionGroupByOutputType = {
    id: string
    userId: string
    total: number
    status: string
    createdAt: Date
    updatedAt: Date
    _count: TransactionCountAggregateOutputType | null
    _avg: TransactionAvgAggregateOutputType | null
    _sum: TransactionSumAggregateOutputType | null
    _min: TransactionMinAggregateOutputType | null
    _max: TransactionMaxAggregateOutputType | null
  }

  type GetTransactionGroupByPayload<T extends TransactionGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<TransactionGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof TransactionGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], TransactionGroupByOutputType[P]>
            : GetScalarType<T[P], TransactionGroupByOutputType[P]>
        }
      >
    >


  export type TransactionSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    total?: boolean
    status?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    transactionDetails?: boolean | Transaction$transactionDetailsArgs<ExtArgs>
    _count?: boolean | TransactionCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["transaction"]>



  export type TransactionSelectScalar = {
    id?: boolean
    userId?: boolean
    total?: boolean
    status?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type TransactionOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "userId" | "total" | "status" | "createdAt" | "updatedAt", ExtArgs["result"]["transaction"]>
  export type TransactionInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    transactionDetails?: boolean | Transaction$transactionDetailsArgs<ExtArgs>
    _count?: boolean | TransactionCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $TransactionPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Transaction"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
      transactionDetails: Prisma.$TransactionDetailsPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      userId: string
      total: number
      status: string
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["transaction"]>
    composites: {}
  }

  type TransactionGetPayload<S extends boolean | null | undefined | TransactionDefaultArgs> = $Result.GetResult<Prisma.$TransactionPayload, S>

  type TransactionCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<TransactionFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: TransactionCountAggregateInputType | true
    }

  export interface TransactionDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Transaction'], meta: { name: 'Transaction' } }
    /**
     * Find zero or one Transaction that matches the filter.
     * @param {TransactionFindUniqueArgs} args - Arguments to find a Transaction
     * @example
     * // Get one Transaction
     * const transaction = await prisma.transaction.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends TransactionFindUniqueArgs>(args: SelectSubset<T, TransactionFindUniqueArgs<ExtArgs>>): Prisma__TransactionClient<$Result.GetResult<Prisma.$TransactionPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Transaction that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {TransactionFindUniqueOrThrowArgs} args - Arguments to find a Transaction
     * @example
     * // Get one Transaction
     * const transaction = await prisma.transaction.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends TransactionFindUniqueOrThrowArgs>(args: SelectSubset<T, TransactionFindUniqueOrThrowArgs<ExtArgs>>): Prisma__TransactionClient<$Result.GetResult<Prisma.$TransactionPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Transaction that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionFindFirstArgs} args - Arguments to find a Transaction
     * @example
     * // Get one Transaction
     * const transaction = await prisma.transaction.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends TransactionFindFirstArgs>(args?: SelectSubset<T, TransactionFindFirstArgs<ExtArgs>>): Prisma__TransactionClient<$Result.GetResult<Prisma.$TransactionPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Transaction that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionFindFirstOrThrowArgs} args - Arguments to find a Transaction
     * @example
     * // Get one Transaction
     * const transaction = await prisma.transaction.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends TransactionFindFirstOrThrowArgs>(args?: SelectSubset<T, TransactionFindFirstOrThrowArgs<ExtArgs>>): Prisma__TransactionClient<$Result.GetResult<Prisma.$TransactionPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Transactions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Transactions
     * const transactions = await prisma.transaction.findMany()
     * 
     * // Get first 10 Transactions
     * const transactions = await prisma.transaction.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const transactionWithIdOnly = await prisma.transaction.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends TransactionFindManyArgs>(args?: SelectSubset<T, TransactionFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TransactionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Transaction.
     * @param {TransactionCreateArgs} args - Arguments to create a Transaction.
     * @example
     * // Create one Transaction
     * const Transaction = await prisma.transaction.create({
     *   data: {
     *     // ... data to create a Transaction
     *   }
     * })
     * 
     */
    create<T extends TransactionCreateArgs>(args: SelectSubset<T, TransactionCreateArgs<ExtArgs>>): Prisma__TransactionClient<$Result.GetResult<Prisma.$TransactionPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Transactions.
     * @param {TransactionCreateManyArgs} args - Arguments to create many Transactions.
     * @example
     * // Create many Transactions
     * const transaction = await prisma.transaction.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends TransactionCreateManyArgs>(args?: SelectSubset<T, TransactionCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Transaction.
     * @param {TransactionDeleteArgs} args - Arguments to delete one Transaction.
     * @example
     * // Delete one Transaction
     * const Transaction = await prisma.transaction.delete({
     *   where: {
     *     // ... filter to delete one Transaction
     *   }
     * })
     * 
     */
    delete<T extends TransactionDeleteArgs>(args: SelectSubset<T, TransactionDeleteArgs<ExtArgs>>): Prisma__TransactionClient<$Result.GetResult<Prisma.$TransactionPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Transaction.
     * @param {TransactionUpdateArgs} args - Arguments to update one Transaction.
     * @example
     * // Update one Transaction
     * const transaction = await prisma.transaction.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends TransactionUpdateArgs>(args: SelectSubset<T, TransactionUpdateArgs<ExtArgs>>): Prisma__TransactionClient<$Result.GetResult<Prisma.$TransactionPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Transactions.
     * @param {TransactionDeleteManyArgs} args - Arguments to filter Transactions to delete.
     * @example
     * // Delete a few Transactions
     * const { count } = await prisma.transaction.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends TransactionDeleteManyArgs>(args?: SelectSubset<T, TransactionDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Transactions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Transactions
     * const transaction = await prisma.transaction.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends TransactionUpdateManyArgs>(args: SelectSubset<T, TransactionUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Transaction.
     * @param {TransactionUpsertArgs} args - Arguments to update or create a Transaction.
     * @example
     * // Update or create a Transaction
     * const transaction = await prisma.transaction.upsert({
     *   create: {
     *     // ... data to create a Transaction
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Transaction we want to update
     *   }
     * })
     */
    upsert<T extends TransactionUpsertArgs>(args: SelectSubset<T, TransactionUpsertArgs<ExtArgs>>): Prisma__TransactionClient<$Result.GetResult<Prisma.$TransactionPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Transactions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionCountArgs} args - Arguments to filter Transactions to count.
     * @example
     * // Count the number of Transactions
     * const count = await prisma.transaction.count({
     *   where: {
     *     // ... the filter for the Transactions we want to count
     *   }
     * })
    **/
    count<T extends TransactionCountArgs>(
      args?: Subset<T, TransactionCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], TransactionCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Transaction.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends TransactionAggregateArgs>(args: Subset<T, TransactionAggregateArgs>): Prisma.PrismaPromise<GetTransactionAggregateType<T>>

    /**
     * Group by Transaction.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends TransactionGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: TransactionGroupByArgs['orderBy'] }
        : { orderBy?: TransactionGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, TransactionGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetTransactionGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Transaction model
   */
  readonly fields: TransactionFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Transaction.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__TransactionClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    transactionDetails<T extends Transaction$transactionDetailsArgs<ExtArgs> = {}>(args?: Subset<T, Transaction$transactionDetailsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TransactionDetailsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Transaction model
   */
  interface TransactionFieldRefs {
    readonly id: FieldRef<"Transaction", 'String'>
    readonly userId: FieldRef<"Transaction", 'String'>
    readonly total: FieldRef<"Transaction", 'Int'>
    readonly status: FieldRef<"Transaction", 'String'>
    readonly createdAt: FieldRef<"Transaction", 'DateTime'>
    readonly updatedAt: FieldRef<"Transaction", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Transaction findUnique
   */
  export type TransactionFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Transaction
     */
    select?: TransactionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Transaction
     */
    omit?: TransactionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionInclude<ExtArgs> | null
    /**
     * Filter, which Transaction to fetch.
     */
    where: TransactionWhereUniqueInput
  }

  /**
   * Transaction findUniqueOrThrow
   */
  export type TransactionFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Transaction
     */
    select?: TransactionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Transaction
     */
    omit?: TransactionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionInclude<ExtArgs> | null
    /**
     * Filter, which Transaction to fetch.
     */
    where: TransactionWhereUniqueInput
  }

  /**
   * Transaction findFirst
   */
  export type TransactionFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Transaction
     */
    select?: TransactionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Transaction
     */
    omit?: TransactionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionInclude<ExtArgs> | null
    /**
     * Filter, which Transaction to fetch.
     */
    where?: TransactionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Transactions to fetch.
     */
    orderBy?: TransactionOrderByWithRelationInput | TransactionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Transactions.
     */
    cursor?: TransactionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Transactions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Transactions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Transactions.
     */
    distinct?: TransactionScalarFieldEnum | TransactionScalarFieldEnum[]
  }

  /**
   * Transaction findFirstOrThrow
   */
  export type TransactionFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Transaction
     */
    select?: TransactionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Transaction
     */
    omit?: TransactionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionInclude<ExtArgs> | null
    /**
     * Filter, which Transaction to fetch.
     */
    where?: TransactionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Transactions to fetch.
     */
    orderBy?: TransactionOrderByWithRelationInput | TransactionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Transactions.
     */
    cursor?: TransactionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Transactions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Transactions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Transactions.
     */
    distinct?: TransactionScalarFieldEnum | TransactionScalarFieldEnum[]
  }

  /**
   * Transaction findMany
   */
  export type TransactionFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Transaction
     */
    select?: TransactionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Transaction
     */
    omit?: TransactionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionInclude<ExtArgs> | null
    /**
     * Filter, which Transactions to fetch.
     */
    where?: TransactionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Transactions to fetch.
     */
    orderBy?: TransactionOrderByWithRelationInput | TransactionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Transactions.
     */
    cursor?: TransactionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Transactions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Transactions.
     */
    skip?: number
    distinct?: TransactionScalarFieldEnum | TransactionScalarFieldEnum[]
  }

  /**
   * Transaction create
   */
  export type TransactionCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Transaction
     */
    select?: TransactionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Transaction
     */
    omit?: TransactionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionInclude<ExtArgs> | null
    /**
     * The data needed to create a Transaction.
     */
    data: XOR<TransactionCreateInput, TransactionUncheckedCreateInput>
  }

  /**
   * Transaction createMany
   */
  export type TransactionCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Transactions.
     */
    data: TransactionCreateManyInput | TransactionCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Transaction update
   */
  export type TransactionUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Transaction
     */
    select?: TransactionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Transaction
     */
    omit?: TransactionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionInclude<ExtArgs> | null
    /**
     * The data needed to update a Transaction.
     */
    data: XOR<TransactionUpdateInput, TransactionUncheckedUpdateInput>
    /**
     * Choose, which Transaction to update.
     */
    where: TransactionWhereUniqueInput
  }

  /**
   * Transaction updateMany
   */
  export type TransactionUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Transactions.
     */
    data: XOR<TransactionUpdateManyMutationInput, TransactionUncheckedUpdateManyInput>
    /**
     * Filter which Transactions to update
     */
    where?: TransactionWhereInput
    /**
     * Limit how many Transactions to update.
     */
    limit?: number
  }

  /**
   * Transaction upsert
   */
  export type TransactionUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Transaction
     */
    select?: TransactionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Transaction
     */
    omit?: TransactionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionInclude<ExtArgs> | null
    /**
     * The filter to search for the Transaction to update in case it exists.
     */
    where: TransactionWhereUniqueInput
    /**
     * In case the Transaction found by the `where` argument doesn't exist, create a new Transaction with this data.
     */
    create: XOR<TransactionCreateInput, TransactionUncheckedCreateInput>
    /**
     * In case the Transaction was found with the provided `where` argument, update it with this data.
     */
    update: XOR<TransactionUpdateInput, TransactionUncheckedUpdateInput>
  }

  /**
   * Transaction delete
   */
  export type TransactionDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Transaction
     */
    select?: TransactionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Transaction
     */
    omit?: TransactionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionInclude<ExtArgs> | null
    /**
     * Filter which Transaction to delete.
     */
    where: TransactionWhereUniqueInput
  }

  /**
   * Transaction deleteMany
   */
  export type TransactionDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Transactions to delete
     */
    where?: TransactionWhereInput
    /**
     * Limit how many Transactions to delete.
     */
    limit?: number
  }

  /**
   * Transaction.transactionDetails
   */
  export type Transaction$transactionDetailsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TransactionDetails
     */
    select?: TransactionDetailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TransactionDetails
     */
    omit?: TransactionDetailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionDetailsInclude<ExtArgs> | null
    where?: TransactionDetailsWhereInput
    orderBy?: TransactionDetailsOrderByWithRelationInput | TransactionDetailsOrderByWithRelationInput[]
    cursor?: TransactionDetailsWhereUniqueInput
    take?: number
    skip?: number
    distinct?: TransactionDetailsScalarFieldEnum | TransactionDetailsScalarFieldEnum[]
  }

  /**
   * Transaction without action
   */
  export type TransactionDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Transaction
     */
    select?: TransactionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Transaction
     */
    omit?: TransactionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionInclude<ExtArgs> | null
  }


  /**
   * Model TransactionDetails
   */

  export type AggregateTransactionDetails = {
    _count: TransactionDetailsCountAggregateOutputType | null
    _avg: TransactionDetailsAvgAggregateOutputType | null
    _sum: TransactionDetailsSumAggregateOutputType | null
    _min: TransactionDetailsMinAggregateOutputType | null
    _max: TransactionDetailsMaxAggregateOutputType | null
  }

  export type TransactionDetailsAvgAggregateOutputType = {
    purchasedPrice: number | null
    quantity: number | null
    subtotal: number | null
  }

  export type TransactionDetailsSumAggregateOutputType = {
    purchasedPrice: number | null
    quantity: number | null
    subtotal: number | null
  }

  export type TransactionDetailsMinAggregateOutputType = {
    id: string | null
    transactionId: string | null
    productId: string | null
    purchasedPrice: number | null
    quantity: number | null
    subtotal: number | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type TransactionDetailsMaxAggregateOutputType = {
    id: string | null
    transactionId: string | null
    productId: string | null
    purchasedPrice: number | null
    quantity: number | null
    subtotal: number | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type TransactionDetailsCountAggregateOutputType = {
    id: number
    transactionId: number
    productId: number
    purchasedPrice: number
    quantity: number
    subtotal: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type TransactionDetailsAvgAggregateInputType = {
    purchasedPrice?: true
    quantity?: true
    subtotal?: true
  }

  export type TransactionDetailsSumAggregateInputType = {
    purchasedPrice?: true
    quantity?: true
    subtotal?: true
  }

  export type TransactionDetailsMinAggregateInputType = {
    id?: true
    transactionId?: true
    productId?: true
    purchasedPrice?: true
    quantity?: true
    subtotal?: true
    createdAt?: true
    updatedAt?: true
  }

  export type TransactionDetailsMaxAggregateInputType = {
    id?: true
    transactionId?: true
    productId?: true
    purchasedPrice?: true
    quantity?: true
    subtotal?: true
    createdAt?: true
    updatedAt?: true
  }

  export type TransactionDetailsCountAggregateInputType = {
    id?: true
    transactionId?: true
    productId?: true
    purchasedPrice?: true
    quantity?: true
    subtotal?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type TransactionDetailsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which TransactionDetails to aggregate.
     */
    where?: TransactionDetailsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TransactionDetails to fetch.
     */
    orderBy?: TransactionDetailsOrderByWithRelationInput | TransactionDetailsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: TransactionDetailsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TransactionDetails from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TransactionDetails.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned TransactionDetails
    **/
    _count?: true | TransactionDetailsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: TransactionDetailsAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: TransactionDetailsSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: TransactionDetailsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: TransactionDetailsMaxAggregateInputType
  }

  export type GetTransactionDetailsAggregateType<T extends TransactionDetailsAggregateArgs> = {
        [P in keyof T & keyof AggregateTransactionDetails]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateTransactionDetails[P]>
      : GetScalarType<T[P], AggregateTransactionDetails[P]>
  }




  export type TransactionDetailsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TransactionDetailsWhereInput
    orderBy?: TransactionDetailsOrderByWithAggregationInput | TransactionDetailsOrderByWithAggregationInput[]
    by: TransactionDetailsScalarFieldEnum[] | TransactionDetailsScalarFieldEnum
    having?: TransactionDetailsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: TransactionDetailsCountAggregateInputType | true
    _avg?: TransactionDetailsAvgAggregateInputType
    _sum?: TransactionDetailsSumAggregateInputType
    _min?: TransactionDetailsMinAggregateInputType
    _max?: TransactionDetailsMaxAggregateInputType
  }

  export type TransactionDetailsGroupByOutputType = {
    id: string
    transactionId: string
    productId: string
    purchasedPrice: number
    quantity: number
    subtotal: number
    createdAt: Date
    updatedAt: Date
    _count: TransactionDetailsCountAggregateOutputType | null
    _avg: TransactionDetailsAvgAggregateOutputType | null
    _sum: TransactionDetailsSumAggregateOutputType | null
    _min: TransactionDetailsMinAggregateOutputType | null
    _max: TransactionDetailsMaxAggregateOutputType | null
  }

  type GetTransactionDetailsGroupByPayload<T extends TransactionDetailsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<TransactionDetailsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof TransactionDetailsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], TransactionDetailsGroupByOutputType[P]>
            : GetScalarType<T[P], TransactionDetailsGroupByOutputType[P]>
        }
      >
    >


  export type TransactionDetailsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    transactionId?: boolean
    productId?: boolean
    purchasedPrice?: boolean
    quantity?: boolean
    subtotal?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    transaction?: boolean | TransactionDefaultArgs<ExtArgs>
    product?: boolean | ProductDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["transactionDetails"]>



  export type TransactionDetailsSelectScalar = {
    id?: boolean
    transactionId?: boolean
    productId?: boolean
    purchasedPrice?: boolean
    quantity?: boolean
    subtotal?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type TransactionDetailsOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "transactionId" | "productId" | "purchasedPrice" | "quantity" | "subtotal" | "createdAt" | "updatedAt", ExtArgs["result"]["transactionDetails"]>
  export type TransactionDetailsInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    transaction?: boolean | TransactionDefaultArgs<ExtArgs>
    product?: boolean | ProductDefaultArgs<ExtArgs>
  }

  export type $TransactionDetailsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "TransactionDetails"
    objects: {
      transaction: Prisma.$TransactionPayload<ExtArgs>
      product: Prisma.$ProductPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      transactionId: string
      productId: string
      purchasedPrice: number
      quantity: number
      subtotal: number
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["transactionDetails"]>
    composites: {}
  }

  type TransactionDetailsGetPayload<S extends boolean | null | undefined | TransactionDetailsDefaultArgs> = $Result.GetResult<Prisma.$TransactionDetailsPayload, S>

  type TransactionDetailsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<TransactionDetailsFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: TransactionDetailsCountAggregateInputType | true
    }

  export interface TransactionDetailsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['TransactionDetails'], meta: { name: 'TransactionDetails' } }
    /**
     * Find zero or one TransactionDetails that matches the filter.
     * @param {TransactionDetailsFindUniqueArgs} args - Arguments to find a TransactionDetails
     * @example
     * // Get one TransactionDetails
     * const transactionDetails = await prisma.transactionDetails.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends TransactionDetailsFindUniqueArgs>(args: SelectSubset<T, TransactionDetailsFindUniqueArgs<ExtArgs>>): Prisma__TransactionDetailsClient<$Result.GetResult<Prisma.$TransactionDetailsPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one TransactionDetails that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {TransactionDetailsFindUniqueOrThrowArgs} args - Arguments to find a TransactionDetails
     * @example
     * // Get one TransactionDetails
     * const transactionDetails = await prisma.transactionDetails.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends TransactionDetailsFindUniqueOrThrowArgs>(args: SelectSubset<T, TransactionDetailsFindUniqueOrThrowArgs<ExtArgs>>): Prisma__TransactionDetailsClient<$Result.GetResult<Prisma.$TransactionDetailsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first TransactionDetails that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionDetailsFindFirstArgs} args - Arguments to find a TransactionDetails
     * @example
     * // Get one TransactionDetails
     * const transactionDetails = await prisma.transactionDetails.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends TransactionDetailsFindFirstArgs>(args?: SelectSubset<T, TransactionDetailsFindFirstArgs<ExtArgs>>): Prisma__TransactionDetailsClient<$Result.GetResult<Prisma.$TransactionDetailsPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first TransactionDetails that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionDetailsFindFirstOrThrowArgs} args - Arguments to find a TransactionDetails
     * @example
     * // Get one TransactionDetails
     * const transactionDetails = await prisma.transactionDetails.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends TransactionDetailsFindFirstOrThrowArgs>(args?: SelectSubset<T, TransactionDetailsFindFirstOrThrowArgs<ExtArgs>>): Prisma__TransactionDetailsClient<$Result.GetResult<Prisma.$TransactionDetailsPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more TransactionDetails that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionDetailsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all TransactionDetails
     * const transactionDetails = await prisma.transactionDetails.findMany()
     * 
     * // Get first 10 TransactionDetails
     * const transactionDetails = await prisma.transactionDetails.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const transactionDetailsWithIdOnly = await prisma.transactionDetails.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends TransactionDetailsFindManyArgs>(args?: SelectSubset<T, TransactionDetailsFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TransactionDetailsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a TransactionDetails.
     * @param {TransactionDetailsCreateArgs} args - Arguments to create a TransactionDetails.
     * @example
     * // Create one TransactionDetails
     * const TransactionDetails = await prisma.transactionDetails.create({
     *   data: {
     *     // ... data to create a TransactionDetails
     *   }
     * })
     * 
     */
    create<T extends TransactionDetailsCreateArgs>(args: SelectSubset<T, TransactionDetailsCreateArgs<ExtArgs>>): Prisma__TransactionDetailsClient<$Result.GetResult<Prisma.$TransactionDetailsPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many TransactionDetails.
     * @param {TransactionDetailsCreateManyArgs} args - Arguments to create many TransactionDetails.
     * @example
     * // Create many TransactionDetails
     * const transactionDetails = await prisma.transactionDetails.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends TransactionDetailsCreateManyArgs>(args?: SelectSubset<T, TransactionDetailsCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a TransactionDetails.
     * @param {TransactionDetailsDeleteArgs} args - Arguments to delete one TransactionDetails.
     * @example
     * // Delete one TransactionDetails
     * const TransactionDetails = await prisma.transactionDetails.delete({
     *   where: {
     *     // ... filter to delete one TransactionDetails
     *   }
     * })
     * 
     */
    delete<T extends TransactionDetailsDeleteArgs>(args: SelectSubset<T, TransactionDetailsDeleteArgs<ExtArgs>>): Prisma__TransactionDetailsClient<$Result.GetResult<Prisma.$TransactionDetailsPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one TransactionDetails.
     * @param {TransactionDetailsUpdateArgs} args - Arguments to update one TransactionDetails.
     * @example
     * // Update one TransactionDetails
     * const transactionDetails = await prisma.transactionDetails.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends TransactionDetailsUpdateArgs>(args: SelectSubset<T, TransactionDetailsUpdateArgs<ExtArgs>>): Prisma__TransactionDetailsClient<$Result.GetResult<Prisma.$TransactionDetailsPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more TransactionDetails.
     * @param {TransactionDetailsDeleteManyArgs} args - Arguments to filter TransactionDetails to delete.
     * @example
     * // Delete a few TransactionDetails
     * const { count } = await prisma.transactionDetails.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends TransactionDetailsDeleteManyArgs>(args?: SelectSubset<T, TransactionDetailsDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more TransactionDetails.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionDetailsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many TransactionDetails
     * const transactionDetails = await prisma.transactionDetails.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends TransactionDetailsUpdateManyArgs>(args: SelectSubset<T, TransactionDetailsUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one TransactionDetails.
     * @param {TransactionDetailsUpsertArgs} args - Arguments to update or create a TransactionDetails.
     * @example
     * // Update or create a TransactionDetails
     * const transactionDetails = await prisma.transactionDetails.upsert({
     *   create: {
     *     // ... data to create a TransactionDetails
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the TransactionDetails we want to update
     *   }
     * })
     */
    upsert<T extends TransactionDetailsUpsertArgs>(args: SelectSubset<T, TransactionDetailsUpsertArgs<ExtArgs>>): Prisma__TransactionDetailsClient<$Result.GetResult<Prisma.$TransactionDetailsPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of TransactionDetails.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionDetailsCountArgs} args - Arguments to filter TransactionDetails to count.
     * @example
     * // Count the number of TransactionDetails
     * const count = await prisma.transactionDetails.count({
     *   where: {
     *     // ... the filter for the TransactionDetails we want to count
     *   }
     * })
    **/
    count<T extends TransactionDetailsCountArgs>(
      args?: Subset<T, TransactionDetailsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], TransactionDetailsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a TransactionDetails.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionDetailsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends TransactionDetailsAggregateArgs>(args: Subset<T, TransactionDetailsAggregateArgs>): Prisma.PrismaPromise<GetTransactionDetailsAggregateType<T>>

    /**
     * Group by TransactionDetails.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionDetailsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends TransactionDetailsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: TransactionDetailsGroupByArgs['orderBy'] }
        : { orderBy?: TransactionDetailsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, TransactionDetailsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetTransactionDetailsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the TransactionDetails model
   */
  readonly fields: TransactionDetailsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for TransactionDetails.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__TransactionDetailsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    transaction<T extends TransactionDefaultArgs<ExtArgs> = {}>(args?: Subset<T, TransactionDefaultArgs<ExtArgs>>): Prisma__TransactionClient<$Result.GetResult<Prisma.$TransactionPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    product<T extends ProductDefaultArgs<ExtArgs> = {}>(args?: Subset<T, ProductDefaultArgs<ExtArgs>>): Prisma__ProductClient<$Result.GetResult<Prisma.$ProductPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the TransactionDetails model
   */
  interface TransactionDetailsFieldRefs {
    readonly id: FieldRef<"TransactionDetails", 'String'>
    readonly transactionId: FieldRef<"TransactionDetails", 'String'>
    readonly productId: FieldRef<"TransactionDetails", 'String'>
    readonly purchasedPrice: FieldRef<"TransactionDetails", 'Int'>
    readonly quantity: FieldRef<"TransactionDetails", 'Int'>
    readonly subtotal: FieldRef<"TransactionDetails", 'Int'>
    readonly createdAt: FieldRef<"TransactionDetails", 'DateTime'>
    readonly updatedAt: FieldRef<"TransactionDetails", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * TransactionDetails findUnique
   */
  export type TransactionDetailsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TransactionDetails
     */
    select?: TransactionDetailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TransactionDetails
     */
    omit?: TransactionDetailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionDetailsInclude<ExtArgs> | null
    /**
     * Filter, which TransactionDetails to fetch.
     */
    where: TransactionDetailsWhereUniqueInput
  }

  /**
   * TransactionDetails findUniqueOrThrow
   */
  export type TransactionDetailsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TransactionDetails
     */
    select?: TransactionDetailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TransactionDetails
     */
    omit?: TransactionDetailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionDetailsInclude<ExtArgs> | null
    /**
     * Filter, which TransactionDetails to fetch.
     */
    where: TransactionDetailsWhereUniqueInput
  }

  /**
   * TransactionDetails findFirst
   */
  export type TransactionDetailsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TransactionDetails
     */
    select?: TransactionDetailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TransactionDetails
     */
    omit?: TransactionDetailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionDetailsInclude<ExtArgs> | null
    /**
     * Filter, which TransactionDetails to fetch.
     */
    where?: TransactionDetailsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TransactionDetails to fetch.
     */
    orderBy?: TransactionDetailsOrderByWithRelationInput | TransactionDetailsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for TransactionDetails.
     */
    cursor?: TransactionDetailsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TransactionDetails from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TransactionDetails.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of TransactionDetails.
     */
    distinct?: TransactionDetailsScalarFieldEnum | TransactionDetailsScalarFieldEnum[]
  }

  /**
   * TransactionDetails findFirstOrThrow
   */
  export type TransactionDetailsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TransactionDetails
     */
    select?: TransactionDetailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TransactionDetails
     */
    omit?: TransactionDetailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionDetailsInclude<ExtArgs> | null
    /**
     * Filter, which TransactionDetails to fetch.
     */
    where?: TransactionDetailsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TransactionDetails to fetch.
     */
    orderBy?: TransactionDetailsOrderByWithRelationInput | TransactionDetailsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for TransactionDetails.
     */
    cursor?: TransactionDetailsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TransactionDetails from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TransactionDetails.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of TransactionDetails.
     */
    distinct?: TransactionDetailsScalarFieldEnum | TransactionDetailsScalarFieldEnum[]
  }

  /**
   * TransactionDetails findMany
   */
  export type TransactionDetailsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TransactionDetails
     */
    select?: TransactionDetailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TransactionDetails
     */
    omit?: TransactionDetailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionDetailsInclude<ExtArgs> | null
    /**
     * Filter, which TransactionDetails to fetch.
     */
    where?: TransactionDetailsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TransactionDetails to fetch.
     */
    orderBy?: TransactionDetailsOrderByWithRelationInput | TransactionDetailsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing TransactionDetails.
     */
    cursor?: TransactionDetailsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TransactionDetails from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TransactionDetails.
     */
    skip?: number
    distinct?: TransactionDetailsScalarFieldEnum | TransactionDetailsScalarFieldEnum[]
  }

  /**
   * TransactionDetails create
   */
  export type TransactionDetailsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TransactionDetails
     */
    select?: TransactionDetailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TransactionDetails
     */
    omit?: TransactionDetailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionDetailsInclude<ExtArgs> | null
    /**
     * The data needed to create a TransactionDetails.
     */
    data: XOR<TransactionDetailsCreateInput, TransactionDetailsUncheckedCreateInput>
  }

  /**
   * TransactionDetails createMany
   */
  export type TransactionDetailsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many TransactionDetails.
     */
    data: TransactionDetailsCreateManyInput | TransactionDetailsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * TransactionDetails update
   */
  export type TransactionDetailsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TransactionDetails
     */
    select?: TransactionDetailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TransactionDetails
     */
    omit?: TransactionDetailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionDetailsInclude<ExtArgs> | null
    /**
     * The data needed to update a TransactionDetails.
     */
    data: XOR<TransactionDetailsUpdateInput, TransactionDetailsUncheckedUpdateInput>
    /**
     * Choose, which TransactionDetails to update.
     */
    where: TransactionDetailsWhereUniqueInput
  }

  /**
   * TransactionDetails updateMany
   */
  export type TransactionDetailsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update TransactionDetails.
     */
    data: XOR<TransactionDetailsUpdateManyMutationInput, TransactionDetailsUncheckedUpdateManyInput>
    /**
     * Filter which TransactionDetails to update
     */
    where?: TransactionDetailsWhereInput
    /**
     * Limit how many TransactionDetails to update.
     */
    limit?: number
  }

  /**
   * TransactionDetails upsert
   */
  export type TransactionDetailsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TransactionDetails
     */
    select?: TransactionDetailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TransactionDetails
     */
    omit?: TransactionDetailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionDetailsInclude<ExtArgs> | null
    /**
     * The filter to search for the TransactionDetails to update in case it exists.
     */
    where: TransactionDetailsWhereUniqueInput
    /**
     * In case the TransactionDetails found by the `where` argument doesn't exist, create a new TransactionDetails with this data.
     */
    create: XOR<TransactionDetailsCreateInput, TransactionDetailsUncheckedCreateInput>
    /**
     * In case the TransactionDetails was found with the provided `where` argument, update it with this data.
     */
    update: XOR<TransactionDetailsUpdateInput, TransactionDetailsUncheckedUpdateInput>
  }

  /**
   * TransactionDetails delete
   */
  export type TransactionDetailsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TransactionDetails
     */
    select?: TransactionDetailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TransactionDetails
     */
    omit?: TransactionDetailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionDetailsInclude<ExtArgs> | null
    /**
     * Filter which TransactionDetails to delete.
     */
    where: TransactionDetailsWhereUniqueInput
  }

  /**
   * TransactionDetails deleteMany
   */
  export type TransactionDetailsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which TransactionDetails to delete
     */
    where?: TransactionDetailsWhereInput
    /**
     * Limit how many TransactionDetails to delete.
     */
    limit?: number
  }

  /**
   * TransactionDetails without action
   */
  export type TransactionDetailsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TransactionDetails
     */
    select?: TransactionDetailsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TransactionDetails
     */
    omit?: TransactionDetailsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionDetailsInclude<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const AdminScalarFieldEnum: {
    id: 'id',
    name: 'name',
    email: 'email',
    password: 'password',
    role: 'role',
    status: 'status',
    isPasswordChanged: 'isPasswordChanged',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type AdminScalarFieldEnum = (typeof AdminScalarFieldEnum)[keyof typeof AdminScalarFieldEnum]


  export const UserScalarFieldEnum: {
    id: 'id',
    name: 'name',
    email: 'email',
    password: 'password',
    status: 'status',
    profile: 'profile',
    balance: 'balance',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type UserScalarFieldEnum = (typeof UserScalarFieldEnum)[keyof typeof UserScalarFieldEnum]


  export const UserVerificationTokenScalarFieldEnum: {
    id: 'id',
    token: 'token',
    userId: 'userId',
    purpose: 'purpose',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt',
    expiredAt: 'expiredAt'
  };

  export type UserVerificationTokenScalarFieldEnum = (typeof UserVerificationTokenScalarFieldEnum)[keyof typeof UserVerificationTokenScalarFieldEnum]


  export const CategoryScalarFieldEnum: {
    id: 'id',
    name: 'name',
    status: 'status',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type CategoryScalarFieldEnum = (typeof CategoryScalarFieldEnum)[keyof typeof CategoryScalarFieldEnum]


  export const ProductScalarFieldEnum: {
    id: 'id',
    categoryId: 'categoryId',
    name: 'name',
    status: 'status',
    price: 'price',
    stock: 'stock',
    description: 'description',
    imageFileName: 'imageFileName',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type ProductScalarFieldEnum = (typeof ProductScalarFieldEnum)[keyof typeof ProductScalarFieldEnum]


  export const StockMutationScalarFieldEnum: {
    id: 'id',
    productId: 'productId',
    currentStock: 'currentStock',
    quantity: 'quantity',
    type: 'type',
    notes: 'notes',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type StockMutationScalarFieldEnum = (typeof StockMutationScalarFieldEnum)[keyof typeof StockMutationScalarFieldEnum]


  export const PaymentTermScalarFieldEnum: {
    id: 'id',
    name: 'name',
    status: 'status',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type PaymentTermScalarFieldEnum = (typeof PaymentTermScalarFieldEnum)[keyof typeof PaymentTermScalarFieldEnum]


  export const PaymentAccountScalarFieldEnum: {
    id: 'id',
    paymentTermId: 'paymentTermId',
    accountHolderName: 'accountHolderName',
    accountNumber: 'accountNumber',
    status: 'status',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type PaymentAccountScalarFieldEnum = (typeof PaymentAccountScalarFieldEnum)[keyof typeof PaymentAccountScalarFieldEnum]


  export const WishlistScalarFieldEnum: {
    id: 'id',
    userId: 'userId',
    productId: 'productId',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type WishlistScalarFieldEnum = (typeof WishlistScalarFieldEnum)[keyof typeof WishlistScalarFieldEnum]


  export const TopUpScalarFieldEnum: {
    id: 'id',
    nominal: 'nominal',
    adminId: 'adminId',
    userId: 'userId',
    proofOfTransferFileName: 'proofOfTransferFileName',
    status: 'status',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt',
    paymentAccountId: 'paymentAccountId',
    paymentTermId: 'paymentTermId'
  };

  export type TopUpScalarFieldEnum = (typeof TopUpScalarFieldEnum)[keyof typeof TopUpScalarFieldEnum]


  export const TransactionScalarFieldEnum: {
    id: 'id',
    userId: 'userId',
    total: 'total',
    status: 'status',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type TransactionScalarFieldEnum = (typeof TransactionScalarFieldEnum)[keyof typeof TransactionScalarFieldEnum]


  export const TransactionDetailsScalarFieldEnum: {
    id: 'id',
    transactionId: 'transactionId',
    productId: 'productId',
    purchasedPrice: 'purchasedPrice',
    quantity: 'quantity',
    subtotal: 'subtotal',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type TransactionDetailsScalarFieldEnum = (typeof TransactionDetailsScalarFieldEnum)[keyof typeof TransactionDetailsScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const AdminOrderByRelevanceFieldEnum: {
    id: 'id',
    name: 'name',
    email: 'email',
    password: 'password',
    role: 'role',
    status: 'status'
  };

  export type AdminOrderByRelevanceFieldEnum = (typeof AdminOrderByRelevanceFieldEnum)[keyof typeof AdminOrderByRelevanceFieldEnum]


  export const UserOrderByRelevanceFieldEnum: {
    id: 'id',
    name: 'name',
    email: 'email',
    password: 'password',
    status: 'status',
    profile: 'profile'
  };

  export type UserOrderByRelevanceFieldEnum = (typeof UserOrderByRelevanceFieldEnum)[keyof typeof UserOrderByRelevanceFieldEnum]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  export const UserVerificationTokenOrderByRelevanceFieldEnum: {
    id: 'id',
    token: 'token',
    userId: 'userId',
    purpose: 'purpose'
  };

  export type UserVerificationTokenOrderByRelevanceFieldEnum = (typeof UserVerificationTokenOrderByRelevanceFieldEnum)[keyof typeof UserVerificationTokenOrderByRelevanceFieldEnum]


  export const CategoryOrderByRelevanceFieldEnum: {
    id: 'id',
    name: 'name',
    status: 'status'
  };

  export type CategoryOrderByRelevanceFieldEnum = (typeof CategoryOrderByRelevanceFieldEnum)[keyof typeof CategoryOrderByRelevanceFieldEnum]


  export const ProductOrderByRelevanceFieldEnum: {
    id: 'id',
    categoryId: 'categoryId',
    name: 'name',
    status: 'status',
    description: 'description',
    imageFileName: 'imageFileName'
  };

  export type ProductOrderByRelevanceFieldEnum = (typeof ProductOrderByRelevanceFieldEnum)[keyof typeof ProductOrderByRelevanceFieldEnum]


  export const StockMutationOrderByRelevanceFieldEnum: {
    id: 'id',
    productId: 'productId',
    type: 'type',
    notes: 'notes'
  };

  export type StockMutationOrderByRelevanceFieldEnum = (typeof StockMutationOrderByRelevanceFieldEnum)[keyof typeof StockMutationOrderByRelevanceFieldEnum]


  export const PaymentTermOrderByRelevanceFieldEnum: {
    id: 'id',
    name: 'name',
    status: 'status'
  };

  export type PaymentTermOrderByRelevanceFieldEnum = (typeof PaymentTermOrderByRelevanceFieldEnum)[keyof typeof PaymentTermOrderByRelevanceFieldEnum]


  export const PaymentAccountOrderByRelevanceFieldEnum: {
    id: 'id',
    paymentTermId: 'paymentTermId',
    accountHolderName: 'accountHolderName',
    accountNumber: 'accountNumber',
    status: 'status'
  };

  export type PaymentAccountOrderByRelevanceFieldEnum = (typeof PaymentAccountOrderByRelevanceFieldEnum)[keyof typeof PaymentAccountOrderByRelevanceFieldEnum]


  export const WishlistOrderByRelevanceFieldEnum: {
    id: 'id',
    userId: 'userId',
    productId: 'productId'
  };

  export type WishlistOrderByRelevanceFieldEnum = (typeof WishlistOrderByRelevanceFieldEnum)[keyof typeof WishlistOrderByRelevanceFieldEnum]


  export const TopUpOrderByRelevanceFieldEnum: {
    id: 'id',
    adminId: 'adminId',
    userId: 'userId',
    proofOfTransferFileName: 'proofOfTransferFileName',
    status: 'status',
    paymentAccountId: 'paymentAccountId',
    paymentTermId: 'paymentTermId'
  };

  export type TopUpOrderByRelevanceFieldEnum = (typeof TopUpOrderByRelevanceFieldEnum)[keyof typeof TopUpOrderByRelevanceFieldEnum]


  export const TransactionOrderByRelevanceFieldEnum: {
    id: 'id',
    userId: 'userId',
    status: 'status'
  };

  export type TransactionOrderByRelevanceFieldEnum = (typeof TransactionOrderByRelevanceFieldEnum)[keyof typeof TransactionOrderByRelevanceFieldEnum]


  export const TransactionDetailsOrderByRelevanceFieldEnum: {
    id: 'id',
    transactionId: 'transactionId',
    productId: 'productId'
  };

  export type TransactionDetailsOrderByRelevanceFieldEnum = (typeof TransactionDetailsOrderByRelevanceFieldEnum)[keyof typeof TransactionDetailsOrderByRelevanceFieldEnum]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'Boolean'
   */
  export type BooleanFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Boolean'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    
  /**
   * Deep Input Types
   */


  export type AdminWhereInput = {
    AND?: AdminWhereInput | AdminWhereInput[]
    OR?: AdminWhereInput[]
    NOT?: AdminWhereInput | AdminWhereInput[]
    id?: StringFilter<"Admin"> | string
    name?: StringFilter<"Admin"> | string
    email?: StringFilter<"Admin"> | string
    password?: StringFilter<"Admin"> | string
    role?: StringFilter<"Admin"> | string
    status?: StringFilter<"Admin"> | string
    isPasswordChanged?: BoolFilter<"Admin"> | boolean
    createdAt?: DateTimeFilter<"Admin"> | Date | string
    updatedAt?: DateTimeFilter<"Admin"> | Date | string
    topUps?: TopUpListRelationFilter
  }

  export type AdminOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    password?: SortOrder
    role?: SortOrder
    status?: SortOrder
    isPasswordChanged?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    topUps?: TopUpOrderByRelationAggregateInput
    _relevance?: AdminOrderByRelevanceInput
  }

  export type AdminWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: AdminWhereInput | AdminWhereInput[]
    OR?: AdminWhereInput[]
    NOT?: AdminWhereInput | AdminWhereInput[]
    name?: StringFilter<"Admin"> | string
    email?: StringFilter<"Admin"> | string
    password?: StringFilter<"Admin"> | string
    role?: StringFilter<"Admin"> | string
    status?: StringFilter<"Admin"> | string
    isPasswordChanged?: BoolFilter<"Admin"> | boolean
    createdAt?: DateTimeFilter<"Admin"> | Date | string
    updatedAt?: DateTimeFilter<"Admin"> | Date | string
    topUps?: TopUpListRelationFilter
  }, "id">

  export type AdminOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    password?: SortOrder
    role?: SortOrder
    status?: SortOrder
    isPasswordChanged?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: AdminCountOrderByAggregateInput
    _max?: AdminMaxOrderByAggregateInput
    _min?: AdminMinOrderByAggregateInput
  }

  export type AdminScalarWhereWithAggregatesInput = {
    AND?: AdminScalarWhereWithAggregatesInput | AdminScalarWhereWithAggregatesInput[]
    OR?: AdminScalarWhereWithAggregatesInput[]
    NOT?: AdminScalarWhereWithAggregatesInput | AdminScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Admin"> | string
    name?: StringWithAggregatesFilter<"Admin"> | string
    email?: StringWithAggregatesFilter<"Admin"> | string
    password?: StringWithAggregatesFilter<"Admin"> | string
    role?: StringWithAggregatesFilter<"Admin"> | string
    status?: StringWithAggregatesFilter<"Admin"> | string
    isPasswordChanged?: BoolWithAggregatesFilter<"Admin"> | boolean
    createdAt?: DateTimeWithAggregatesFilter<"Admin"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"Admin"> | Date | string
  }

  export type UserWhereInput = {
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    id?: StringFilter<"User"> | string
    name?: StringFilter<"User"> | string
    email?: StringFilter<"User"> | string
    password?: StringFilter<"User"> | string
    status?: StringFilter<"User"> | string
    profile?: StringFilter<"User"> | string
    balance?: IntFilter<"User"> | number
    createdAt?: DateTimeFilter<"User"> | Date | string
    updatedAt?: DateTimeFilter<"User"> | Date | string
    wishlists?: WishlistListRelationFilter
    topUp?: TopUpListRelationFilter
    transactions?: TransactionListRelationFilter
    userVerificationTokens?: UserVerificationTokenListRelationFilter
  }

  export type UserOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    password?: SortOrder
    status?: SortOrder
    profile?: SortOrder
    balance?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    wishlists?: WishlistOrderByRelationAggregateInput
    topUp?: TopUpOrderByRelationAggregateInput
    transactions?: TransactionOrderByRelationAggregateInput
    userVerificationTokens?: UserVerificationTokenOrderByRelationAggregateInput
    _relevance?: UserOrderByRelevanceInput
  }

  export type UserWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    name?: StringFilter<"User"> | string
    email?: StringFilter<"User"> | string
    password?: StringFilter<"User"> | string
    status?: StringFilter<"User"> | string
    profile?: StringFilter<"User"> | string
    balance?: IntFilter<"User"> | number
    createdAt?: DateTimeFilter<"User"> | Date | string
    updatedAt?: DateTimeFilter<"User"> | Date | string
    wishlists?: WishlistListRelationFilter
    topUp?: TopUpListRelationFilter
    transactions?: TransactionListRelationFilter
    userVerificationTokens?: UserVerificationTokenListRelationFilter
  }, "id">

  export type UserOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    password?: SortOrder
    status?: SortOrder
    profile?: SortOrder
    balance?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: UserCountOrderByAggregateInput
    _avg?: UserAvgOrderByAggregateInput
    _max?: UserMaxOrderByAggregateInput
    _min?: UserMinOrderByAggregateInput
    _sum?: UserSumOrderByAggregateInput
  }

  export type UserScalarWhereWithAggregatesInput = {
    AND?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    OR?: UserScalarWhereWithAggregatesInput[]
    NOT?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"User"> | string
    name?: StringWithAggregatesFilter<"User"> | string
    email?: StringWithAggregatesFilter<"User"> | string
    password?: StringWithAggregatesFilter<"User"> | string
    status?: StringWithAggregatesFilter<"User"> | string
    profile?: StringWithAggregatesFilter<"User"> | string
    balance?: IntWithAggregatesFilter<"User"> | number
    createdAt?: DateTimeWithAggregatesFilter<"User"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"User"> | Date | string
  }

  export type UserVerificationTokenWhereInput = {
    AND?: UserVerificationTokenWhereInput | UserVerificationTokenWhereInput[]
    OR?: UserVerificationTokenWhereInput[]
    NOT?: UserVerificationTokenWhereInput | UserVerificationTokenWhereInput[]
    id?: StringFilter<"UserVerificationToken"> | string
    token?: StringFilter<"UserVerificationToken"> | string
    userId?: StringFilter<"UserVerificationToken"> | string
    purpose?: StringFilter<"UserVerificationToken"> | string
    createdAt?: DateTimeFilter<"UserVerificationToken"> | Date | string
    updatedAt?: DateTimeFilter<"UserVerificationToken"> | Date | string
    expiredAt?: DateTimeNullableFilter<"UserVerificationToken"> | Date | string | null
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }

  export type UserVerificationTokenOrderByWithRelationInput = {
    id?: SortOrder
    token?: SortOrder
    userId?: SortOrder
    purpose?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    expiredAt?: SortOrderInput | SortOrder
    user?: UserOrderByWithRelationInput
    _relevance?: UserVerificationTokenOrderByRelevanceInput
  }

  export type UserVerificationTokenWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: UserVerificationTokenWhereInput | UserVerificationTokenWhereInput[]
    OR?: UserVerificationTokenWhereInput[]
    NOT?: UserVerificationTokenWhereInput | UserVerificationTokenWhereInput[]
    token?: StringFilter<"UserVerificationToken"> | string
    userId?: StringFilter<"UserVerificationToken"> | string
    purpose?: StringFilter<"UserVerificationToken"> | string
    createdAt?: DateTimeFilter<"UserVerificationToken"> | Date | string
    updatedAt?: DateTimeFilter<"UserVerificationToken"> | Date | string
    expiredAt?: DateTimeNullableFilter<"UserVerificationToken"> | Date | string | null
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }, "id">

  export type UserVerificationTokenOrderByWithAggregationInput = {
    id?: SortOrder
    token?: SortOrder
    userId?: SortOrder
    purpose?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    expiredAt?: SortOrderInput | SortOrder
    _count?: UserVerificationTokenCountOrderByAggregateInput
    _max?: UserVerificationTokenMaxOrderByAggregateInput
    _min?: UserVerificationTokenMinOrderByAggregateInput
  }

  export type UserVerificationTokenScalarWhereWithAggregatesInput = {
    AND?: UserVerificationTokenScalarWhereWithAggregatesInput | UserVerificationTokenScalarWhereWithAggregatesInput[]
    OR?: UserVerificationTokenScalarWhereWithAggregatesInput[]
    NOT?: UserVerificationTokenScalarWhereWithAggregatesInput | UserVerificationTokenScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"UserVerificationToken"> | string
    token?: StringWithAggregatesFilter<"UserVerificationToken"> | string
    userId?: StringWithAggregatesFilter<"UserVerificationToken"> | string
    purpose?: StringWithAggregatesFilter<"UserVerificationToken"> | string
    createdAt?: DateTimeWithAggregatesFilter<"UserVerificationToken"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"UserVerificationToken"> | Date | string
    expiredAt?: DateTimeNullableWithAggregatesFilter<"UserVerificationToken"> | Date | string | null
  }

  export type CategoryWhereInput = {
    AND?: CategoryWhereInput | CategoryWhereInput[]
    OR?: CategoryWhereInput[]
    NOT?: CategoryWhereInput | CategoryWhereInput[]
    id?: StringFilter<"Category"> | string
    name?: StringFilter<"Category"> | string
    status?: StringFilter<"Category"> | string
    createdAt?: DateTimeFilter<"Category"> | Date | string
    updatedAt?: DateTimeFilter<"Category"> | Date | string
    products?: ProductListRelationFilter
  }

  export type CategoryOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    products?: ProductOrderByRelationAggregateInput
    _relevance?: CategoryOrderByRelevanceInput
  }

  export type CategoryWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: CategoryWhereInput | CategoryWhereInput[]
    OR?: CategoryWhereInput[]
    NOT?: CategoryWhereInput | CategoryWhereInput[]
    name?: StringFilter<"Category"> | string
    status?: StringFilter<"Category"> | string
    createdAt?: DateTimeFilter<"Category"> | Date | string
    updatedAt?: DateTimeFilter<"Category"> | Date | string
    products?: ProductListRelationFilter
  }, "id">

  export type CategoryOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: CategoryCountOrderByAggregateInput
    _max?: CategoryMaxOrderByAggregateInput
    _min?: CategoryMinOrderByAggregateInput
  }

  export type CategoryScalarWhereWithAggregatesInput = {
    AND?: CategoryScalarWhereWithAggregatesInput | CategoryScalarWhereWithAggregatesInput[]
    OR?: CategoryScalarWhereWithAggregatesInput[]
    NOT?: CategoryScalarWhereWithAggregatesInput | CategoryScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Category"> | string
    name?: StringWithAggregatesFilter<"Category"> | string
    status?: StringWithAggregatesFilter<"Category"> | string
    createdAt?: DateTimeWithAggregatesFilter<"Category"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"Category"> | Date | string
  }

  export type ProductWhereInput = {
    AND?: ProductWhereInput | ProductWhereInput[]
    OR?: ProductWhereInput[]
    NOT?: ProductWhereInput | ProductWhereInput[]
    id?: StringFilter<"Product"> | string
    categoryId?: StringFilter<"Product"> | string
    name?: StringFilter<"Product"> | string
    status?: StringFilter<"Product"> | string
    price?: IntFilter<"Product"> | number
    stock?: IntFilter<"Product"> | number
    description?: StringFilter<"Product"> | string
    imageFileName?: StringNullableFilter<"Product"> | string | null
    createdAt?: DateTimeFilter<"Product"> | Date | string
    updatedAt?: DateTimeFilter<"Product"> | Date | string
    category?: XOR<CategoryScalarRelationFilter, CategoryWhereInput>
    stockMutations?: StockMutationListRelationFilter
    wishlists?: WishlistListRelationFilter
    transactionDetails?: TransactionDetailsListRelationFilter
  }

  export type ProductOrderByWithRelationInput = {
    id?: SortOrder
    categoryId?: SortOrder
    name?: SortOrder
    status?: SortOrder
    price?: SortOrder
    stock?: SortOrder
    description?: SortOrder
    imageFileName?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    category?: CategoryOrderByWithRelationInput
    stockMutations?: StockMutationOrderByRelationAggregateInput
    wishlists?: WishlistOrderByRelationAggregateInput
    transactionDetails?: TransactionDetailsOrderByRelationAggregateInput
    _relevance?: ProductOrderByRelevanceInput
  }

  export type ProductWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: ProductWhereInput | ProductWhereInput[]
    OR?: ProductWhereInput[]
    NOT?: ProductWhereInput | ProductWhereInput[]
    categoryId?: StringFilter<"Product"> | string
    name?: StringFilter<"Product"> | string
    status?: StringFilter<"Product"> | string
    price?: IntFilter<"Product"> | number
    stock?: IntFilter<"Product"> | number
    description?: StringFilter<"Product"> | string
    imageFileName?: StringNullableFilter<"Product"> | string | null
    createdAt?: DateTimeFilter<"Product"> | Date | string
    updatedAt?: DateTimeFilter<"Product"> | Date | string
    category?: XOR<CategoryScalarRelationFilter, CategoryWhereInput>
    stockMutations?: StockMutationListRelationFilter
    wishlists?: WishlistListRelationFilter
    transactionDetails?: TransactionDetailsListRelationFilter
  }, "id">

  export type ProductOrderByWithAggregationInput = {
    id?: SortOrder
    categoryId?: SortOrder
    name?: SortOrder
    status?: SortOrder
    price?: SortOrder
    stock?: SortOrder
    description?: SortOrder
    imageFileName?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: ProductCountOrderByAggregateInput
    _avg?: ProductAvgOrderByAggregateInput
    _max?: ProductMaxOrderByAggregateInput
    _min?: ProductMinOrderByAggregateInput
    _sum?: ProductSumOrderByAggregateInput
  }

  export type ProductScalarWhereWithAggregatesInput = {
    AND?: ProductScalarWhereWithAggregatesInput | ProductScalarWhereWithAggregatesInput[]
    OR?: ProductScalarWhereWithAggregatesInput[]
    NOT?: ProductScalarWhereWithAggregatesInput | ProductScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Product"> | string
    categoryId?: StringWithAggregatesFilter<"Product"> | string
    name?: StringWithAggregatesFilter<"Product"> | string
    status?: StringWithAggregatesFilter<"Product"> | string
    price?: IntWithAggregatesFilter<"Product"> | number
    stock?: IntWithAggregatesFilter<"Product"> | number
    description?: StringWithAggregatesFilter<"Product"> | string
    imageFileName?: StringNullableWithAggregatesFilter<"Product"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"Product"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"Product"> | Date | string
  }

  export type StockMutationWhereInput = {
    AND?: StockMutationWhereInput | StockMutationWhereInput[]
    OR?: StockMutationWhereInput[]
    NOT?: StockMutationWhereInput | StockMutationWhereInput[]
    id?: StringFilter<"StockMutation"> | string
    productId?: StringFilter<"StockMutation"> | string
    currentStock?: IntFilter<"StockMutation"> | number
    quantity?: IntFilter<"StockMutation"> | number
    type?: StringFilter<"StockMutation"> | string
    notes?: StringNullableFilter<"StockMutation"> | string | null
    createdAt?: DateTimeFilter<"StockMutation"> | Date | string
    updatedAt?: DateTimeFilter<"StockMutation"> | Date | string
    product?: XOR<ProductScalarRelationFilter, ProductWhereInput>
  }

  export type StockMutationOrderByWithRelationInput = {
    id?: SortOrder
    productId?: SortOrder
    currentStock?: SortOrder
    quantity?: SortOrder
    type?: SortOrder
    notes?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    product?: ProductOrderByWithRelationInput
    _relevance?: StockMutationOrderByRelevanceInput
  }

  export type StockMutationWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: StockMutationWhereInput | StockMutationWhereInput[]
    OR?: StockMutationWhereInput[]
    NOT?: StockMutationWhereInput | StockMutationWhereInput[]
    productId?: StringFilter<"StockMutation"> | string
    currentStock?: IntFilter<"StockMutation"> | number
    quantity?: IntFilter<"StockMutation"> | number
    type?: StringFilter<"StockMutation"> | string
    notes?: StringNullableFilter<"StockMutation"> | string | null
    createdAt?: DateTimeFilter<"StockMutation"> | Date | string
    updatedAt?: DateTimeFilter<"StockMutation"> | Date | string
    product?: XOR<ProductScalarRelationFilter, ProductWhereInput>
  }, "id">

  export type StockMutationOrderByWithAggregationInput = {
    id?: SortOrder
    productId?: SortOrder
    currentStock?: SortOrder
    quantity?: SortOrder
    type?: SortOrder
    notes?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: StockMutationCountOrderByAggregateInput
    _avg?: StockMutationAvgOrderByAggregateInput
    _max?: StockMutationMaxOrderByAggregateInput
    _min?: StockMutationMinOrderByAggregateInput
    _sum?: StockMutationSumOrderByAggregateInput
  }

  export type StockMutationScalarWhereWithAggregatesInput = {
    AND?: StockMutationScalarWhereWithAggregatesInput | StockMutationScalarWhereWithAggregatesInput[]
    OR?: StockMutationScalarWhereWithAggregatesInput[]
    NOT?: StockMutationScalarWhereWithAggregatesInput | StockMutationScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"StockMutation"> | string
    productId?: StringWithAggregatesFilter<"StockMutation"> | string
    currentStock?: IntWithAggregatesFilter<"StockMutation"> | number
    quantity?: IntWithAggregatesFilter<"StockMutation"> | number
    type?: StringWithAggregatesFilter<"StockMutation"> | string
    notes?: StringNullableWithAggregatesFilter<"StockMutation"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"StockMutation"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"StockMutation"> | Date | string
  }

  export type PaymentTermWhereInput = {
    AND?: PaymentTermWhereInput | PaymentTermWhereInput[]
    OR?: PaymentTermWhereInput[]
    NOT?: PaymentTermWhereInput | PaymentTermWhereInput[]
    id?: StringFilter<"PaymentTerm"> | string
    name?: StringFilter<"PaymentTerm"> | string
    status?: StringFilter<"PaymentTerm"> | string
    createdAt?: DateTimeFilter<"PaymentTerm"> | Date | string
    updatedAt?: DateTimeFilter<"PaymentTerm"> | Date | string
    PaymentAccounts?: PaymentAccountListRelationFilter
    TopUps?: TopUpListRelationFilter
  }

  export type PaymentTermOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    PaymentAccounts?: PaymentAccountOrderByRelationAggregateInput
    TopUps?: TopUpOrderByRelationAggregateInput
    _relevance?: PaymentTermOrderByRelevanceInput
  }

  export type PaymentTermWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: PaymentTermWhereInput | PaymentTermWhereInput[]
    OR?: PaymentTermWhereInput[]
    NOT?: PaymentTermWhereInput | PaymentTermWhereInput[]
    name?: StringFilter<"PaymentTerm"> | string
    status?: StringFilter<"PaymentTerm"> | string
    createdAt?: DateTimeFilter<"PaymentTerm"> | Date | string
    updatedAt?: DateTimeFilter<"PaymentTerm"> | Date | string
    PaymentAccounts?: PaymentAccountListRelationFilter
    TopUps?: TopUpListRelationFilter
  }, "id">

  export type PaymentTermOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: PaymentTermCountOrderByAggregateInput
    _max?: PaymentTermMaxOrderByAggregateInput
    _min?: PaymentTermMinOrderByAggregateInput
  }

  export type PaymentTermScalarWhereWithAggregatesInput = {
    AND?: PaymentTermScalarWhereWithAggregatesInput | PaymentTermScalarWhereWithAggregatesInput[]
    OR?: PaymentTermScalarWhereWithAggregatesInput[]
    NOT?: PaymentTermScalarWhereWithAggregatesInput | PaymentTermScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"PaymentTerm"> | string
    name?: StringWithAggregatesFilter<"PaymentTerm"> | string
    status?: StringWithAggregatesFilter<"PaymentTerm"> | string
    createdAt?: DateTimeWithAggregatesFilter<"PaymentTerm"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"PaymentTerm"> | Date | string
  }

  export type PaymentAccountWhereInput = {
    AND?: PaymentAccountWhereInput | PaymentAccountWhereInput[]
    OR?: PaymentAccountWhereInput[]
    NOT?: PaymentAccountWhereInput | PaymentAccountWhereInput[]
    id?: StringFilter<"PaymentAccount"> | string
    paymentTermId?: StringFilter<"PaymentAccount"> | string
    accountHolderName?: StringFilter<"PaymentAccount"> | string
    accountNumber?: StringFilter<"PaymentAccount"> | string
    status?: StringFilter<"PaymentAccount"> | string
    createdAt?: DateTimeFilter<"PaymentAccount"> | Date | string
    updatedAt?: DateTimeFilter<"PaymentAccount"> | Date | string
    paymentTerm?: XOR<PaymentTermScalarRelationFilter, PaymentTermWhereInput>
    TopUps?: TopUpListRelationFilter
  }

  export type PaymentAccountOrderByWithRelationInput = {
    id?: SortOrder
    paymentTermId?: SortOrder
    accountHolderName?: SortOrder
    accountNumber?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    paymentTerm?: PaymentTermOrderByWithRelationInput
    TopUps?: TopUpOrderByRelationAggregateInput
    _relevance?: PaymentAccountOrderByRelevanceInput
  }

  export type PaymentAccountWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: PaymentAccountWhereInput | PaymentAccountWhereInput[]
    OR?: PaymentAccountWhereInput[]
    NOT?: PaymentAccountWhereInput | PaymentAccountWhereInput[]
    paymentTermId?: StringFilter<"PaymentAccount"> | string
    accountHolderName?: StringFilter<"PaymentAccount"> | string
    accountNumber?: StringFilter<"PaymentAccount"> | string
    status?: StringFilter<"PaymentAccount"> | string
    createdAt?: DateTimeFilter<"PaymentAccount"> | Date | string
    updatedAt?: DateTimeFilter<"PaymentAccount"> | Date | string
    paymentTerm?: XOR<PaymentTermScalarRelationFilter, PaymentTermWhereInput>
    TopUps?: TopUpListRelationFilter
  }, "id">

  export type PaymentAccountOrderByWithAggregationInput = {
    id?: SortOrder
    paymentTermId?: SortOrder
    accountHolderName?: SortOrder
    accountNumber?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: PaymentAccountCountOrderByAggregateInput
    _max?: PaymentAccountMaxOrderByAggregateInput
    _min?: PaymentAccountMinOrderByAggregateInput
  }

  export type PaymentAccountScalarWhereWithAggregatesInput = {
    AND?: PaymentAccountScalarWhereWithAggregatesInput | PaymentAccountScalarWhereWithAggregatesInput[]
    OR?: PaymentAccountScalarWhereWithAggregatesInput[]
    NOT?: PaymentAccountScalarWhereWithAggregatesInput | PaymentAccountScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"PaymentAccount"> | string
    paymentTermId?: StringWithAggregatesFilter<"PaymentAccount"> | string
    accountHolderName?: StringWithAggregatesFilter<"PaymentAccount"> | string
    accountNumber?: StringWithAggregatesFilter<"PaymentAccount"> | string
    status?: StringWithAggregatesFilter<"PaymentAccount"> | string
    createdAt?: DateTimeWithAggregatesFilter<"PaymentAccount"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"PaymentAccount"> | Date | string
  }

  export type WishlistWhereInput = {
    AND?: WishlistWhereInput | WishlistWhereInput[]
    OR?: WishlistWhereInput[]
    NOT?: WishlistWhereInput | WishlistWhereInput[]
    id?: StringFilter<"Wishlist"> | string
    userId?: StringFilter<"Wishlist"> | string
    productId?: StringFilter<"Wishlist"> | string
    createdAt?: DateTimeFilter<"Wishlist"> | Date | string
    updatedAt?: DateTimeFilter<"Wishlist"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    product?: XOR<ProductScalarRelationFilter, ProductWhereInput>
  }

  export type WishlistOrderByWithRelationInput = {
    id?: SortOrder
    userId?: SortOrder
    productId?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    user?: UserOrderByWithRelationInput
    product?: ProductOrderByWithRelationInput
    _relevance?: WishlistOrderByRelevanceInput
  }

  export type WishlistWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: WishlistWhereInput | WishlistWhereInput[]
    OR?: WishlistWhereInput[]
    NOT?: WishlistWhereInput | WishlistWhereInput[]
    userId?: StringFilter<"Wishlist"> | string
    productId?: StringFilter<"Wishlist"> | string
    createdAt?: DateTimeFilter<"Wishlist"> | Date | string
    updatedAt?: DateTimeFilter<"Wishlist"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    product?: XOR<ProductScalarRelationFilter, ProductWhereInput>
  }, "id">

  export type WishlistOrderByWithAggregationInput = {
    id?: SortOrder
    userId?: SortOrder
    productId?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: WishlistCountOrderByAggregateInput
    _max?: WishlistMaxOrderByAggregateInput
    _min?: WishlistMinOrderByAggregateInput
  }

  export type WishlistScalarWhereWithAggregatesInput = {
    AND?: WishlistScalarWhereWithAggregatesInput | WishlistScalarWhereWithAggregatesInput[]
    OR?: WishlistScalarWhereWithAggregatesInput[]
    NOT?: WishlistScalarWhereWithAggregatesInput | WishlistScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Wishlist"> | string
    userId?: StringWithAggregatesFilter<"Wishlist"> | string
    productId?: StringWithAggregatesFilter<"Wishlist"> | string
    createdAt?: DateTimeWithAggregatesFilter<"Wishlist"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"Wishlist"> | Date | string
  }

  export type TopUpWhereInput = {
    AND?: TopUpWhereInput | TopUpWhereInput[]
    OR?: TopUpWhereInput[]
    NOT?: TopUpWhereInput | TopUpWhereInput[]
    id?: StringFilter<"TopUp"> | string
    nominal?: IntFilter<"TopUp"> | number
    adminId?: StringNullableFilter<"TopUp"> | string | null
    userId?: StringFilter<"TopUp"> | string
    proofOfTransferFileName?: StringFilter<"TopUp"> | string
    status?: StringFilter<"TopUp"> | string
    createdAt?: DateTimeFilter<"TopUp"> | Date | string
    updatedAt?: DateTimeFilter<"TopUp"> | Date | string
    paymentAccountId?: StringFilter<"TopUp"> | string
    paymentTermId?: StringFilter<"TopUp"> | string
    admin?: XOR<AdminNullableScalarRelationFilter, AdminWhereInput> | null
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    PaymentAccount?: XOR<PaymentAccountScalarRelationFilter, PaymentAccountWhereInput>
    paymentTerm?: XOR<PaymentTermScalarRelationFilter, PaymentTermWhereInput>
  }

  export type TopUpOrderByWithRelationInput = {
    id?: SortOrder
    nominal?: SortOrder
    adminId?: SortOrderInput | SortOrder
    userId?: SortOrder
    proofOfTransferFileName?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    paymentAccountId?: SortOrder
    paymentTermId?: SortOrder
    admin?: AdminOrderByWithRelationInput
    user?: UserOrderByWithRelationInput
    PaymentAccount?: PaymentAccountOrderByWithRelationInput
    paymentTerm?: PaymentTermOrderByWithRelationInput
    _relevance?: TopUpOrderByRelevanceInput
  }

  export type TopUpWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: TopUpWhereInput | TopUpWhereInput[]
    OR?: TopUpWhereInput[]
    NOT?: TopUpWhereInput | TopUpWhereInput[]
    nominal?: IntFilter<"TopUp"> | number
    adminId?: StringNullableFilter<"TopUp"> | string | null
    userId?: StringFilter<"TopUp"> | string
    proofOfTransferFileName?: StringFilter<"TopUp"> | string
    status?: StringFilter<"TopUp"> | string
    createdAt?: DateTimeFilter<"TopUp"> | Date | string
    updatedAt?: DateTimeFilter<"TopUp"> | Date | string
    paymentAccountId?: StringFilter<"TopUp"> | string
    paymentTermId?: StringFilter<"TopUp"> | string
    admin?: XOR<AdminNullableScalarRelationFilter, AdminWhereInput> | null
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    PaymentAccount?: XOR<PaymentAccountScalarRelationFilter, PaymentAccountWhereInput>
    paymentTerm?: XOR<PaymentTermScalarRelationFilter, PaymentTermWhereInput>
  }, "id">

  export type TopUpOrderByWithAggregationInput = {
    id?: SortOrder
    nominal?: SortOrder
    adminId?: SortOrderInput | SortOrder
    userId?: SortOrder
    proofOfTransferFileName?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    paymentAccountId?: SortOrder
    paymentTermId?: SortOrder
    _count?: TopUpCountOrderByAggregateInput
    _avg?: TopUpAvgOrderByAggregateInput
    _max?: TopUpMaxOrderByAggregateInput
    _min?: TopUpMinOrderByAggregateInput
    _sum?: TopUpSumOrderByAggregateInput
  }

  export type TopUpScalarWhereWithAggregatesInput = {
    AND?: TopUpScalarWhereWithAggregatesInput | TopUpScalarWhereWithAggregatesInput[]
    OR?: TopUpScalarWhereWithAggregatesInput[]
    NOT?: TopUpScalarWhereWithAggregatesInput | TopUpScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"TopUp"> | string
    nominal?: IntWithAggregatesFilter<"TopUp"> | number
    adminId?: StringNullableWithAggregatesFilter<"TopUp"> | string | null
    userId?: StringWithAggregatesFilter<"TopUp"> | string
    proofOfTransferFileName?: StringWithAggregatesFilter<"TopUp"> | string
    status?: StringWithAggregatesFilter<"TopUp"> | string
    createdAt?: DateTimeWithAggregatesFilter<"TopUp"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"TopUp"> | Date | string
    paymentAccountId?: StringWithAggregatesFilter<"TopUp"> | string
    paymentTermId?: StringWithAggregatesFilter<"TopUp"> | string
  }

  export type TransactionWhereInput = {
    AND?: TransactionWhereInput | TransactionWhereInput[]
    OR?: TransactionWhereInput[]
    NOT?: TransactionWhereInput | TransactionWhereInput[]
    id?: StringFilter<"Transaction"> | string
    userId?: StringFilter<"Transaction"> | string
    total?: IntFilter<"Transaction"> | number
    status?: StringFilter<"Transaction"> | string
    createdAt?: DateTimeFilter<"Transaction"> | Date | string
    updatedAt?: DateTimeFilter<"Transaction"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    transactionDetails?: TransactionDetailsListRelationFilter
  }

  export type TransactionOrderByWithRelationInput = {
    id?: SortOrder
    userId?: SortOrder
    total?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    user?: UserOrderByWithRelationInput
    transactionDetails?: TransactionDetailsOrderByRelationAggregateInput
    _relevance?: TransactionOrderByRelevanceInput
  }

  export type TransactionWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: TransactionWhereInput | TransactionWhereInput[]
    OR?: TransactionWhereInput[]
    NOT?: TransactionWhereInput | TransactionWhereInput[]
    userId?: StringFilter<"Transaction"> | string
    total?: IntFilter<"Transaction"> | number
    status?: StringFilter<"Transaction"> | string
    createdAt?: DateTimeFilter<"Transaction"> | Date | string
    updatedAt?: DateTimeFilter<"Transaction"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    transactionDetails?: TransactionDetailsListRelationFilter
  }, "id">

  export type TransactionOrderByWithAggregationInput = {
    id?: SortOrder
    userId?: SortOrder
    total?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: TransactionCountOrderByAggregateInput
    _avg?: TransactionAvgOrderByAggregateInput
    _max?: TransactionMaxOrderByAggregateInput
    _min?: TransactionMinOrderByAggregateInput
    _sum?: TransactionSumOrderByAggregateInput
  }

  export type TransactionScalarWhereWithAggregatesInput = {
    AND?: TransactionScalarWhereWithAggregatesInput | TransactionScalarWhereWithAggregatesInput[]
    OR?: TransactionScalarWhereWithAggregatesInput[]
    NOT?: TransactionScalarWhereWithAggregatesInput | TransactionScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Transaction"> | string
    userId?: StringWithAggregatesFilter<"Transaction"> | string
    total?: IntWithAggregatesFilter<"Transaction"> | number
    status?: StringWithAggregatesFilter<"Transaction"> | string
    createdAt?: DateTimeWithAggregatesFilter<"Transaction"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"Transaction"> | Date | string
  }

  export type TransactionDetailsWhereInput = {
    AND?: TransactionDetailsWhereInput | TransactionDetailsWhereInput[]
    OR?: TransactionDetailsWhereInput[]
    NOT?: TransactionDetailsWhereInput | TransactionDetailsWhereInput[]
    id?: StringFilter<"TransactionDetails"> | string
    transactionId?: StringFilter<"TransactionDetails"> | string
    productId?: StringFilter<"TransactionDetails"> | string
    purchasedPrice?: IntFilter<"TransactionDetails"> | number
    quantity?: IntFilter<"TransactionDetails"> | number
    subtotal?: IntFilter<"TransactionDetails"> | number
    createdAt?: DateTimeFilter<"TransactionDetails"> | Date | string
    updatedAt?: DateTimeFilter<"TransactionDetails"> | Date | string
    transaction?: XOR<TransactionScalarRelationFilter, TransactionWhereInput>
    product?: XOR<ProductScalarRelationFilter, ProductWhereInput>
  }

  export type TransactionDetailsOrderByWithRelationInput = {
    id?: SortOrder
    transactionId?: SortOrder
    productId?: SortOrder
    purchasedPrice?: SortOrder
    quantity?: SortOrder
    subtotal?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    transaction?: TransactionOrderByWithRelationInput
    product?: ProductOrderByWithRelationInput
    _relevance?: TransactionDetailsOrderByRelevanceInput
  }

  export type TransactionDetailsWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: TransactionDetailsWhereInput | TransactionDetailsWhereInput[]
    OR?: TransactionDetailsWhereInput[]
    NOT?: TransactionDetailsWhereInput | TransactionDetailsWhereInput[]
    transactionId?: StringFilter<"TransactionDetails"> | string
    productId?: StringFilter<"TransactionDetails"> | string
    purchasedPrice?: IntFilter<"TransactionDetails"> | number
    quantity?: IntFilter<"TransactionDetails"> | number
    subtotal?: IntFilter<"TransactionDetails"> | number
    createdAt?: DateTimeFilter<"TransactionDetails"> | Date | string
    updatedAt?: DateTimeFilter<"TransactionDetails"> | Date | string
    transaction?: XOR<TransactionScalarRelationFilter, TransactionWhereInput>
    product?: XOR<ProductScalarRelationFilter, ProductWhereInput>
  }, "id">

  export type TransactionDetailsOrderByWithAggregationInput = {
    id?: SortOrder
    transactionId?: SortOrder
    productId?: SortOrder
    purchasedPrice?: SortOrder
    quantity?: SortOrder
    subtotal?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: TransactionDetailsCountOrderByAggregateInput
    _avg?: TransactionDetailsAvgOrderByAggregateInput
    _max?: TransactionDetailsMaxOrderByAggregateInput
    _min?: TransactionDetailsMinOrderByAggregateInput
    _sum?: TransactionDetailsSumOrderByAggregateInput
  }

  export type TransactionDetailsScalarWhereWithAggregatesInput = {
    AND?: TransactionDetailsScalarWhereWithAggregatesInput | TransactionDetailsScalarWhereWithAggregatesInput[]
    OR?: TransactionDetailsScalarWhereWithAggregatesInput[]
    NOT?: TransactionDetailsScalarWhereWithAggregatesInput | TransactionDetailsScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"TransactionDetails"> | string
    transactionId?: StringWithAggregatesFilter<"TransactionDetails"> | string
    productId?: StringWithAggregatesFilter<"TransactionDetails"> | string
    purchasedPrice?: IntWithAggregatesFilter<"TransactionDetails"> | number
    quantity?: IntWithAggregatesFilter<"TransactionDetails"> | number
    subtotal?: IntWithAggregatesFilter<"TransactionDetails"> | number
    createdAt?: DateTimeWithAggregatesFilter<"TransactionDetails"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"TransactionDetails"> | Date | string
  }

  export type AdminCreateInput = {
    id?: string
    name: string
    email: string
    password: string
    role: string
    status: string
    isPasswordChanged: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    topUps?: TopUpCreateNestedManyWithoutAdminInput
  }

  export type AdminUncheckedCreateInput = {
    id?: string
    name: string
    email: string
    password: string
    role: string
    status: string
    isPasswordChanged: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    topUps?: TopUpUncheckedCreateNestedManyWithoutAdminInput
  }

  export type AdminUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    role?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    isPasswordChanged?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    topUps?: TopUpUpdateManyWithoutAdminNestedInput
  }

  export type AdminUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    role?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    isPasswordChanged?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    topUps?: TopUpUncheckedUpdateManyWithoutAdminNestedInput
  }

  export type AdminCreateManyInput = {
    id?: string
    name: string
    email: string
    password: string
    role: string
    status: string
    isPasswordChanged: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type AdminUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    role?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    isPasswordChanged?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AdminUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    role?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    isPasswordChanged?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserCreateInput = {
    id?: string
    name: string
    email: string
    password: string
    status: string
    profile: string
    balance: number
    createdAt?: Date | string
    updatedAt?: Date | string
    wishlists?: WishlistCreateNestedManyWithoutUserInput
    topUp?: TopUpCreateNestedManyWithoutUserInput
    transactions?: TransactionCreateNestedManyWithoutUserInput
    userVerificationTokens?: UserVerificationTokenCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateInput = {
    id?: string
    name: string
    email: string
    password: string
    status: string
    profile: string
    balance: number
    createdAt?: Date | string
    updatedAt?: Date | string
    wishlists?: WishlistUncheckedCreateNestedManyWithoutUserInput
    topUp?: TopUpUncheckedCreateNestedManyWithoutUserInput
    transactions?: TransactionUncheckedCreateNestedManyWithoutUserInput
    userVerificationTokens?: UserVerificationTokenUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    profile?: StringFieldUpdateOperationsInput | string
    balance?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    wishlists?: WishlistUpdateManyWithoutUserNestedInput
    topUp?: TopUpUpdateManyWithoutUserNestedInput
    transactions?: TransactionUpdateManyWithoutUserNestedInput
    userVerificationTokens?: UserVerificationTokenUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    profile?: StringFieldUpdateOperationsInput | string
    balance?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    wishlists?: WishlistUncheckedUpdateManyWithoutUserNestedInput
    topUp?: TopUpUncheckedUpdateManyWithoutUserNestedInput
    transactions?: TransactionUncheckedUpdateManyWithoutUserNestedInput
    userVerificationTokens?: UserVerificationTokenUncheckedUpdateManyWithoutUserNestedInput
  }

  export type UserCreateManyInput = {
    id?: string
    name: string
    email: string
    password: string
    status: string
    profile: string
    balance: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type UserUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    profile?: StringFieldUpdateOperationsInput | string
    balance?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    profile?: StringFieldUpdateOperationsInput | string
    balance?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserVerificationTokenCreateInput = {
    id?: string
    token: string
    purpose: string
    createdAt?: Date | string
    updatedAt?: Date | string
    expiredAt?: Date | string | null
    user: UserCreateNestedOneWithoutUserVerificationTokensInput
  }

  export type UserVerificationTokenUncheckedCreateInput = {
    id?: string
    token: string
    userId: string
    purpose: string
    createdAt?: Date | string
    updatedAt?: Date | string
    expiredAt?: Date | string | null
  }

  export type UserVerificationTokenUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    purpose?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    expiredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    user?: UserUpdateOneRequiredWithoutUserVerificationTokensNestedInput
  }

  export type UserVerificationTokenUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    purpose?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    expiredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type UserVerificationTokenCreateManyInput = {
    id?: string
    token: string
    userId: string
    purpose: string
    createdAt?: Date | string
    updatedAt?: Date | string
    expiredAt?: Date | string | null
  }

  export type UserVerificationTokenUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    purpose?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    expiredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type UserVerificationTokenUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    purpose?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    expiredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type CategoryCreateInput = {
    id?: string
    name: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    products?: ProductCreateNestedManyWithoutCategoryInput
  }

  export type CategoryUncheckedCreateInput = {
    id?: string
    name: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    products?: ProductUncheckedCreateNestedManyWithoutCategoryInput
  }

  export type CategoryUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    products?: ProductUpdateManyWithoutCategoryNestedInput
  }

  export type CategoryUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    products?: ProductUncheckedUpdateManyWithoutCategoryNestedInput
  }

  export type CategoryCreateManyInput = {
    id?: string
    name: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type CategoryUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CategoryUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ProductCreateInput = {
    id?: string
    name: string
    status: string
    price: number
    stock: number
    description: string
    imageFileName?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    category: CategoryCreateNestedOneWithoutProductsInput
    stockMutations?: StockMutationCreateNestedManyWithoutProductInput
    wishlists?: WishlistCreateNestedManyWithoutProductInput
    transactionDetails?: TransactionDetailsCreateNestedManyWithoutProductInput
  }

  export type ProductUncheckedCreateInput = {
    id?: string
    categoryId: string
    name: string
    status: string
    price: number
    stock: number
    description: string
    imageFileName?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    stockMutations?: StockMutationUncheckedCreateNestedManyWithoutProductInput
    wishlists?: WishlistUncheckedCreateNestedManyWithoutProductInput
    transactionDetails?: TransactionDetailsUncheckedCreateNestedManyWithoutProductInput
  }

  export type ProductUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    price?: IntFieldUpdateOperationsInput | number
    stock?: IntFieldUpdateOperationsInput | number
    description?: StringFieldUpdateOperationsInput | string
    imageFileName?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    category?: CategoryUpdateOneRequiredWithoutProductsNestedInput
    stockMutations?: StockMutationUpdateManyWithoutProductNestedInput
    wishlists?: WishlistUpdateManyWithoutProductNestedInput
    transactionDetails?: TransactionDetailsUpdateManyWithoutProductNestedInput
  }

  export type ProductUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    categoryId?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    price?: IntFieldUpdateOperationsInput | number
    stock?: IntFieldUpdateOperationsInput | number
    description?: StringFieldUpdateOperationsInput | string
    imageFileName?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    stockMutations?: StockMutationUncheckedUpdateManyWithoutProductNestedInput
    wishlists?: WishlistUncheckedUpdateManyWithoutProductNestedInput
    transactionDetails?: TransactionDetailsUncheckedUpdateManyWithoutProductNestedInput
  }

  export type ProductCreateManyInput = {
    id?: string
    categoryId: string
    name: string
    status: string
    price: number
    stock: number
    description: string
    imageFileName?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type ProductUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    price?: IntFieldUpdateOperationsInput | number
    stock?: IntFieldUpdateOperationsInput | number
    description?: StringFieldUpdateOperationsInput | string
    imageFileName?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ProductUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    categoryId?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    price?: IntFieldUpdateOperationsInput | number
    stock?: IntFieldUpdateOperationsInput | number
    description?: StringFieldUpdateOperationsInput | string
    imageFileName?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type StockMutationCreateInput = {
    id?: string
    currentStock: number
    quantity: number
    type: string
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    product: ProductCreateNestedOneWithoutStockMutationsInput
  }

  export type StockMutationUncheckedCreateInput = {
    id?: string
    productId: string
    currentStock: number
    quantity: number
    type: string
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type StockMutationUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    currentStock?: IntFieldUpdateOperationsInput | number
    quantity?: IntFieldUpdateOperationsInput | number
    type?: StringFieldUpdateOperationsInput | string
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    product?: ProductUpdateOneRequiredWithoutStockMutationsNestedInput
  }

  export type StockMutationUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    productId?: StringFieldUpdateOperationsInput | string
    currentStock?: IntFieldUpdateOperationsInput | number
    quantity?: IntFieldUpdateOperationsInput | number
    type?: StringFieldUpdateOperationsInput | string
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type StockMutationCreateManyInput = {
    id?: string
    productId: string
    currentStock: number
    quantity: number
    type: string
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type StockMutationUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    currentStock?: IntFieldUpdateOperationsInput | number
    quantity?: IntFieldUpdateOperationsInput | number
    type?: StringFieldUpdateOperationsInput | string
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type StockMutationUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    productId?: StringFieldUpdateOperationsInput | string
    currentStock?: IntFieldUpdateOperationsInput | number
    quantity?: IntFieldUpdateOperationsInput | number
    type?: StringFieldUpdateOperationsInput | string
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PaymentTermCreateInput = {
    id?: string
    name: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    PaymentAccounts?: PaymentAccountCreateNestedManyWithoutPaymentTermInput
    TopUps?: TopUpCreateNestedManyWithoutPaymentTermInput
  }

  export type PaymentTermUncheckedCreateInput = {
    id?: string
    name: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    PaymentAccounts?: PaymentAccountUncheckedCreateNestedManyWithoutPaymentTermInput
    TopUps?: TopUpUncheckedCreateNestedManyWithoutPaymentTermInput
  }

  export type PaymentTermUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    PaymentAccounts?: PaymentAccountUpdateManyWithoutPaymentTermNestedInput
    TopUps?: TopUpUpdateManyWithoutPaymentTermNestedInput
  }

  export type PaymentTermUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    PaymentAccounts?: PaymentAccountUncheckedUpdateManyWithoutPaymentTermNestedInput
    TopUps?: TopUpUncheckedUpdateManyWithoutPaymentTermNestedInput
  }

  export type PaymentTermCreateManyInput = {
    id?: string
    name: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type PaymentTermUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PaymentTermUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PaymentAccountCreateInput = {
    id?: string
    accountHolderName: string
    accountNumber: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    paymentTerm: PaymentTermCreateNestedOneWithoutPaymentAccountsInput
    TopUps?: TopUpCreateNestedManyWithoutPaymentAccountInput
  }

  export type PaymentAccountUncheckedCreateInput = {
    id?: string
    paymentTermId: string
    accountHolderName: string
    accountNumber: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    TopUps?: TopUpUncheckedCreateNestedManyWithoutPaymentAccountInput
  }

  export type PaymentAccountUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    accountHolderName?: StringFieldUpdateOperationsInput | string
    accountNumber?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    paymentTerm?: PaymentTermUpdateOneRequiredWithoutPaymentAccountsNestedInput
    TopUps?: TopUpUpdateManyWithoutPaymentAccountNestedInput
  }

  export type PaymentAccountUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    paymentTermId?: StringFieldUpdateOperationsInput | string
    accountHolderName?: StringFieldUpdateOperationsInput | string
    accountNumber?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    TopUps?: TopUpUncheckedUpdateManyWithoutPaymentAccountNestedInput
  }

  export type PaymentAccountCreateManyInput = {
    id?: string
    paymentTermId: string
    accountHolderName: string
    accountNumber: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type PaymentAccountUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    accountHolderName?: StringFieldUpdateOperationsInput | string
    accountNumber?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PaymentAccountUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    paymentTermId?: StringFieldUpdateOperationsInput | string
    accountHolderName?: StringFieldUpdateOperationsInput | string
    accountNumber?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type WishlistCreateInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    user: UserCreateNestedOneWithoutWishlistsInput
    product: ProductCreateNestedOneWithoutWishlistsInput
  }

  export type WishlistUncheckedCreateInput = {
    id?: string
    userId: string
    productId: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type WishlistUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutWishlistsNestedInput
    product?: ProductUpdateOneRequiredWithoutWishlistsNestedInput
  }

  export type WishlistUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    productId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type WishlistCreateManyInput = {
    id?: string
    userId: string
    productId: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type WishlistUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type WishlistUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    productId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type TopUpCreateInput = {
    id?: string
    nominal: number
    proofOfTransferFileName: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    admin?: AdminCreateNestedOneWithoutTopUpsInput
    user: UserCreateNestedOneWithoutTopUpInput
    PaymentAccount: PaymentAccountCreateNestedOneWithoutTopUpsInput
    paymentTerm: PaymentTermCreateNestedOneWithoutTopUpsInput
  }

  export type TopUpUncheckedCreateInput = {
    id?: string
    nominal: number
    adminId?: string | null
    userId: string
    proofOfTransferFileName: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    paymentAccountId: string
    paymentTermId: string
  }

  export type TopUpUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    nominal?: IntFieldUpdateOperationsInput | number
    proofOfTransferFileName?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    admin?: AdminUpdateOneWithoutTopUpsNestedInput
    user?: UserUpdateOneRequiredWithoutTopUpNestedInput
    PaymentAccount?: PaymentAccountUpdateOneRequiredWithoutTopUpsNestedInput
    paymentTerm?: PaymentTermUpdateOneRequiredWithoutTopUpsNestedInput
  }

  export type TopUpUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    nominal?: IntFieldUpdateOperationsInput | number
    adminId?: NullableStringFieldUpdateOperationsInput | string | null
    userId?: StringFieldUpdateOperationsInput | string
    proofOfTransferFileName?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    paymentAccountId?: StringFieldUpdateOperationsInput | string
    paymentTermId?: StringFieldUpdateOperationsInput | string
  }

  export type TopUpCreateManyInput = {
    id?: string
    nominal: number
    adminId?: string | null
    userId: string
    proofOfTransferFileName: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    paymentAccountId: string
    paymentTermId: string
  }

  export type TopUpUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    nominal?: IntFieldUpdateOperationsInput | number
    proofOfTransferFileName?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type TopUpUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    nominal?: IntFieldUpdateOperationsInput | number
    adminId?: NullableStringFieldUpdateOperationsInput | string | null
    userId?: StringFieldUpdateOperationsInput | string
    proofOfTransferFileName?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    paymentAccountId?: StringFieldUpdateOperationsInput | string
    paymentTermId?: StringFieldUpdateOperationsInput | string
  }

  export type TransactionCreateInput = {
    id?: string
    total: number
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    user: UserCreateNestedOneWithoutTransactionsInput
    transactionDetails?: TransactionDetailsCreateNestedManyWithoutTransactionInput
  }

  export type TransactionUncheckedCreateInput = {
    id?: string
    userId: string
    total: number
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    transactionDetails?: TransactionDetailsUncheckedCreateNestedManyWithoutTransactionInput
  }

  export type TransactionUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    total?: IntFieldUpdateOperationsInput | number
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutTransactionsNestedInput
    transactionDetails?: TransactionDetailsUpdateManyWithoutTransactionNestedInput
  }

  export type TransactionUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    total?: IntFieldUpdateOperationsInput | number
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    transactionDetails?: TransactionDetailsUncheckedUpdateManyWithoutTransactionNestedInput
  }

  export type TransactionCreateManyInput = {
    id?: string
    userId: string
    total: number
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type TransactionUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    total?: IntFieldUpdateOperationsInput | number
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type TransactionUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    total?: IntFieldUpdateOperationsInput | number
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type TransactionDetailsCreateInput = {
    id?: string
    purchasedPrice: number
    quantity: number
    subtotal: number
    createdAt?: Date | string
    updatedAt?: Date | string
    transaction: TransactionCreateNestedOneWithoutTransactionDetailsInput
    product: ProductCreateNestedOneWithoutTransactionDetailsInput
  }

  export type TransactionDetailsUncheckedCreateInput = {
    id?: string
    transactionId: string
    productId: string
    purchasedPrice: number
    quantity: number
    subtotal: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type TransactionDetailsUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    purchasedPrice?: IntFieldUpdateOperationsInput | number
    quantity?: IntFieldUpdateOperationsInput | number
    subtotal?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    transaction?: TransactionUpdateOneRequiredWithoutTransactionDetailsNestedInput
    product?: ProductUpdateOneRequiredWithoutTransactionDetailsNestedInput
  }

  export type TransactionDetailsUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    transactionId?: StringFieldUpdateOperationsInput | string
    productId?: StringFieldUpdateOperationsInput | string
    purchasedPrice?: IntFieldUpdateOperationsInput | number
    quantity?: IntFieldUpdateOperationsInput | number
    subtotal?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type TransactionDetailsCreateManyInput = {
    id?: string
    transactionId: string
    productId: string
    purchasedPrice: number
    quantity: number
    subtotal: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type TransactionDetailsUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    purchasedPrice?: IntFieldUpdateOperationsInput | number
    quantity?: IntFieldUpdateOperationsInput | number
    subtotal?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type TransactionDetailsUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    transactionId?: StringFieldUpdateOperationsInput | string
    productId?: StringFieldUpdateOperationsInput | string
    purchasedPrice?: IntFieldUpdateOperationsInput | number
    quantity?: IntFieldUpdateOperationsInput | number
    subtotal?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type BoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type DateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type TopUpListRelationFilter = {
    every?: TopUpWhereInput
    some?: TopUpWhereInput
    none?: TopUpWhereInput
  }

  export type TopUpOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type AdminOrderByRelevanceInput = {
    fields: AdminOrderByRelevanceFieldEnum | AdminOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type AdminCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    password?: SortOrder
    role?: SortOrder
    status?: SortOrder
    isPasswordChanged?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type AdminMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    password?: SortOrder
    role?: SortOrder
    status?: SortOrder
    isPasswordChanged?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type AdminMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    password?: SortOrder
    role?: SortOrder
    status?: SortOrder
    isPasswordChanged?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type BoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type DateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type WishlistListRelationFilter = {
    every?: WishlistWhereInput
    some?: WishlistWhereInput
    none?: WishlistWhereInput
  }

  export type TransactionListRelationFilter = {
    every?: TransactionWhereInput
    some?: TransactionWhereInput
    none?: TransactionWhereInput
  }

  export type UserVerificationTokenListRelationFilter = {
    every?: UserVerificationTokenWhereInput
    some?: UserVerificationTokenWhereInput
    none?: UserVerificationTokenWhereInput
  }

  export type WishlistOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type TransactionOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type UserVerificationTokenOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type UserOrderByRelevanceInput = {
    fields: UserOrderByRelevanceFieldEnum | UserOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type UserCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    password?: SortOrder
    status?: SortOrder
    profile?: SortOrder
    balance?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type UserAvgOrderByAggregateInput = {
    balance?: SortOrder
  }

  export type UserMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    password?: SortOrder
    status?: SortOrder
    profile?: SortOrder
    balance?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type UserMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    password?: SortOrder
    status?: SortOrder
    profile?: SortOrder
    balance?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type UserSumOrderByAggregateInput = {
    balance?: SortOrder
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type DateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type UserScalarRelationFilter = {
    is?: UserWhereInput
    isNot?: UserWhereInput
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type UserVerificationTokenOrderByRelevanceInput = {
    fields: UserVerificationTokenOrderByRelevanceFieldEnum | UserVerificationTokenOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type UserVerificationTokenCountOrderByAggregateInput = {
    id?: SortOrder
    token?: SortOrder
    userId?: SortOrder
    purpose?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    expiredAt?: SortOrder
  }

  export type UserVerificationTokenMaxOrderByAggregateInput = {
    id?: SortOrder
    token?: SortOrder
    userId?: SortOrder
    purpose?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    expiredAt?: SortOrder
  }

  export type UserVerificationTokenMinOrderByAggregateInput = {
    id?: SortOrder
    token?: SortOrder
    userId?: SortOrder
    purpose?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    expiredAt?: SortOrder
  }

  export type DateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type ProductListRelationFilter = {
    every?: ProductWhereInput
    some?: ProductWhereInput
    none?: ProductWhereInput
  }

  export type ProductOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type CategoryOrderByRelevanceInput = {
    fields: CategoryOrderByRelevanceFieldEnum | CategoryOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type CategoryCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type CategoryMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type CategoryMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type CategoryScalarRelationFilter = {
    is?: CategoryWhereInput
    isNot?: CategoryWhereInput
  }

  export type StockMutationListRelationFilter = {
    every?: StockMutationWhereInput
    some?: StockMutationWhereInput
    none?: StockMutationWhereInput
  }

  export type TransactionDetailsListRelationFilter = {
    every?: TransactionDetailsWhereInput
    some?: TransactionDetailsWhereInput
    none?: TransactionDetailsWhereInput
  }

  export type StockMutationOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type TransactionDetailsOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type ProductOrderByRelevanceInput = {
    fields: ProductOrderByRelevanceFieldEnum | ProductOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type ProductCountOrderByAggregateInput = {
    id?: SortOrder
    categoryId?: SortOrder
    name?: SortOrder
    status?: SortOrder
    price?: SortOrder
    stock?: SortOrder
    description?: SortOrder
    imageFileName?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type ProductAvgOrderByAggregateInput = {
    price?: SortOrder
    stock?: SortOrder
  }

  export type ProductMaxOrderByAggregateInput = {
    id?: SortOrder
    categoryId?: SortOrder
    name?: SortOrder
    status?: SortOrder
    price?: SortOrder
    stock?: SortOrder
    description?: SortOrder
    imageFileName?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type ProductMinOrderByAggregateInput = {
    id?: SortOrder
    categoryId?: SortOrder
    name?: SortOrder
    status?: SortOrder
    price?: SortOrder
    stock?: SortOrder
    description?: SortOrder
    imageFileName?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type ProductSumOrderByAggregateInput = {
    price?: SortOrder
    stock?: SortOrder
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type ProductScalarRelationFilter = {
    is?: ProductWhereInput
    isNot?: ProductWhereInput
  }

  export type StockMutationOrderByRelevanceInput = {
    fields: StockMutationOrderByRelevanceFieldEnum | StockMutationOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type StockMutationCountOrderByAggregateInput = {
    id?: SortOrder
    productId?: SortOrder
    currentStock?: SortOrder
    quantity?: SortOrder
    type?: SortOrder
    notes?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type StockMutationAvgOrderByAggregateInput = {
    currentStock?: SortOrder
    quantity?: SortOrder
  }

  export type StockMutationMaxOrderByAggregateInput = {
    id?: SortOrder
    productId?: SortOrder
    currentStock?: SortOrder
    quantity?: SortOrder
    type?: SortOrder
    notes?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type StockMutationMinOrderByAggregateInput = {
    id?: SortOrder
    productId?: SortOrder
    currentStock?: SortOrder
    quantity?: SortOrder
    type?: SortOrder
    notes?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type StockMutationSumOrderByAggregateInput = {
    currentStock?: SortOrder
    quantity?: SortOrder
  }

  export type PaymentAccountListRelationFilter = {
    every?: PaymentAccountWhereInput
    some?: PaymentAccountWhereInput
    none?: PaymentAccountWhereInput
  }

  export type PaymentAccountOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type PaymentTermOrderByRelevanceInput = {
    fields: PaymentTermOrderByRelevanceFieldEnum | PaymentTermOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type PaymentTermCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type PaymentTermMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type PaymentTermMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type PaymentTermScalarRelationFilter = {
    is?: PaymentTermWhereInput
    isNot?: PaymentTermWhereInput
  }

  export type PaymentAccountOrderByRelevanceInput = {
    fields: PaymentAccountOrderByRelevanceFieldEnum | PaymentAccountOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type PaymentAccountCountOrderByAggregateInput = {
    id?: SortOrder
    paymentTermId?: SortOrder
    accountHolderName?: SortOrder
    accountNumber?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type PaymentAccountMaxOrderByAggregateInput = {
    id?: SortOrder
    paymentTermId?: SortOrder
    accountHolderName?: SortOrder
    accountNumber?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type PaymentAccountMinOrderByAggregateInput = {
    id?: SortOrder
    paymentTermId?: SortOrder
    accountHolderName?: SortOrder
    accountNumber?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type WishlistOrderByRelevanceInput = {
    fields: WishlistOrderByRelevanceFieldEnum | WishlistOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type WishlistCountOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    productId?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type WishlistMaxOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    productId?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type WishlistMinOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    productId?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type AdminNullableScalarRelationFilter = {
    is?: AdminWhereInput | null
    isNot?: AdminWhereInput | null
  }

  export type PaymentAccountScalarRelationFilter = {
    is?: PaymentAccountWhereInput
    isNot?: PaymentAccountWhereInput
  }

  export type TopUpOrderByRelevanceInput = {
    fields: TopUpOrderByRelevanceFieldEnum | TopUpOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type TopUpCountOrderByAggregateInput = {
    id?: SortOrder
    nominal?: SortOrder
    adminId?: SortOrder
    userId?: SortOrder
    proofOfTransferFileName?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    paymentAccountId?: SortOrder
    paymentTermId?: SortOrder
  }

  export type TopUpAvgOrderByAggregateInput = {
    nominal?: SortOrder
  }

  export type TopUpMaxOrderByAggregateInput = {
    id?: SortOrder
    nominal?: SortOrder
    adminId?: SortOrder
    userId?: SortOrder
    proofOfTransferFileName?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    paymentAccountId?: SortOrder
    paymentTermId?: SortOrder
  }

  export type TopUpMinOrderByAggregateInput = {
    id?: SortOrder
    nominal?: SortOrder
    adminId?: SortOrder
    userId?: SortOrder
    proofOfTransferFileName?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    paymentAccountId?: SortOrder
    paymentTermId?: SortOrder
  }

  export type TopUpSumOrderByAggregateInput = {
    nominal?: SortOrder
  }

  export type TransactionOrderByRelevanceInput = {
    fields: TransactionOrderByRelevanceFieldEnum | TransactionOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type TransactionCountOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    total?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type TransactionAvgOrderByAggregateInput = {
    total?: SortOrder
  }

  export type TransactionMaxOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    total?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type TransactionMinOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    total?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type TransactionSumOrderByAggregateInput = {
    total?: SortOrder
  }

  export type TransactionScalarRelationFilter = {
    is?: TransactionWhereInput
    isNot?: TransactionWhereInput
  }

  export type TransactionDetailsOrderByRelevanceInput = {
    fields: TransactionDetailsOrderByRelevanceFieldEnum | TransactionDetailsOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type TransactionDetailsCountOrderByAggregateInput = {
    id?: SortOrder
    transactionId?: SortOrder
    productId?: SortOrder
    purchasedPrice?: SortOrder
    quantity?: SortOrder
    subtotal?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type TransactionDetailsAvgOrderByAggregateInput = {
    purchasedPrice?: SortOrder
    quantity?: SortOrder
    subtotal?: SortOrder
  }

  export type TransactionDetailsMaxOrderByAggregateInput = {
    id?: SortOrder
    transactionId?: SortOrder
    productId?: SortOrder
    purchasedPrice?: SortOrder
    quantity?: SortOrder
    subtotal?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type TransactionDetailsMinOrderByAggregateInput = {
    id?: SortOrder
    transactionId?: SortOrder
    productId?: SortOrder
    purchasedPrice?: SortOrder
    quantity?: SortOrder
    subtotal?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type TransactionDetailsSumOrderByAggregateInput = {
    purchasedPrice?: SortOrder
    quantity?: SortOrder
    subtotal?: SortOrder
  }

  export type TopUpCreateNestedManyWithoutAdminInput = {
    create?: XOR<TopUpCreateWithoutAdminInput, TopUpUncheckedCreateWithoutAdminInput> | TopUpCreateWithoutAdminInput[] | TopUpUncheckedCreateWithoutAdminInput[]
    connectOrCreate?: TopUpCreateOrConnectWithoutAdminInput | TopUpCreateOrConnectWithoutAdminInput[]
    createMany?: TopUpCreateManyAdminInputEnvelope
    connect?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
  }

  export type TopUpUncheckedCreateNestedManyWithoutAdminInput = {
    create?: XOR<TopUpCreateWithoutAdminInput, TopUpUncheckedCreateWithoutAdminInput> | TopUpCreateWithoutAdminInput[] | TopUpUncheckedCreateWithoutAdminInput[]
    connectOrCreate?: TopUpCreateOrConnectWithoutAdminInput | TopUpCreateOrConnectWithoutAdminInput[]
    createMany?: TopUpCreateManyAdminInputEnvelope
    connect?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type BoolFieldUpdateOperationsInput = {
    set?: boolean
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type TopUpUpdateManyWithoutAdminNestedInput = {
    create?: XOR<TopUpCreateWithoutAdminInput, TopUpUncheckedCreateWithoutAdminInput> | TopUpCreateWithoutAdminInput[] | TopUpUncheckedCreateWithoutAdminInput[]
    connectOrCreate?: TopUpCreateOrConnectWithoutAdminInput | TopUpCreateOrConnectWithoutAdminInput[]
    upsert?: TopUpUpsertWithWhereUniqueWithoutAdminInput | TopUpUpsertWithWhereUniqueWithoutAdminInput[]
    createMany?: TopUpCreateManyAdminInputEnvelope
    set?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    disconnect?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    delete?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    connect?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    update?: TopUpUpdateWithWhereUniqueWithoutAdminInput | TopUpUpdateWithWhereUniqueWithoutAdminInput[]
    updateMany?: TopUpUpdateManyWithWhereWithoutAdminInput | TopUpUpdateManyWithWhereWithoutAdminInput[]
    deleteMany?: TopUpScalarWhereInput | TopUpScalarWhereInput[]
  }

  export type TopUpUncheckedUpdateManyWithoutAdminNestedInput = {
    create?: XOR<TopUpCreateWithoutAdminInput, TopUpUncheckedCreateWithoutAdminInput> | TopUpCreateWithoutAdminInput[] | TopUpUncheckedCreateWithoutAdminInput[]
    connectOrCreate?: TopUpCreateOrConnectWithoutAdminInput | TopUpCreateOrConnectWithoutAdminInput[]
    upsert?: TopUpUpsertWithWhereUniqueWithoutAdminInput | TopUpUpsertWithWhereUniqueWithoutAdminInput[]
    createMany?: TopUpCreateManyAdminInputEnvelope
    set?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    disconnect?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    delete?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    connect?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    update?: TopUpUpdateWithWhereUniqueWithoutAdminInput | TopUpUpdateWithWhereUniqueWithoutAdminInput[]
    updateMany?: TopUpUpdateManyWithWhereWithoutAdminInput | TopUpUpdateManyWithWhereWithoutAdminInput[]
    deleteMany?: TopUpScalarWhereInput | TopUpScalarWhereInput[]
  }

  export type WishlistCreateNestedManyWithoutUserInput = {
    create?: XOR<WishlistCreateWithoutUserInput, WishlistUncheckedCreateWithoutUserInput> | WishlistCreateWithoutUserInput[] | WishlistUncheckedCreateWithoutUserInput[]
    connectOrCreate?: WishlistCreateOrConnectWithoutUserInput | WishlistCreateOrConnectWithoutUserInput[]
    createMany?: WishlistCreateManyUserInputEnvelope
    connect?: WishlistWhereUniqueInput | WishlistWhereUniqueInput[]
  }

  export type TopUpCreateNestedManyWithoutUserInput = {
    create?: XOR<TopUpCreateWithoutUserInput, TopUpUncheckedCreateWithoutUserInput> | TopUpCreateWithoutUserInput[] | TopUpUncheckedCreateWithoutUserInput[]
    connectOrCreate?: TopUpCreateOrConnectWithoutUserInput | TopUpCreateOrConnectWithoutUserInput[]
    createMany?: TopUpCreateManyUserInputEnvelope
    connect?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
  }

  export type TransactionCreateNestedManyWithoutUserInput = {
    create?: XOR<TransactionCreateWithoutUserInput, TransactionUncheckedCreateWithoutUserInput> | TransactionCreateWithoutUserInput[] | TransactionUncheckedCreateWithoutUserInput[]
    connectOrCreate?: TransactionCreateOrConnectWithoutUserInput | TransactionCreateOrConnectWithoutUserInput[]
    createMany?: TransactionCreateManyUserInputEnvelope
    connect?: TransactionWhereUniqueInput | TransactionWhereUniqueInput[]
  }

  export type UserVerificationTokenCreateNestedManyWithoutUserInput = {
    create?: XOR<UserVerificationTokenCreateWithoutUserInput, UserVerificationTokenUncheckedCreateWithoutUserInput> | UserVerificationTokenCreateWithoutUserInput[] | UserVerificationTokenUncheckedCreateWithoutUserInput[]
    connectOrCreate?: UserVerificationTokenCreateOrConnectWithoutUserInput | UserVerificationTokenCreateOrConnectWithoutUserInput[]
    createMany?: UserVerificationTokenCreateManyUserInputEnvelope
    connect?: UserVerificationTokenWhereUniqueInput | UserVerificationTokenWhereUniqueInput[]
  }

  export type WishlistUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<WishlistCreateWithoutUserInput, WishlistUncheckedCreateWithoutUserInput> | WishlistCreateWithoutUserInput[] | WishlistUncheckedCreateWithoutUserInput[]
    connectOrCreate?: WishlistCreateOrConnectWithoutUserInput | WishlistCreateOrConnectWithoutUserInput[]
    createMany?: WishlistCreateManyUserInputEnvelope
    connect?: WishlistWhereUniqueInput | WishlistWhereUniqueInput[]
  }

  export type TopUpUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<TopUpCreateWithoutUserInput, TopUpUncheckedCreateWithoutUserInput> | TopUpCreateWithoutUserInput[] | TopUpUncheckedCreateWithoutUserInput[]
    connectOrCreate?: TopUpCreateOrConnectWithoutUserInput | TopUpCreateOrConnectWithoutUserInput[]
    createMany?: TopUpCreateManyUserInputEnvelope
    connect?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
  }

  export type TransactionUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<TransactionCreateWithoutUserInput, TransactionUncheckedCreateWithoutUserInput> | TransactionCreateWithoutUserInput[] | TransactionUncheckedCreateWithoutUserInput[]
    connectOrCreate?: TransactionCreateOrConnectWithoutUserInput | TransactionCreateOrConnectWithoutUserInput[]
    createMany?: TransactionCreateManyUserInputEnvelope
    connect?: TransactionWhereUniqueInput | TransactionWhereUniqueInput[]
  }

  export type UserVerificationTokenUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<UserVerificationTokenCreateWithoutUserInput, UserVerificationTokenUncheckedCreateWithoutUserInput> | UserVerificationTokenCreateWithoutUserInput[] | UserVerificationTokenUncheckedCreateWithoutUserInput[]
    connectOrCreate?: UserVerificationTokenCreateOrConnectWithoutUserInput | UserVerificationTokenCreateOrConnectWithoutUserInput[]
    createMany?: UserVerificationTokenCreateManyUserInputEnvelope
    connect?: UserVerificationTokenWhereUniqueInput | UserVerificationTokenWhereUniqueInput[]
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type WishlistUpdateManyWithoutUserNestedInput = {
    create?: XOR<WishlistCreateWithoutUserInput, WishlistUncheckedCreateWithoutUserInput> | WishlistCreateWithoutUserInput[] | WishlistUncheckedCreateWithoutUserInput[]
    connectOrCreate?: WishlistCreateOrConnectWithoutUserInput | WishlistCreateOrConnectWithoutUserInput[]
    upsert?: WishlistUpsertWithWhereUniqueWithoutUserInput | WishlistUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: WishlistCreateManyUserInputEnvelope
    set?: WishlistWhereUniqueInput | WishlistWhereUniqueInput[]
    disconnect?: WishlistWhereUniqueInput | WishlistWhereUniqueInput[]
    delete?: WishlistWhereUniqueInput | WishlistWhereUniqueInput[]
    connect?: WishlistWhereUniqueInput | WishlistWhereUniqueInput[]
    update?: WishlistUpdateWithWhereUniqueWithoutUserInput | WishlistUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: WishlistUpdateManyWithWhereWithoutUserInput | WishlistUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: WishlistScalarWhereInput | WishlistScalarWhereInput[]
  }

  export type TopUpUpdateManyWithoutUserNestedInput = {
    create?: XOR<TopUpCreateWithoutUserInput, TopUpUncheckedCreateWithoutUserInput> | TopUpCreateWithoutUserInput[] | TopUpUncheckedCreateWithoutUserInput[]
    connectOrCreate?: TopUpCreateOrConnectWithoutUserInput | TopUpCreateOrConnectWithoutUserInput[]
    upsert?: TopUpUpsertWithWhereUniqueWithoutUserInput | TopUpUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: TopUpCreateManyUserInputEnvelope
    set?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    disconnect?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    delete?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    connect?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    update?: TopUpUpdateWithWhereUniqueWithoutUserInput | TopUpUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: TopUpUpdateManyWithWhereWithoutUserInput | TopUpUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: TopUpScalarWhereInput | TopUpScalarWhereInput[]
  }

  export type TransactionUpdateManyWithoutUserNestedInput = {
    create?: XOR<TransactionCreateWithoutUserInput, TransactionUncheckedCreateWithoutUserInput> | TransactionCreateWithoutUserInput[] | TransactionUncheckedCreateWithoutUserInput[]
    connectOrCreate?: TransactionCreateOrConnectWithoutUserInput | TransactionCreateOrConnectWithoutUserInput[]
    upsert?: TransactionUpsertWithWhereUniqueWithoutUserInput | TransactionUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: TransactionCreateManyUserInputEnvelope
    set?: TransactionWhereUniqueInput | TransactionWhereUniqueInput[]
    disconnect?: TransactionWhereUniqueInput | TransactionWhereUniqueInput[]
    delete?: TransactionWhereUniqueInput | TransactionWhereUniqueInput[]
    connect?: TransactionWhereUniqueInput | TransactionWhereUniqueInput[]
    update?: TransactionUpdateWithWhereUniqueWithoutUserInput | TransactionUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: TransactionUpdateManyWithWhereWithoutUserInput | TransactionUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: TransactionScalarWhereInput | TransactionScalarWhereInput[]
  }

  export type UserVerificationTokenUpdateManyWithoutUserNestedInput = {
    create?: XOR<UserVerificationTokenCreateWithoutUserInput, UserVerificationTokenUncheckedCreateWithoutUserInput> | UserVerificationTokenCreateWithoutUserInput[] | UserVerificationTokenUncheckedCreateWithoutUserInput[]
    connectOrCreate?: UserVerificationTokenCreateOrConnectWithoutUserInput | UserVerificationTokenCreateOrConnectWithoutUserInput[]
    upsert?: UserVerificationTokenUpsertWithWhereUniqueWithoutUserInput | UserVerificationTokenUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: UserVerificationTokenCreateManyUserInputEnvelope
    set?: UserVerificationTokenWhereUniqueInput | UserVerificationTokenWhereUniqueInput[]
    disconnect?: UserVerificationTokenWhereUniqueInput | UserVerificationTokenWhereUniqueInput[]
    delete?: UserVerificationTokenWhereUniqueInput | UserVerificationTokenWhereUniqueInput[]
    connect?: UserVerificationTokenWhereUniqueInput | UserVerificationTokenWhereUniqueInput[]
    update?: UserVerificationTokenUpdateWithWhereUniqueWithoutUserInput | UserVerificationTokenUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: UserVerificationTokenUpdateManyWithWhereWithoutUserInput | UserVerificationTokenUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: UserVerificationTokenScalarWhereInput | UserVerificationTokenScalarWhereInput[]
  }

  export type WishlistUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<WishlistCreateWithoutUserInput, WishlistUncheckedCreateWithoutUserInput> | WishlistCreateWithoutUserInput[] | WishlistUncheckedCreateWithoutUserInput[]
    connectOrCreate?: WishlistCreateOrConnectWithoutUserInput | WishlistCreateOrConnectWithoutUserInput[]
    upsert?: WishlistUpsertWithWhereUniqueWithoutUserInput | WishlistUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: WishlistCreateManyUserInputEnvelope
    set?: WishlistWhereUniqueInput | WishlistWhereUniqueInput[]
    disconnect?: WishlistWhereUniqueInput | WishlistWhereUniqueInput[]
    delete?: WishlistWhereUniqueInput | WishlistWhereUniqueInput[]
    connect?: WishlistWhereUniqueInput | WishlistWhereUniqueInput[]
    update?: WishlistUpdateWithWhereUniqueWithoutUserInput | WishlistUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: WishlistUpdateManyWithWhereWithoutUserInput | WishlistUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: WishlistScalarWhereInput | WishlistScalarWhereInput[]
  }

  export type TopUpUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<TopUpCreateWithoutUserInput, TopUpUncheckedCreateWithoutUserInput> | TopUpCreateWithoutUserInput[] | TopUpUncheckedCreateWithoutUserInput[]
    connectOrCreate?: TopUpCreateOrConnectWithoutUserInput | TopUpCreateOrConnectWithoutUserInput[]
    upsert?: TopUpUpsertWithWhereUniqueWithoutUserInput | TopUpUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: TopUpCreateManyUserInputEnvelope
    set?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    disconnect?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    delete?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    connect?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    update?: TopUpUpdateWithWhereUniqueWithoutUserInput | TopUpUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: TopUpUpdateManyWithWhereWithoutUserInput | TopUpUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: TopUpScalarWhereInput | TopUpScalarWhereInput[]
  }

  export type TransactionUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<TransactionCreateWithoutUserInput, TransactionUncheckedCreateWithoutUserInput> | TransactionCreateWithoutUserInput[] | TransactionUncheckedCreateWithoutUserInput[]
    connectOrCreate?: TransactionCreateOrConnectWithoutUserInput | TransactionCreateOrConnectWithoutUserInput[]
    upsert?: TransactionUpsertWithWhereUniqueWithoutUserInput | TransactionUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: TransactionCreateManyUserInputEnvelope
    set?: TransactionWhereUniqueInput | TransactionWhereUniqueInput[]
    disconnect?: TransactionWhereUniqueInput | TransactionWhereUniqueInput[]
    delete?: TransactionWhereUniqueInput | TransactionWhereUniqueInput[]
    connect?: TransactionWhereUniqueInput | TransactionWhereUniqueInput[]
    update?: TransactionUpdateWithWhereUniqueWithoutUserInput | TransactionUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: TransactionUpdateManyWithWhereWithoutUserInput | TransactionUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: TransactionScalarWhereInput | TransactionScalarWhereInput[]
  }

  export type UserVerificationTokenUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<UserVerificationTokenCreateWithoutUserInput, UserVerificationTokenUncheckedCreateWithoutUserInput> | UserVerificationTokenCreateWithoutUserInput[] | UserVerificationTokenUncheckedCreateWithoutUserInput[]
    connectOrCreate?: UserVerificationTokenCreateOrConnectWithoutUserInput | UserVerificationTokenCreateOrConnectWithoutUserInput[]
    upsert?: UserVerificationTokenUpsertWithWhereUniqueWithoutUserInput | UserVerificationTokenUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: UserVerificationTokenCreateManyUserInputEnvelope
    set?: UserVerificationTokenWhereUniqueInput | UserVerificationTokenWhereUniqueInput[]
    disconnect?: UserVerificationTokenWhereUniqueInput | UserVerificationTokenWhereUniqueInput[]
    delete?: UserVerificationTokenWhereUniqueInput | UserVerificationTokenWhereUniqueInput[]
    connect?: UserVerificationTokenWhereUniqueInput | UserVerificationTokenWhereUniqueInput[]
    update?: UserVerificationTokenUpdateWithWhereUniqueWithoutUserInput | UserVerificationTokenUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: UserVerificationTokenUpdateManyWithWhereWithoutUserInput | UserVerificationTokenUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: UserVerificationTokenScalarWhereInput | UserVerificationTokenScalarWhereInput[]
  }

  export type UserCreateNestedOneWithoutUserVerificationTokensInput = {
    create?: XOR<UserCreateWithoutUserVerificationTokensInput, UserUncheckedCreateWithoutUserVerificationTokensInput>
    connectOrCreate?: UserCreateOrConnectWithoutUserVerificationTokensInput
    connect?: UserWhereUniqueInput
  }

  export type NullableDateTimeFieldUpdateOperationsInput = {
    set?: Date | string | null
  }

  export type UserUpdateOneRequiredWithoutUserVerificationTokensNestedInput = {
    create?: XOR<UserCreateWithoutUserVerificationTokensInput, UserUncheckedCreateWithoutUserVerificationTokensInput>
    connectOrCreate?: UserCreateOrConnectWithoutUserVerificationTokensInput
    upsert?: UserUpsertWithoutUserVerificationTokensInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutUserVerificationTokensInput, UserUpdateWithoutUserVerificationTokensInput>, UserUncheckedUpdateWithoutUserVerificationTokensInput>
  }

  export type ProductCreateNestedManyWithoutCategoryInput = {
    create?: XOR<ProductCreateWithoutCategoryInput, ProductUncheckedCreateWithoutCategoryInput> | ProductCreateWithoutCategoryInput[] | ProductUncheckedCreateWithoutCategoryInput[]
    connectOrCreate?: ProductCreateOrConnectWithoutCategoryInput | ProductCreateOrConnectWithoutCategoryInput[]
    createMany?: ProductCreateManyCategoryInputEnvelope
    connect?: ProductWhereUniqueInput | ProductWhereUniqueInput[]
  }

  export type ProductUncheckedCreateNestedManyWithoutCategoryInput = {
    create?: XOR<ProductCreateWithoutCategoryInput, ProductUncheckedCreateWithoutCategoryInput> | ProductCreateWithoutCategoryInput[] | ProductUncheckedCreateWithoutCategoryInput[]
    connectOrCreate?: ProductCreateOrConnectWithoutCategoryInput | ProductCreateOrConnectWithoutCategoryInput[]
    createMany?: ProductCreateManyCategoryInputEnvelope
    connect?: ProductWhereUniqueInput | ProductWhereUniqueInput[]
  }

  export type ProductUpdateManyWithoutCategoryNestedInput = {
    create?: XOR<ProductCreateWithoutCategoryInput, ProductUncheckedCreateWithoutCategoryInput> | ProductCreateWithoutCategoryInput[] | ProductUncheckedCreateWithoutCategoryInput[]
    connectOrCreate?: ProductCreateOrConnectWithoutCategoryInput | ProductCreateOrConnectWithoutCategoryInput[]
    upsert?: ProductUpsertWithWhereUniqueWithoutCategoryInput | ProductUpsertWithWhereUniqueWithoutCategoryInput[]
    createMany?: ProductCreateManyCategoryInputEnvelope
    set?: ProductWhereUniqueInput | ProductWhereUniqueInput[]
    disconnect?: ProductWhereUniqueInput | ProductWhereUniqueInput[]
    delete?: ProductWhereUniqueInput | ProductWhereUniqueInput[]
    connect?: ProductWhereUniqueInput | ProductWhereUniqueInput[]
    update?: ProductUpdateWithWhereUniqueWithoutCategoryInput | ProductUpdateWithWhereUniqueWithoutCategoryInput[]
    updateMany?: ProductUpdateManyWithWhereWithoutCategoryInput | ProductUpdateManyWithWhereWithoutCategoryInput[]
    deleteMany?: ProductScalarWhereInput | ProductScalarWhereInput[]
  }

  export type ProductUncheckedUpdateManyWithoutCategoryNestedInput = {
    create?: XOR<ProductCreateWithoutCategoryInput, ProductUncheckedCreateWithoutCategoryInput> | ProductCreateWithoutCategoryInput[] | ProductUncheckedCreateWithoutCategoryInput[]
    connectOrCreate?: ProductCreateOrConnectWithoutCategoryInput | ProductCreateOrConnectWithoutCategoryInput[]
    upsert?: ProductUpsertWithWhereUniqueWithoutCategoryInput | ProductUpsertWithWhereUniqueWithoutCategoryInput[]
    createMany?: ProductCreateManyCategoryInputEnvelope
    set?: ProductWhereUniqueInput | ProductWhereUniqueInput[]
    disconnect?: ProductWhereUniqueInput | ProductWhereUniqueInput[]
    delete?: ProductWhereUniqueInput | ProductWhereUniqueInput[]
    connect?: ProductWhereUniqueInput | ProductWhereUniqueInput[]
    update?: ProductUpdateWithWhereUniqueWithoutCategoryInput | ProductUpdateWithWhereUniqueWithoutCategoryInput[]
    updateMany?: ProductUpdateManyWithWhereWithoutCategoryInput | ProductUpdateManyWithWhereWithoutCategoryInput[]
    deleteMany?: ProductScalarWhereInput | ProductScalarWhereInput[]
  }

  export type CategoryCreateNestedOneWithoutProductsInput = {
    create?: XOR<CategoryCreateWithoutProductsInput, CategoryUncheckedCreateWithoutProductsInput>
    connectOrCreate?: CategoryCreateOrConnectWithoutProductsInput
    connect?: CategoryWhereUniqueInput
  }

  export type StockMutationCreateNestedManyWithoutProductInput = {
    create?: XOR<StockMutationCreateWithoutProductInput, StockMutationUncheckedCreateWithoutProductInput> | StockMutationCreateWithoutProductInput[] | StockMutationUncheckedCreateWithoutProductInput[]
    connectOrCreate?: StockMutationCreateOrConnectWithoutProductInput | StockMutationCreateOrConnectWithoutProductInput[]
    createMany?: StockMutationCreateManyProductInputEnvelope
    connect?: StockMutationWhereUniqueInput | StockMutationWhereUniqueInput[]
  }

  export type WishlistCreateNestedManyWithoutProductInput = {
    create?: XOR<WishlistCreateWithoutProductInput, WishlistUncheckedCreateWithoutProductInput> | WishlistCreateWithoutProductInput[] | WishlistUncheckedCreateWithoutProductInput[]
    connectOrCreate?: WishlistCreateOrConnectWithoutProductInput | WishlistCreateOrConnectWithoutProductInput[]
    createMany?: WishlistCreateManyProductInputEnvelope
    connect?: WishlistWhereUniqueInput | WishlistWhereUniqueInput[]
  }

  export type TransactionDetailsCreateNestedManyWithoutProductInput = {
    create?: XOR<TransactionDetailsCreateWithoutProductInput, TransactionDetailsUncheckedCreateWithoutProductInput> | TransactionDetailsCreateWithoutProductInput[] | TransactionDetailsUncheckedCreateWithoutProductInput[]
    connectOrCreate?: TransactionDetailsCreateOrConnectWithoutProductInput | TransactionDetailsCreateOrConnectWithoutProductInput[]
    createMany?: TransactionDetailsCreateManyProductInputEnvelope
    connect?: TransactionDetailsWhereUniqueInput | TransactionDetailsWhereUniqueInput[]
  }

  export type StockMutationUncheckedCreateNestedManyWithoutProductInput = {
    create?: XOR<StockMutationCreateWithoutProductInput, StockMutationUncheckedCreateWithoutProductInput> | StockMutationCreateWithoutProductInput[] | StockMutationUncheckedCreateWithoutProductInput[]
    connectOrCreate?: StockMutationCreateOrConnectWithoutProductInput | StockMutationCreateOrConnectWithoutProductInput[]
    createMany?: StockMutationCreateManyProductInputEnvelope
    connect?: StockMutationWhereUniqueInput | StockMutationWhereUniqueInput[]
  }

  export type WishlistUncheckedCreateNestedManyWithoutProductInput = {
    create?: XOR<WishlistCreateWithoutProductInput, WishlistUncheckedCreateWithoutProductInput> | WishlistCreateWithoutProductInput[] | WishlistUncheckedCreateWithoutProductInput[]
    connectOrCreate?: WishlistCreateOrConnectWithoutProductInput | WishlistCreateOrConnectWithoutProductInput[]
    createMany?: WishlistCreateManyProductInputEnvelope
    connect?: WishlistWhereUniqueInput | WishlistWhereUniqueInput[]
  }

  export type TransactionDetailsUncheckedCreateNestedManyWithoutProductInput = {
    create?: XOR<TransactionDetailsCreateWithoutProductInput, TransactionDetailsUncheckedCreateWithoutProductInput> | TransactionDetailsCreateWithoutProductInput[] | TransactionDetailsUncheckedCreateWithoutProductInput[]
    connectOrCreate?: TransactionDetailsCreateOrConnectWithoutProductInput | TransactionDetailsCreateOrConnectWithoutProductInput[]
    createMany?: TransactionDetailsCreateManyProductInputEnvelope
    connect?: TransactionDetailsWhereUniqueInput | TransactionDetailsWhereUniqueInput[]
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type CategoryUpdateOneRequiredWithoutProductsNestedInput = {
    create?: XOR<CategoryCreateWithoutProductsInput, CategoryUncheckedCreateWithoutProductsInput>
    connectOrCreate?: CategoryCreateOrConnectWithoutProductsInput
    upsert?: CategoryUpsertWithoutProductsInput
    connect?: CategoryWhereUniqueInput
    update?: XOR<XOR<CategoryUpdateToOneWithWhereWithoutProductsInput, CategoryUpdateWithoutProductsInput>, CategoryUncheckedUpdateWithoutProductsInput>
  }

  export type StockMutationUpdateManyWithoutProductNestedInput = {
    create?: XOR<StockMutationCreateWithoutProductInput, StockMutationUncheckedCreateWithoutProductInput> | StockMutationCreateWithoutProductInput[] | StockMutationUncheckedCreateWithoutProductInput[]
    connectOrCreate?: StockMutationCreateOrConnectWithoutProductInput | StockMutationCreateOrConnectWithoutProductInput[]
    upsert?: StockMutationUpsertWithWhereUniqueWithoutProductInput | StockMutationUpsertWithWhereUniqueWithoutProductInput[]
    createMany?: StockMutationCreateManyProductInputEnvelope
    set?: StockMutationWhereUniqueInput | StockMutationWhereUniqueInput[]
    disconnect?: StockMutationWhereUniqueInput | StockMutationWhereUniqueInput[]
    delete?: StockMutationWhereUniqueInput | StockMutationWhereUniqueInput[]
    connect?: StockMutationWhereUniqueInput | StockMutationWhereUniqueInput[]
    update?: StockMutationUpdateWithWhereUniqueWithoutProductInput | StockMutationUpdateWithWhereUniqueWithoutProductInput[]
    updateMany?: StockMutationUpdateManyWithWhereWithoutProductInput | StockMutationUpdateManyWithWhereWithoutProductInput[]
    deleteMany?: StockMutationScalarWhereInput | StockMutationScalarWhereInput[]
  }

  export type WishlistUpdateManyWithoutProductNestedInput = {
    create?: XOR<WishlistCreateWithoutProductInput, WishlistUncheckedCreateWithoutProductInput> | WishlistCreateWithoutProductInput[] | WishlistUncheckedCreateWithoutProductInput[]
    connectOrCreate?: WishlistCreateOrConnectWithoutProductInput | WishlistCreateOrConnectWithoutProductInput[]
    upsert?: WishlistUpsertWithWhereUniqueWithoutProductInput | WishlistUpsertWithWhereUniqueWithoutProductInput[]
    createMany?: WishlistCreateManyProductInputEnvelope
    set?: WishlistWhereUniqueInput | WishlistWhereUniqueInput[]
    disconnect?: WishlistWhereUniqueInput | WishlistWhereUniqueInput[]
    delete?: WishlistWhereUniqueInput | WishlistWhereUniqueInput[]
    connect?: WishlistWhereUniqueInput | WishlistWhereUniqueInput[]
    update?: WishlistUpdateWithWhereUniqueWithoutProductInput | WishlistUpdateWithWhereUniqueWithoutProductInput[]
    updateMany?: WishlistUpdateManyWithWhereWithoutProductInput | WishlistUpdateManyWithWhereWithoutProductInput[]
    deleteMany?: WishlistScalarWhereInput | WishlistScalarWhereInput[]
  }

  export type TransactionDetailsUpdateManyWithoutProductNestedInput = {
    create?: XOR<TransactionDetailsCreateWithoutProductInput, TransactionDetailsUncheckedCreateWithoutProductInput> | TransactionDetailsCreateWithoutProductInput[] | TransactionDetailsUncheckedCreateWithoutProductInput[]
    connectOrCreate?: TransactionDetailsCreateOrConnectWithoutProductInput | TransactionDetailsCreateOrConnectWithoutProductInput[]
    upsert?: TransactionDetailsUpsertWithWhereUniqueWithoutProductInput | TransactionDetailsUpsertWithWhereUniqueWithoutProductInput[]
    createMany?: TransactionDetailsCreateManyProductInputEnvelope
    set?: TransactionDetailsWhereUniqueInput | TransactionDetailsWhereUniqueInput[]
    disconnect?: TransactionDetailsWhereUniqueInput | TransactionDetailsWhereUniqueInput[]
    delete?: TransactionDetailsWhereUniqueInput | TransactionDetailsWhereUniqueInput[]
    connect?: TransactionDetailsWhereUniqueInput | TransactionDetailsWhereUniqueInput[]
    update?: TransactionDetailsUpdateWithWhereUniqueWithoutProductInput | TransactionDetailsUpdateWithWhereUniqueWithoutProductInput[]
    updateMany?: TransactionDetailsUpdateManyWithWhereWithoutProductInput | TransactionDetailsUpdateManyWithWhereWithoutProductInput[]
    deleteMany?: TransactionDetailsScalarWhereInput | TransactionDetailsScalarWhereInput[]
  }

  export type StockMutationUncheckedUpdateManyWithoutProductNestedInput = {
    create?: XOR<StockMutationCreateWithoutProductInput, StockMutationUncheckedCreateWithoutProductInput> | StockMutationCreateWithoutProductInput[] | StockMutationUncheckedCreateWithoutProductInput[]
    connectOrCreate?: StockMutationCreateOrConnectWithoutProductInput | StockMutationCreateOrConnectWithoutProductInput[]
    upsert?: StockMutationUpsertWithWhereUniqueWithoutProductInput | StockMutationUpsertWithWhereUniqueWithoutProductInput[]
    createMany?: StockMutationCreateManyProductInputEnvelope
    set?: StockMutationWhereUniqueInput | StockMutationWhereUniqueInput[]
    disconnect?: StockMutationWhereUniqueInput | StockMutationWhereUniqueInput[]
    delete?: StockMutationWhereUniqueInput | StockMutationWhereUniqueInput[]
    connect?: StockMutationWhereUniqueInput | StockMutationWhereUniqueInput[]
    update?: StockMutationUpdateWithWhereUniqueWithoutProductInput | StockMutationUpdateWithWhereUniqueWithoutProductInput[]
    updateMany?: StockMutationUpdateManyWithWhereWithoutProductInput | StockMutationUpdateManyWithWhereWithoutProductInput[]
    deleteMany?: StockMutationScalarWhereInput | StockMutationScalarWhereInput[]
  }

  export type WishlistUncheckedUpdateManyWithoutProductNestedInput = {
    create?: XOR<WishlistCreateWithoutProductInput, WishlistUncheckedCreateWithoutProductInput> | WishlistCreateWithoutProductInput[] | WishlistUncheckedCreateWithoutProductInput[]
    connectOrCreate?: WishlistCreateOrConnectWithoutProductInput | WishlistCreateOrConnectWithoutProductInput[]
    upsert?: WishlistUpsertWithWhereUniqueWithoutProductInput | WishlistUpsertWithWhereUniqueWithoutProductInput[]
    createMany?: WishlistCreateManyProductInputEnvelope
    set?: WishlistWhereUniqueInput | WishlistWhereUniqueInput[]
    disconnect?: WishlistWhereUniqueInput | WishlistWhereUniqueInput[]
    delete?: WishlistWhereUniqueInput | WishlistWhereUniqueInput[]
    connect?: WishlistWhereUniqueInput | WishlistWhereUniqueInput[]
    update?: WishlistUpdateWithWhereUniqueWithoutProductInput | WishlistUpdateWithWhereUniqueWithoutProductInput[]
    updateMany?: WishlistUpdateManyWithWhereWithoutProductInput | WishlistUpdateManyWithWhereWithoutProductInput[]
    deleteMany?: WishlistScalarWhereInput | WishlistScalarWhereInput[]
  }

  export type TransactionDetailsUncheckedUpdateManyWithoutProductNestedInput = {
    create?: XOR<TransactionDetailsCreateWithoutProductInput, TransactionDetailsUncheckedCreateWithoutProductInput> | TransactionDetailsCreateWithoutProductInput[] | TransactionDetailsUncheckedCreateWithoutProductInput[]
    connectOrCreate?: TransactionDetailsCreateOrConnectWithoutProductInput | TransactionDetailsCreateOrConnectWithoutProductInput[]
    upsert?: TransactionDetailsUpsertWithWhereUniqueWithoutProductInput | TransactionDetailsUpsertWithWhereUniqueWithoutProductInput[]
    createMany?: TransactionDetailsCreateManyProductInputEnvelope
    set?: TransactionDetailsWhereUniqueInput | TransactionDetailsWhereUniqueInput[]
    disconnect?: TransactionDetailsWhereUniqueInput | TransactionDetailsWhereUniqueInput[]
    delete?: TransactionDetailsWhereUniqueInput | TransactionDetailsWhereUniqueInput[]
    connect?: TransactionDetailsWhereUniqueInput | TransactionDetailsWhereUniqueInput[]
    update?: TransactionDetailsUpdateWithWhereUniqueWithoutProductInput | TransactionDetailsUpdateWithWhereUniqueWithoutProductInput[]
    updateMany?: TransactionDetailsUpdateManyWithWhereWithoutProductInput | TransactionDetailsUpdateManyWithWhereWithoutProductInput[]
    deleteMany?: TransactionDetailsScalarWhereInput | TransactionDetailsScalarWhereInput[]
  }

  export type ProductCreateNestedOneWithoutStockMutationsInput = {
    create?: XOR<ProductCreateWithoutStockMutationsInput, ProductUncheckedCreateWithoutStockMutationsInput>
    connectOrCreate?: ProductCreateOrConnectWithoutStockMutationsInput
    connect?: ProductWhereUniqueInput
  }

  export type ProductUpdateOneRequiredWithoutStockMutationsNestedInput = {
    create?: XOR<ProductCreateWithoutStockMutationsInput, ProductUncheckedCreateWithoutStockMutationsInput>
    connectOrCreate?: ProductCreateOrConnectWithoutStockMutationsInput
    upsert?: ProductUpsertWithoutStockMutationsInput
    connect?: ProductWhereUniqueInput
    update?: XOR<XOR<ProductUpdateToOneWithWhereWithoutStockMutationsInput, ProductUpdateWithoutStockMutationsInput>, ProductUncheckedUpdateWithoutStockMutationsInput>
  }

  export type PaymentAccountCreateNestedManyWithoutPaymentTermInput = {
    create?: XOR<PaymentAccountCreateWithoutPaymentTermInput, PaymentAccountUncheckedCreateWithoutPaymentTermInput> | PaymentAccountCreateWithoutPaymentTermInput[] | PaymentAccountUncheckedCreateWithoutPaymentTermInput[]
    connectOrCreate?: PaymentAccountCreateOrConnectWithoutPaymentTermInput | PaymentAccountCreateOrConnectWithoutPaymentTermInput[]
    createMany?: PaymentAccountCreateManyPaymentTermInputEnvelope
    connect?: PaymentAccountWhereUniqueInput | PaymentAccountWhereUniqueInput[]
  }

  export type TopUpCreateNestedManyWithoutPaymentTermInput = {
    create?: XOR<TopUpCreateWithoutPaymentTermInput, TopUpUncheckedCreateWithoutPaymentTermInput> | TopUpCreateWithoutPaymentTermInput[] | TopUpUncheckedCreateWithoutPaymentTermInput[]
    connectOrCreate?: TopUpCreateOrConnectWithoutPaymentTermInput | TopUpCreateOrConnectWithoutPaymentTermInput[]
    createMany?: TopUpCreateManyPaymentTermInputEnvelope
    connect?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
  }

  export type PaymentAccountUncheckedCreateNestedManyWithoutPaymentTermInput = {
    create?: XOR<PaymentAccountCreateWithoutPaymentTermInput, PaymentAccountUncheckedCreateWithoutPaymentTermInput> | PaymentAccountCreateWithoutPaymentTermInput[] | PaymentAccountUncheckedCreateWithoutPaymentTermInput[]
    connectOrCreate?: PaymentAccountCreateOrConnectWithoutPaymentTermInput | PaymentAccountCreateOrConnectWithoutPaymentTermInput[]
    createMany?: PaymentAccountCreateManyPaymentTermInputEnvelope
    connect?: PaymentAccountWhereUniqueInput | PaymentAccountWhereUniqueInput[]
  }

  export type TopUpUncheckedCreateNestedManyWithoutPaymentTermInput = {
    create?: XOR<TopUpCreateWithoutPaymentTermInput, TopUpUncheckedCreateWithoutPaymentTermInput> | TopUpCreateWithoutPaymentTermInput[] | TopUpUncheckedCreateWithoutPaymentTermInput[]
    connectOrCreate?: TopUpCreateOrConnectWithoutPaymentTermInput | TopUpCreateOrConnectWithoutPaymentTermInput[]
    createMany?: TopUpCreateManyPaymentTermInputEnvelope
    connect?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
  }

  export type PaymentAccountUpdateManyWithoutPaymentTermNestedInput = {
    create?: XOR<PaymentAccountCreateWithoutPaymentTermInput, PaymentAccountUncheckedCreateWithoutPaymentTermInput> | PaymentAccountCreateWithoutPaymentTermInput[] | PaymentAccountUncheckedCreateWithoutPaymentTermInput[]
    connectOrCreate?: PaymentAccountCreateOrConnectWithoutPaymentTermInput | PaymentAccountCreateOrConnectWithoutPaymentTermInput[]
    upsert?: PaymentAccountUpsertWithWhereUniqueWithoutPaymentTermInput | PaymentAccountUpsertWithWhereUniqueWithoutPaymentTermInput[]
    createMany?: PaymentAccountCreateManyPaymentTermInputEnvelope
    set?: PaymentAccountWhereUniqueInput | PaymentAccountWhereUniqueInput[]
    disconnect?: PaymentAccountWhereUniqueInput | PaymentAccountWhereUniqueInput[]
    delete?: PaymentAccountWhereUniqueInput | PaymentAccountWhereUniqueInput[]
    connect?: PaymentAccountWhereUniqueInput | PaymentAccountWhereUniqueInput[]
    update?: PaymentAccountUpdateWithWhereUniqueWithoutPaymentTermInput | PaymentAccountUpdateWithWhereUniqueWithoutPaymentTermInput[]
    updateMany?: PaymentAccountUpdateManyWithWhereWithoutPaymentTermInput | PaymentAccountUpdateManyWithWhereWithoutPaymentTermInput[]
    deleteMany?: PaymentAccountScalarWhereInput | PaymentAccountScalarWhereInput[]
  }

  export type TopUpUpdateManyWithoutPaymentTermNestedInput = {
    create?: XOR<TopUpCreateWithoutPaymentTermInput, TopUpUncheckedCreateWithoutPaymentTermInput> | TopUpCreateWithoutPaymentTermInput[] | TopUpUncheckedCreateWithoutPaymentTermInput[]
    connectOrCreate?: TopUpCreateOrConnectWithoutPaymentTermInput | TopUpCreateOrConnectWithoutPaymentTermInput[]
    upsert?: TopUpUpsertWithWhereUniqueWithoutPaymentTermInput | TopUpUpsertWithWhereUniqueWithoutPaymentTermInput[]
    createMany?: TopUpCreateManyPaymentTermInputEnvelope
    set?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    disconnect?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    delete?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    connect?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    update?: TopUpUpdateWithWhereUniqueWithoutPaymentTermInput | TopUpUpdateWithWhereUniqueWithoutPaymentTermInput[]
    updateMany?: TopUpUpdateManyWithWhereWithoutPaymentTermInput | TopUpUpdateManyWithWhereWithoutPaymentTermInput[]
    deleteMany?: TopUpScalarWhereInput | TopUpScalarWhereInput[]
  }

  export type PaymentAccountUncheckedUpdateManyWithoutPaymentTermNestedInput = {
    create?: XOR<PaymentAccountCreateWithoutPaymentTermInput, PaymentAccountUncheckedCreateWithoutPaymentTermInput> | PaymentAccountCreateWithoutPaymentTermInput[] | PaymentAccountUncheckedCreateWithoutPaymentTermInput[]
    connectOrCreate?: PaymentAccountCreateOrConnectWithoutPaymentTermInput | PaymentAccountCreateOrConnectWithoutPaymentTermInput[]
    upsert?: PaymentAccountUpsertWithWhereUniqueWithoutPaymentTermInput | PaymentAccountUpsertWithWhereUniqueWithoutPaymentTermInput[]
    createMany?: PaymentAccountCreateManyPaymentTermInputEnvelope
    set?: PaymentAccountWhereUniqueInput | PaymentAccountWhereUniqueInput[]
    disconnect?: PaymentAccountWhereUniqueInput | PaymentAccountWhereUniqueInput[]
    delete?: PaymentAccountWhereUniqueInput | PaymentAccountWhereUniqueInput[]
    connect?: PaymentAccountWhereUniqueInput | PaymentAccountWhereUniqueInput[]
    update?: PaymentAccountUpdateWithWhereUniqueWithoutPaymentTermInput | PaymentAccountUpdateWithWhereUniqueWithoutPaymentTermInput[]
    updateMany?: PaymentAccountUpdateManyWithWhereWithoutPaymentTermInput | PaymentAccountUpdateManyWithWhereWithoutPaymentTermInput[]
    deleteMany?: PaymentAccountScalarWhereInput | PaymentAccountScalarWhereInput[]
  }

  export type TopUpUncheckedUpdateManyWithoutPaymentTermNestedInput = {
    create?: XOR<TopUpCreateWithoutPaymentTermInput, TopUpUncheckedCreateWithoutPaymentTermInput> | TopUpCreateWithoutPaymentTermInput[] | TopUpUncheckedCreateWithoutPaymentTermInput[]
    connectOrCreate?: TopUpCreateOrConnectWithoutPaymentTermInput | TopUpCreateOrConnectWithoutPaymentTermInput[]
    upsert?: TopUpUpsertWithWhereUniqueWithoutPaymentTermInput | TopUpUpsertWithWhereUniqueWithoutPaymentTermInput[]
    createMany?: TopUpCreateManyPaymentTermInputEnvelope
    set?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    disconnect?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    delete?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    connect?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    update?: TopUpUpdateWithWhereUniqueWithoutPaymentTermInput | TopUpUpdateWithWhereUniqueWithoutPaymentTermInput[]
    updateMany?: TopUpUpdateManyWithWhereWithoutPaymentTermInput | TopUpUpdateManyWithWhereWithoutPaymentTermInput[]
    deleteMany?: TopUpScalarWhereInput | TopUpScalarWhereInput[]
  }

  export type PaymentTermCreateNestedOneWithoutPaymentAccountsInput = {
    create?: XOR<PaymentTermCreateWithoutPaymentAccountsInput, PaymentTermUncheckedCreateWithoutPaymentAccountsInput>
    connectOrCreate?: PaymentTermCreateOrConnectWithoutPaymentAccountsInput
    connect?: PaymentTermWhereUniqueInput
  }

  export type TopUpCreateNestedManyWithoutPaymentAccountInput = {
    create?: XOR<TopUpCreateWithoutPaymentAccountInput, TopUpUncheckedCreateWithoutPaymentAccountInput> | TopUpCreateWithoutPaymentAccountInput[] | TopUpUncheckedCreateWithoutPaymentAccountInput[]
    connectOrCreate?: TopUpCreateOrConnectWithoutPaymentAccountInput | TopUpCreateOrConnectWithoutPaymentAccountInput[]
    createMany?: TopUpCreateManyPaymentAccountInputEnvelope
    connect?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
  }

  export type TopUpUncheckedCreateNestedManyWithoutPaymentAccountInput = {
    create?: XOR<TopUpCreateWithoutPaymentAccountInput, TopUpUncheckedCreateWithoutPaymentAccountInput> | TopUpCreateWithoutPaymentAccountInput[] | TopUpUncheckedCreateWithoutPaymentAccountInput[]
    connectOrCreate?: TopUpCreateOrConnectWithoutPaymentAccountInput | TopUpCreateOrConnectWithoutPaymentAccountInput[]
    createMany?: TopUpCreateManyPaymentAccountInputEnvelope
    connect?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
  }

  export type PaymentTermUpdateOneRequiredWithoutPaymentAccountsNestedInput = {
    create?: XOR<PaymentTermCreateWithoutPaymentAccountsInput, PaymentTermUncheckedCreateWithoutPaymentAccountsInput>
    connectOrCreate?: PaymentTermCreateOrConnectWithoutPaymentAccountsInput
    upsert?: PaymentTermUpsertWithoutPaymentAccountsInput
    connect?: PaymentTermWhereUniqueInput
    update?: XOR<XOR<PaymentTermUpdateToOneWithWhereWithoutPaymentAccountsInput, PaymentTermUpdateWithoutPaymentAccountsInput>, PaymentTermUncheckedUpdateWithoutPaymentAccountsInput>
  }

  export type TopUpUpdateManyWithoutPaymentAccountNestedInput = {
    create?: XOR<TopUpCreateWithoutPaymentAccountInput, TopUpUncheckedCreateWithoutPaymentAccountInput> | TopUpCreateWithoutPaymentAccountInput[] | TopUpUncheckedCreateWithoutPaymentAccountInput[]
    connectOrCreate?: TopUpCreateOrConnectWithoutPaymentAccountInput | TopUpCreateOrConnectWithoutPaymentAccountInput[]
    upsert?: TopUpUpsertWithWhereUniqueWithoutPaymentAccountInput | TopUpUpsertWithWhereUniqueWithoutPaymentAccountInput[]
    createMany?: TopUpCreateManyPaymentAccountInputEnvelope
    set?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    disconnect?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    delete?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    connect?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    update?: TopUpUpdateWithWhereUniqueWithoutPaymentAccountInput | TopUpUpdateWithWhereUniqueWithoutPaymentAccountInput[]
    updateMany?: TopUpUpdateManyWithWhereWithoutPaymentAccountInput | TopUpUpdateManyWithWhereWithoutPaymentAccountInput[]
    deleteMany?: TopUpScalarWhereInput | TopUpScalarWhereInput[]
  }

  export type TopUpUncheckedUpdateManyWithoutPaymentAccountNestedInput = {
    create?: XOR<TopUpCreateWithoutPaymentAccountInput, TopUpUncheckedCreateWithoutPaymentAccountInput> | TopUpCreateWithoutPaymentAccountInput[] | TopUpUncheckedCreateWithoutPaymentAccountInput[]
    connectOrCreate?: TopUpCreateOrConnectWithoutPaymentAccountInput | TopUpCreateOrConnectWithoutPaymentAccountInput[]
    upsert?: TopUpUpsertWithWhereUniqueWithoutPaymentAccountInput | TopUpUpsertWithWhereUniqueWithoutPaymentAccountInput[]
    createMany?: TopUpCreateManyPaymentAccountInputEnvelope
    set?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    disconnect?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    delete?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    connect?: TopUpWhereUniqueInput | TopUpWhereUniqueInput[]
    update?: TopUpUpdateWithWhereUniqueWithoutPaymentAccountInput | TopUpUpdateWithWhereUniqueWithoutPaymentAccountInput[]
    updateMany?: TopUpUpdateManyWithWhereWithoutPaymentAccountInput | TopUpUpdateManyWithWhereWithoutPaymentAccountInput[]
    deleteMany?: TopUpScalarWhereInput | TopUpScalarWhereInput[]
  }

  export type UserCreateNestedOneWithoutWishlistsInput = {
    create?: XOR<UserCreateWithoutWishlistsInput, UserUncheckedCreateWithoutWishlistsInput>
    connectOrCreate?: UserCreateOrConnectWithoutWishlistsInput
    connect?: UserWhereUniqueInput
  }

  export type ProductCreateNestedOneWithoutWishlistsInput = {
    create?: XOR<ProductCreateWithoutWishlistsInput, ProductUncheckedCreateWithoutWishlistsInput>
    connectOrCreate?: ProductCreateOrConnectWithoutWishlistsInput
    connect?: ProductWhereUniqueInput
  }

  export type UserUpdateOneRequiredWithoutWishlistsNestedInput = {
    create?: XOR<UserCreateWithoutWishlistsInput, UserUncheckedCreateWithoutWishlistsInput>
    connectOrCreate?: UserCreateOrConnectWithoutWishlistsInput
    upsert?: UserUpsertWithoutWishlistsInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutWishlistsInput, UserUpdateWithoutWishlistsInput>, UserUncheckedUpdateWithoutWishlistsInput>
  }

  export type ProductUpdateOneRequiredWithoutWishlistsNestedInput = {
    create?: XOR<ProductCreateWithoutWishlistsInput, ProductUncheckedCreateWithoutWishlistsInput>
    connectOrCreate?: ProductCreateOrConnectWithoutWishlistsInput
    upsert?: ProductUpsertWithoutWishlistsInput
    connect?: ProductWhereUniqueInput
    update?: XOR<XOR<ProductUpdateToOneWithWhereWithoutWishlistsInput, ProductUpdateWithoutWishlistsInput>, ProductUncheckedUpdateWithoutWishlistsInput>
  }

  export type AdminCreateNestedOneWithoutTopUpsInput = {
    create?: XOR<AdminCreateWithoutTopUpsInput, AdminUncheckedCreateWithoutTopUpsInput>
    connectOrCreate?: AdminCreateOrConnectWithoutTopUpsInput
    connect?: AdminWhereUniqueInput
  }

  export type UserCreateNestedOneWithoutTopUpInput = {
    create?: XOR<UserCreateWithoutTopUpInput, UserUncheckedCreateWithoutTopUpInput>
    connectOrCreate?: UserCreateOrConnectWithoutTopUpInput
    connect?: UserWhereUniqueInput
  }

  export type PaymentAccountCreateNestedOneWithoutTopUpsInput = {
    create?: XOR<PaymentAccountCreateWithoutTopUpsInput, PaymentAccountUncheckedCreateWithoutTopUpsInput>
    connectOrCreate?: PaymentAccountCreateOrConnectWithoutTopUpsInput
    connect?: PaymentAccountWhereUniqueInput
  }

  export type PaymentTermCreateNestedOneWithoutTopUpsInput = {
    create?: XOR<PaymentTermCreateWithoutTopUpsInput, PaymentTermUncheckedCreateWithoutTopUpsInput>
    connectOrCreate?: PaymentTermCreateOrConnectWithoutTopUpsInput
    connect?: PaymentTermWhereUniqueInput
  }

  export type AdminUpdateOneWithoutTopUpsNestedInput = {
    create?: XOR<AdminCreateWithoutTopUpsInput, AdminUncheckedCreateWithoutTopUpsInput>
    connectOrCreate?: AdminCreateOrConnectWithoutTopUpsInput
    upsert?: AdminUpsertWithoutTopUpsInput
    disconnect?: AdminWhereInput | boolean
    delete?: AdminWhereInput | boolean
    connect?: AdminWhereUniqueInput
    update?: XOR<XOR<AdminUpdateToOneWithWhereWithoutTopUpsInput, AdminUpdateWithoutTopUpsInput>, AdminUncheckedUpdateWithoutTopUpsInput>
  }

  export type UserUpdateOneRequiredWithoutTopUpNestedInput = {
    create?: XOR<UserCreateWithoutTopUpInput, UserUncheckedCreateWithoutTopUpInput>
    connectOrCreate?: UserCreateOrConnectWithoutTopUpInput
    upsert?: UserUpsertWithoutTopUpInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutTopUpInput, UserUpdateWithoutTopUpInput>, UserUncheckedUpdateWithoutTopUpInput>
  }

  export type PaymentAccountUpdateOneRequiredWithoutTopUpsNestedInput = {
    create?: XOR<PaymentAccountCreateWithoutTopUpsInput, PaymentAccountUncheckedCreateWithoutTopUpsInput>
    connectOrCreate?: PaymentAccountCreateOrConnectWithoutTopUpsInput
    upsert?: PaymentAccountUpsertWithoutTopUpsInput
    connect?: PaymentAccountWhereUniqueInput
    update?: XOR<XOR<PaymentAccountUpdateToOneWithWhereWithoutTopUpsInput, PaymentAccountUpdateWithoutTopUpsInput>, PaymentAccountUncheckedUpdateWithoutTopUpsInput>
  }

  export type PaymentTermUpdateOneRequiredWithoutTopUpsNestedInput = {
    create?: XOR<PaymentTermCreateWithoutTopUpsInput, PaymentTermUncheckedCreateWithoutTopUpsInput>
    connectOrCreate?: PaymentTermCreateOrConnectWithoutTopUpsInput
    upsert?: PaymentTermUpsertWithoutTopUpsInput
    connect?: PaymentTermWhereUniqueInput
    update?: XOR<XOR<PaymentTermUpdateToOneWithWhereWithoutTopUpsInput, PaymentTermUpdateWithoutTopUpsInput>, PaymentTermUncheckedUpdateWithoutTopUpsInput>
  }

  export type UserCreateNestedOneWithoutTransactionsInput = {
    create?: XOR<UserCreateWithoutTransactionsInput, UserUncheckedCreateWithoutTransactionsInput>
    connectOrCreate?: UserCreateOrConnectWithoutTransactionsInput
    connect?: UserWhereUniqueInput
  }

  export type TransactionDetailsCreateNestedManyWithoutTransactionInput = {
    create?: XOR<TransactionDetailsCreateWithoutTransactionInput, TransactionDetailsUncheckedCreateWithoutTransactionInput> | TransactionDetailsCreateWithoutTransactionInput[] | TransactionDetailsUncheckedCreateWithoutTransactionInput[]
    connectOrCreate?: TransactionDetailsCreateOrConnectWithoutTransactionInput | TransactionDetailsCreateOrConnectWithoutTransactionInput[]
    createMany?: TransactionDetailsCreateManyTransactionInputEnvelope
    connect?: TransactionDetailsWhereUniqueInput | TransactionDetailsWhereUniqueInput[]
  }

  export type TransactionDetailsUncheckedCreateNestedManyWithoutTransactionInput = {
    create?: XOR<TransactionDetailsCreateWithoutTransactionInput, TransactionDetailsUncheckedCreateWithoutTransactionInput> | TransactionDetailsCreateWithoutTransactionInput[] | TransactionDetailsUncheckedCreateWithoutTransactionInput[]
    connectOrCreate?: TransactionDetailsCreateOrConnectWithoutTransactionInput | TransactionDetailsCreateOrConnectWithoutTransactionInput[]
    createMany?: TransactionDetailsCreateManyTransactionInputEnvelope
    connect?: TransactionDetailsWhereUniqueInput | TransactionDetailsWhereUniqueInput[]
  }

  export type UserUpdateOneRequiredWithoutTransactionsNestedInput = {
    create?: XOR<UserCreateWithoutTransactionsInput, UserUncheckedCreateWithoutTransactionsInput>
    connectOrCreate?: UserCreateOrConnectWithoutTransactionsInput
    upsert?: UserUpsertWithoutTransactionsInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutTransactionsInput, UserUpdateWithoutTransactionsInput>, UserUncheckedUpdateWithoutTransactionsInput>
  }

  export type TransactionDetailsUpdateManyWithoutTransactionNestedInput = {
    create?: XOR<TransactionDetailsCreateWithoutTransactionInput, TransactionDetailsUncheckedCreateWithoutTransactionInput> | TransactionDetailsCreateWithoutTransactionInput[] | TransactionDetailsUncheckedCreateWithoutTransactionInput[]
    connectOrCreate?: TransactionDetailsCreateOrConnectWithoutTransactionInput | TransactionDetailsCreateOrConnectWithoutTransactionInput[]
    upsert?: TransactionDetailsUpsertWithWhereUniqueWithoutTransactionInput | TransactionDetailsUpsertWithWhereUniqueWithoutTransactionInput[]
    createMany?: TransactionDetailsCreateManyTransactionInputEnvelope
    set?: TransactionDetailsWhereUniqueInput | TransactionDetailsWhereUniqueInput[]
    disconnect?: TransactionDetailsWhereUniqueInput | TransactionDetailsWhereUniqueInput[]
    delete?: TransactionDetailsWhereUniqueInput | TransactionDetailsWhereUniqueInput[]
    connect?: TransactionDetailsWhereUniqueInput | TransactionDetailsWhereUniqueInput[]
    update?: TransactionDetailsUpdateWithWhereUniqueWithoutTransactionInput | TransactionDetailsUpdateWithWhereUniqueWithoutTransactionInput[]
    updateMany?: TransactionDetailsUpdateManyWithWhereWithoutTransactionInput | TransactionDetailsUpdateManyWithWhereWithoutTransactionInput[]
    deleteMany?: TransactionDetailsScalarWhereInput | TransactionDetailsScalarWhereInput[]
  }

  export type TransactionDetailsUncheckedUpdateManyWithoutTransactionNestedInput = {
    create?: XOR<TransactionDetailsCreateWithoutTransactionInput, TransactionDetailsUncheckedCreateWithoutTransactionInput> | TransactionDetailsCreateWithoutTransactionInput[] | TransactionDetailsUncheckedCreateWithoutTransactionInput[]
    connectOrCreate?: TransactionDetailsCreateOrConnectWithoutTransactionInput | TransactionDetailsCreateOrConnectWithoutTransactionInput[]
    upsert?: TransactionDetailsUpsertWithWhereUniqueWithoutTransactionInput | TransactionDetailsUpsertWithWhereUniqueWithoutTransactionInput[]
    createMany?: TransactionDetailsCreateManyTransactionInputEnvelope
    set?: TransactionDetailsWhereUniqueInput | TransactionDetailsWhereUniqueInput[]
    disconnect?: TransactionDetailsWhereUniqueInput | TransactionDetailsWhereUniqueInput[]
    delete?: TransactionDetailsWhereUniqueInput | TransactionDetailsWhereUniqueInput[]
    connect?: TransactionDetailsWhereUniqueInput | TransactionDetailsWhereUniqueInput[]
    update?: TransactionDetailsUpdateWithWhereUniqueWithoutTransactionInput | TransactionDetailsUpdateWithWhereUniqueWithoutTransactionInput[]
    updateMany?: TransactionDetailsUpdateManyWithWhereWithoutTransactionInput | TransactionDetailsUpdateManyWithWhereWithoutTransactionInput[]
    deleteMany?: TransactionDetailsScalarWhereInput | TransactionDetailsScalarWhereInput[]
  }

  export type TransactionCreateNestedOneWithoutTransactionDetailsInput = {
    create?: XOR<TransactionCreateWithoutTransactionDetailsInput, TransactionUncheckedCreateWithoutTransactionDetailsInput>
    connectOrCreate?: TransactionCreateOrConnectWithoutTransactionDetailsInput
    connect?: TransactionWhereUniqueInput
  }

  export type ProductCreateNestedOneWithoutTransactionDetailsInput = {
    create?: XOR<ProductCreateWithoutTransactionDetailsInput, ProductUncheckedCreateWithoutTransactionDetailsInput>
    connectOrCreate?: ProductCreateOrConnectWithoutTransactionDetailsInput
    connect?: ProductWhereUniqueInput
  }

  export type TransactionUpdateOneRequiredWithoutTransactionDetailsNestedInput = {
    create?: XOR<TransactionCreateWithoutTransactionDetailsInput, TransactionUncheckedCreateWithoutTransactionDetailsInput>
    connectOrCreate?: TransactionCreateOrConnectWithoutTransactionDetailsInput
    upsert?: TransactionUpsertWithoutTransactionDetailsInput
    connect?: TransactionWhereUniqueInput
    update?: XOR<XOR<TransactionUpdateToOneWithWhereWithoutTransactionDetailsInput, TransactionUpdateWithoutTransactionDetailsInput>, TransactionUncheckedUpdateWithoutTransactionDetailsInput>
  }

  export type ProductUpdateOneRequiredWithoutTransactionDetailsNestedInput = {
    create?: XOR<ProductCreateWithoutTransactionDetailsInput, ProductUncheckedCreateWithoutTransactionDetailsInput>
    connectOrCreate?: ProductCreateOrConnectWithoutTransactionDetailsInput
    upsert?: ProductUpsertWithoutTransactionDetailsInput
    connect?: ProductWhereUniqueInput
    update?: XOR<XOR<ProductUpdateToOneWithWhereWithoutTransactionDetailsInput, ProductUpdateWithoutTransactionDetailsInput>, ProductUncheckedUpdateWithoutTransactionDetailsInput>
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedBoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type NestedDateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedBoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type NestedDateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type NestedDateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type NestedDateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type TopUpCreateWithoutAdminInput = {
    id?: string
    nominal: number
    proofOfTransferFileName: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    user: UserCreateNestedOneWithoutTopUpInput
    PaymentAccount: PaymentAccountCreateNestedOneWithoutTopUpsInput
    paymentTerm: PaymentTermCreateNestedOneWithoutTopUpsInput
  }

  export type TopUpUncheckedCreateWithoutAdminInput = {
    id?: string
    nominal: number
    userId: string
    proofOfTransferFileName: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    paymentAccountId: string
    paymentTermId: string
  }

  export type TopUpCreateOrConnectWithoutAdminInput = {
    where: TopUpWhereUniqueInput
    create: XOR<TopUpCreateWithoutAdminInput, TopUpUncheckedCreateWithoutAdminInput>
  }

  export type TopUpCreateManyAdminInputEnvelope = {
    data: TopUpCreateManyAdminInput | TopUpCreateManyAdminInput[]
    skipDuplicates?: boolean
  }

  export type TopUpUpsertWithWhereUniqueWithoutAdminInput = {
    where: TopUpWhereUniqueInput
    update: XOR<TopUpUpdateWithoutAdminInput, TopUpUncheckedUpdateWithoutAdminInput>
    create: XOR<TopUpCreateWithoutAdminInput, TopUpUncheckedCreateWithoutAdminInput>
  }

  export type TopUpUpdateWithWhereUniqueWithoutAdminInput = {
    where: TopUpWhereUniqueInput
    data: XOR<TopUpUpdateWithoutAdminInput, TopUpUncheckedUpdateWithoutAdminInput>
  }

  export type TopUpUpdateManyWithWhereWithoutAdminInput = {
    where: TopUpScalarWhereInput
    data: XOR<TopUpUpdateManyMutationInput, TopUpUncheckedUpdateManyWithoutAdminInput>
  }

  export type TopUpScalarWhereInput = {
    AND?: TopUpScalarWhereInput | TopUpScalarWhereInput[]
    OR?: TopUpScalarWhereInput[]
    NOT?: TopUpScalarWhereInput | TopUpScalarWhereInput[]
    id?: StringFilter<"TopUp"> | string
    nominal?: IntFilter<"TopUp"> | number
    adminId?: StringNullableFilter<"TopUp"> | string | null
    userId?: StringFilter<"TopUp"> | string
    proofOfTransferFileName?: StringFilter<"TopUp"> | string
    status?: StringFilter<"TopUp"> | string
    createdAt?: DateTimeFilter<"TopUp"> | Date | string
    updatedAt?: DateTimeFilter<"TopUp"> | Date | string
    paymentAccountId?: StringFilter<"TopUp"> | string
    paymentTermId?: StringFilter<"TopUp"> | string
  }

  export type WishlistCreateWithoutUserInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    product: ProductCreateNestedOneWithoutWishlistsInput
  }

  export type WishlistUncheckedCreateWithoutUserInput = {
    id?: string
    productId: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type WishlistCreateOrConnectWithoutUserInput = {
    where: WishlistWhereUniqueInput
    create: XOR<WishlistCreateWithoutUserInput, WishlistUncheckedCreateWithoutUserInput>
  }

  export type WishlistCreateManyUserInputEnvelope = {
    data: WishlistCreateManyUserInput | WishlistCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type TopUpCreateWithoutUserInput = {
    id?: string
    nominal: number
    proofOfTransferFileName: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    admin?: AdminCreateNestedOneWithoutTopUpsInput
    PaymentAccount: PaymentAccountCreateNestedOneWithoutTopUpsInput
    paymentTerm: PaymentTermCreateNestedOneWithoutTopUpsInput
  }

  export type TopUpUncheckedCreateWithoutUserInput = {
    id?: string
    nominal: number
    adminId?: string | null
    proofOfTransferFileName: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    paymentAccountId: string
    paymentTermId: string
  }

  export type TopUpCreateOrConnectWithoutUserInput = {
    where: TopUpWhereUniqueInput
    create: XOR<TopUpCreateWithoutUserInput, TopUpUncheckedCreateWithoutUserInput>
  }

  export type TopUpCreateManyUserInputEnvelope = {
    data: TopUpCreateManyUserInput | TopUpCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type TransactionCreateWithoutUserInput = {
    id?: string
    total: number
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    transactionDetails?: TransactionDetailsCreateNestedManyWithoutTransactionInput
  }

  export type TransactionUncheckedCreateWithoutUserInput = {
    id?: string
    total: number
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    transactionDetails?: TransactionDetailsUncheckedCreateNestedManyWithoutTransactionInput
  }

  export type TransactionCreateOrConnectWithoutUserInput = {
    where: TransactionWhereUniqueInput
    create: XOR<TransactionCreateWithoutUserInput, TransactionUncheckedCreateWithoutUserInput>
  }

  export type TransactionCreateManyUserInputEnvelope = {
    data: TransactionCreateManyUserInput | TransactionCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type UserVerificationTokenCreateWithoutUserInput = {
    id?: string
    token: string
    purpose: string
    createdAt?: Date | string
    updatedAt?: Date | string
    expiredAt?: Date | string | null
  }

  export type UserVerificationTokenUncheckedCreateWithoutUserInput = {
    id?: string
    token: string
    purpose: string
    createdAt?: Date | string
    updatedAt?: Date | string
    expiredAt?: Date | string | null
  }

  export type UserVerificationTokenCreateOrConnectWithoutUserInput = {
    where: UserVerificationTokenWhereUniqueInput
    create: XOR<UserVerificationTokenCreateWithoutUserInput, UserVerificationTokenUncheckedCreateWithoutUserInput>
  }

  export type UserVerificationTokenCreateManyUserInputEnvelope = {
    data: UserVerificationTokenCreateManyUserInput | UserVerificationTokenCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type WishlistUpsertWithWhereUniqueWithoutUserInput = {
    where: WishlistWhereUniqueInput
    update: XOR<WishlistUpdateWithoutUserInput, WishlistUncheckedUpdateWithoutUserInput>
    create: XOR<WishlistCreateWithoutUserInput, WishlistUncheckedCreateWithoutUserInput>
  }

  export type WishlistUpdateWithWhereUniqueWithoutUserInput = {
    where: WishlistWhereUniqueInput
    data: XOR<WishlistUpdateWithoutUserInput, WishlistUncheckedUpdateWithoutUserInput>
  }

  export type WishlistUpdateManyWithWhereWithoutUserInput = {
    where: WishlistScalarWhereInput
    data: XOR<WishlistUpdateManyMutationInput, WishlistUncheckedUpdateManyWithoutUserInput>
  }

  export type WishlistScalarWhereInput = {
    AND?: WishlistScalarWhereInput | WishlistScalarWhereInput[]
    OR?: WishlistScalarWhereInput[]
    NOT?: WishlistScalarWhereInput | WishlistScalarWhereInput[]
    id?: StringFilter<"Wishlist"> | string
    userId?: StringFilter<"Wishlist"> | string
    productId?: StringFilter<"Wishlist"> | string
    createdAt?: DateTimeFilter<"Wishlist"> | Date | string
    updatedAt?: DateTimeFilter<"Wishlist"> | Date | string
  }

  export type TopUpUpsertWithWhereUniqueWithoutUserInput = {
    where: TopUpWhereUniqueInput
    update: XOR<TopUpUpdateWithoutUserInput, TopUpUncheckedUpdateWithoutUserInput>
    create: XOR<TopUpCreateWithoutUserInput, TopUpUncheckedCreateWithoutUserInput>
  }

  export type TopUpUpdateWithWhereUniqueWithoutUserInput = {
    where: TopUpWhereUniqueInput
    data: XOR<TopUpUpdateWithoutUserInput, TopUpUncheckedUpdateWithoutUserInput>
  }

  export type TopUpUpdateManyWithWhereWithoutUserInput = {
    where: TopUpScalarWhereInput
    data: XOR<TopUpUpdateManyMutationInput, TopUpUncheckedUpdateManyWithoutUserInput>
  }

  export type TransactionUpsertWithWhereUniqueWithoutUserInput = {
    where: TransactionWhereUniqueInput
    update: XOR<TransactionUpdateWithoutUserInput, TransactionUncheckedUpdateWithoutUserInput>
    create: XOR<TransactionCreateWithoutUserInput, TransactionUncheckedCreateWithoutUserInput>
  }

  export type TransactionUpdateWithWhereUniqueWithoutUserInput = {
    where: TransactionWhereUniqueInput
    data: XOR<TransactionUpdateWithoutUserInput, TransactionUncheckedUpdateWithoutUserInput>
  }

  export type TransactionUpdateManyWithWhereWithoutUserInput = {
    where: TransactionScalarWhereInput
    data: XOR<TransactionUpdateManyMutationInput, TransactionUncheckedUpdateManyWithoutUserInput>
  }

  export type TransactionScalarWhereInput = {
    AND?: TransactionScalarWhereInput | TransactionScalarWhereInput[]
    OR?: TransactionScalarWhereInput[]
    NOT?: TransactionScalarWhereInput | TransactionScalarWhereInput[]
    id?: StringFilter<"Transaction"> | string
    userId?: StringFilter<"Transaction"> | string
    total?: IntFilter<"Transaction"> | number
    status?: StringFilter<"Transaction"> | string
    createdAt?: DateTimeFilter<"Transaction"> | Date | string
    updatedAt?: DateTimeFilter<"Transaction"> | Date | string
  }

  export type UserVerificationTokenUpsertWithWhereUniqueWithoutUserInput = {
    where: UserVerificationTokenWhereUniqueInput
    update: XOR<UserVerificationTokenUpdateWithoutUserInput, UserVerificationTokenUncheckedUpdateWithoutUserInput>
    create: XOR<UserVerificationTokenCreateWithoutUserInput, UserVerificationTokenUncheckedCreateWithoutUserInput>
  }

  export type UserVerificationTokenUpdateWithWhereUniqueWithoutUserInput = {
    where: UserVerificationTokenWhereUniqueInput
    data: XOR<UserVerificationTokenUpdateWithoutUserInput, UserVerificationTokenUncheckedUpdateWithoutUserInput>
  }

  export type UserVerificationTokenUpdateManyWithWhereWithoutUserInput = {
    where: UserVerificationTokenScalarWhereInput
    data: XOR<UserVerificationTokenUpdateManyMutationInput, UserVerificationTokenUncheckedUpdateManyWithoutUserInput>
  }

  export type UserVerificationTokenScalarWhereInput = {
    AND?: UserVerificationTokenScalarWhereInput | UserVerificationTokenScalarWhereInput[]
    OR?: UserVerificationTokenScalarWhereInput[]
    NOT?: UserVerificationTokenScalarWhereInput | UserVerificationTokenScalarWhereInput[]
    id?: StringFilter<"UserVerificationToken"> | string
    token?: StringFilter<"UserVerificationToken"> | string
    userId?: StringFilter<"UserVerificationToken"> | string
    purpose?: StringFilter<"UserVerificationToken"> | string
    createdAt?: DateTimeFilter<"UserVerificationToken"> | Date | string
    updatedAt?: DateTimeFilter<"UserVerificationToken"> | Date | string
    expiredAt?: DateTimeNullableFilter<"UserVerificationToken"> | Date | string | null
  }

  export type UserCreateWithoutUserVerificationTokensInput = {
    id?: string
    name: string
    email: string
    password: string
    status: string
    profile: string
    balance: number
    createdAt?: Date | string
    updatedAt?: Date | string
    wishlists?: WishlistCreateNestedManyWithoutUserInput
    topUp?: TopUpCreateNestedManyWithoutUserInput
    transactions?: TransactionCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutUserVerificationTokensInput = {
    id?: string
    name: string
    email: string
    password: string
    status: string
    profile: string
    balance: number
    createdAt?: Date | string
    updatedAt?: Date | string
    wishlists?: WishlistUncheckedCreateNestedManyWithoutUserInput
    topUp?: TopUpUncheckedCreateNestedManyWithoutUserInput
    transactions?: TransactionUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutUserVerificationTokensInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutUserVerificationTokensInput, UserUncheckedCreateWithoutUserVerificationTokensInput>
  }

  export type UserUpsertWithoutUserVerificationTokensInput = {
    update: XOR<UserUpdateWithoutUserVerificationTokensInput, UserUncheckedUpdateWithoutUserVerificationTokensInput>
    create: XOR<UserCreateWithoutUserVerificationTokensInput, UserUncheckedCreateWithoutUserVerificationTokensInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutUserVerificationTokensInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutUserVerificationTokensInput, UserUncheckedUpdateWithoutUserVerificationTokensInput>
  }

  export type UserUpdateWithoutUserVerificationTokensInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    profile?: StringFieldUpdateOperationsInput | string
    balance?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    wishlists?: WishlistUpdateManyWithoutUserNestedInput
    topUp?: TopUpUpdateManyWithoutUserNestedInput
    transactions?: TransactionUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutUserVerificationTokensInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    profile?: StringFieldUpdateOperationsInput | string
    balance?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    wishlists?: WishlistUncheckedUpdateManyWithoutUserNestedInput
    topUp?: TopUpUncheckedUpdateManyWithoutUserNestedInput
    transactions?: TransactionUncheckedUpdateManyWithoutUserNestedInput
  }

  export type ProductCreateWithoutCategoryInput = {
    id?: string
    name: string
    status: string
    price: number
    stock: number
    description: string
    imageFileName?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    stockMutations?: StockMutationCreateNestedManyWithoutProductInput
    wishlists?: WishlistCreateNestedManyWithoutProductInput
    transactionDetails?: TransactionDetailsCreateNestedManyWithoutProductInput
  }

  export type ProductUncheckedCreateWithoutCategoryInput = {
    id?: string
    name: string
    status: string
    price: number
    stock: number
    description: string
    imageFileName?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    stockMutations?: StockMutationUncheckedCreateNestedManyWithoutProductInput
    wishlists?: WishlistUncheckedCreateNestedManyWithoutProductInput
    transactionDetails?: TransactionDetailsUncheckedCreateNestedManyWithoutProductInput
  }

  export type ProductCreateOrConnectWithoutCategoryInput = {
    where: ProductWhereUniqueInput
    create: XOR<ProductCreateWithoutCategoryInput, ProductUncheckedCreateWithoutCategoryInput>
  }

  export type ProductCreateManyCategoryInputEnvelope = {
    data: ProductCreateManyCategoryInput | ProductCreateManyCategoryInput[]
    skipDuplicates?: boolean
  }

  export type ProductUpsertWithWhereUniqueWithoutCategoryInput = {
    where: ProductWhereUniqueInput
    update: XOR<ProductUpdateWithoutCategoryInput, ProductUncheckedUpdateWithoutCategoryInput>
    create: XOR<ProductCreateWithoutCategoryInput, ProductUncheckedCreateWithoutCategoryInput>
  }

  export type ProductUpdateWithWhereUniqueWithoutCategoryInput = {
    where: ProductWhereUniqueInput
    data: XOR<ProductUpdateWithoutCategoryInput, ProductUncheckedUpdateWithoutCategoryInput>
  }

  export type ProductUpdateManyWithWhereWithoutCategoryInput = {
    where: ProductScalarWhereInput
    data: XOR<ProductUpdateManyMutationInput, ProductUncheckedUpdateManyWithoutCategoryInput>
  }

  export type ProductScalarWhereInput = {
    AND?: ProductScalarWhereInput | ProductScalarWhereInput[]
    OR?: ProductScalarWhereInput[]
    NOT?: ProductScalarWhereInput | ProductScalarWhereInput[]
    id?: StringFilter<"Product"> | string
    categoryId?: StringFilter<"Product"> | string
    name?: StringFilter<"Product"> | string
    status?: StringFilter<"Product"> | string
    price?: IntFilter<"Product"> | number
    stock?: IntFilter<"Product"> | number
    description?: StringFilter<"Product"> | string
    imageFileName?: StringNullableFilter<"Product"> | string | null
    createdAt?: DateTimeFilter<"Product"> | Date | string
    updatedAt?: DateTimeFilter<"Product"> | Date | string
  }

  export type CategoryCreateWithoutProductsInput = {
    id?: string
    name: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type CategoryUncheckedCreateWithoutProductsInput = {
    id?: string
    name: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type CategoryCreateOrConnectWithoutProductsInput = {
    where: CategoryWhereUniqueInput
    create: XOR<CategoryCreateWithoutProductsInput, CategoryUncheckedCreateWithoutProductsInput>
  }

  export type StockMutationCreateWithoutProductInput = {
    id?: string
    currentStock: number
    quantity: number
    type: string
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type StockMutationUncheckedCreateWithoutProductInput = {
    id?: string
    currentStock: number
    quantity: number
    type: string
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type StockMutationCreateOrConnectWithoutProductInput = {
    where: StockMutationWhereUniqueInput
    create: XOR<StockMutationCreateWithoutProductInput, StockMutationUncheckedCreateWithoutProductInput>
  }

  export type StockMutationCreateManyProductInputEnvelope = {
    data: StockMutationCreateManyProductInput | StockMutationCreateManyProductInput[]
    skipDuplicates?: boolean
  }

  export type WishlistCreateWithoutProductInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    user: UserCreateNestedOneWithoutWishlistsInput
  }

  export type WishlistUncheckedCreateWithoutProductInput = {
    id?: string
    userId: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type WishlistCreateOrConnectWithoutProductInput = {
    where: WishlistWhereUniqueInput
    create: XOR<WishlistCreateWithoutProductInput, WishlistUncheckedCreateWithoutProductInput>
  }

  export type WishlistCreateManyProductInputEnvelope = {
    data: WishlistCreateManyProductInput | WishlistCreateManyProductInput[]
    skipDuplicates?: boolean
  }

  export type TransactionDetailsCreateWithoutProductInput = {
    id?: string
    purchasedPrice: number
    quantity: number
    subtotal: number
    createdAt?: Date | string
    updatedAt?: Date | string
    transaction: TransactionCreateNestedOneWithoutTransactionDetailsInput
  }

  export type TransactionDetailsUncheckedCreateWithoutProductInput = {
    id?: string
    transactionId: string
    purchasedPrice: number
    quantity: number
    subtotal: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type TransactionDetailsCreateOrConnectWithoutProductInput = {
    where: TransactionDetailsWhereUniqueInput
    create: XOR<TransactionDetailsCreateWithoutProductInput, TransactionDetailsUncheckedCreateWithoutProductInput>
  }

  export type TransactionDetailsCreateManyProductInputEnvelope = {
    data: TransactionDetailsCreateManyProductInput | TransactionDetailsCreateManyProductInput[]
    skipDuplicates?: boolean
  }

  export type CategoryUpsertWithoutProductsInput = {
    update: XOR<CategoryUpdateWithoutProductsInput, CategoryUncheckedUpdateWithoutProductsInput>
    create: XOR<CategoryCreateWithoutProductsInput, CategoryUncheckedCreateWithoutProductsInput>
    where?: CategoryWhereInput
  }

  export type CategoryUpdateToOneWithWhereWithoutProductsInput = {
    where?: CategoryWhereInput
    data: XOR<CategoryUpdateWithoutProductsInput, CategoryUncheckedUpdateWithoutProductsInput>
  }

  export type CategoryUpdateWithoutProductsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CategoryUncheckedUpdateWithoutProductsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type StockMutationUpsertWithWhereUniqueWithoutProductInput = {
    where: StockMutationWhereUniqueInput
    update: XOR<StockMutationUpdateWithoutProductInput, StockMutationUncheckedUpdateWithoutProductInput>
    create: XOR<StockMutationCreateWithoutProductInput, StockMutationUncheckedCreateWithoutProductInput>
  }

  export type StockMutationUpdateWithWhereUniqueWithoutProductInput = {
    where: StockMutationWhereUniqueInput
    data: XOR<StockMutationUpdateWithoutProductInput, StockMutationUncheckedUpdateWithoutProductInput>
  }

  export type StockMutationUpdateManyWithWhereWithoutProductInput = {
    where: StockMutationScalarWhereInput
    data: XOR<StockMutationUpdateManyMutationInput, StockMutationUncheckedUpdateManyWithoutProductInput>
  }

  export type StockMutationScalarWhereInput = {
    AND?: StockMutationScalarWhereInput | StockMutationScalarWhereInput[]
    OR?: StockMutationScalarWhereInput[]
    NOT?: StockMutationScalarWhereInput | StockMutationScalarWhereInput[]
    id?: StringFilter<"StockMutation"> | string
    productId?: StringFilter<"StockMutation"> | string
    currentStock?: IntFilter<"StockMutation"> | number
    quantity?: IntFilter<"StockMutation"> | number
    type?: StringFilter<"StockMutation"> | string
    notes?: StringNullableFilter<"StockMutation"> | string | null
    createdAt?: DateTimeFilter<"StockMutation"> | Date | string
    updatedAt?: DateTimeFilter<"StockMutation"> | Date | string
  }

  export type WishlistUpsertWithWhereUniqueWithoutProductInput = {
    where: WishlistWhereUniqueInput
    update: XOR<WishlistUpdateWithoutProductInput, WishlistUncheckedUpdateWithoutProductInput>
    create: XOR<WishlistCreateWithoutProductInput, WishlistUncheckedCreateWithoutProductInput>
  }

  export type WishlistUpdateWithWhereUniqueWithoutProductInput = {
    where: WishlistWhereUniqueInput
    data: XOR<WishlistUpdateWithoutProductInput, WishlistUncheckedUpdateWithoutProductInput>
  }

  export type WishlistUpdateManyWithWhereWithoutProductInput = {
    where: WishlistScalarWhereInput
    data: XOR<WishlistUpdateManyMutationInput, WishlistUncheckedUpdateManyWithoutProductInput>
  }

  export type TransactionDetailsUpsertWithWhereUniqueWithoutProductInput = {
    where: TransactionDetailsWhereUniqueInput
    update: XOR<TransactionDetailsUpdateWithoutProductInput, TransactionDetailsUncheckedUpdateWithoutProductInput>
    create: XOR<TransactionDetailsCreateWithoutProductInput, TransactionDetailsUncheckedCreateWithoutProductInput>
  }

  export type TransactionDetailsUpdateWithWhereUniqueWithoutProductInput = {
    where: TransactionDetailsWhereUniqueInput
    data: XOR<TransactionDetailsUpdateWithoutProductInput, TransactionDetailsUncheckedUpdateWithoutProductInput>
  }

  export type TransactionDetailsUpdateManyWithWhereWithoutProductInput = {
    where: TransactionDetailsScalarWhereInput
    data: XOR<TransactionDetailsUpdateManyMutationInput, TransactionDetailsUncheckedUpdateManyWithoutProductInput>
  }

  export type TransactionDetailsScalarWhereInput = {
    AND?: TransactionDetailsScalarWhereInput | TransactionDetailsScalarWhereInput[]
    OR?: TransactionDetailsScalarWhereInput[]
    NOT?: TransactionDetailsScalarWhereInput | TransactionDetailsScalarWhereInput[]
    id?: StringFilter<"TransactionDetails"> | string
    transactionId?: StringFilter<"TransactionDetails"> | string
    productId?: StringFilter<"TransactionDetails"> | string
    purchasedPrice?: IntFilter<"TransactionDetails"> | number
    quantity?: IntFilter<"TransactionDetails"> | number
    subtotal?: IntFilter<"TransactionDetails"> | number
    createdAt?: DateTimeFilter<"TransactionDetails"> | Date | string
    updatedAt?: DateTimeFilter<"TransactionDetails"> | Date | string
  }

  export type ProductCreateWithoutStockMutationsInput = {
    id?: string
    name: string
    status: string
    price: number
    stock: number
    description: string
    imageFileName?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    category: CategoryCreateNestedOneWithoutProductsInput
    wishlists?: WishlistCreateNestedManyWithoutProductInput
    transactionDetails?: TransactionDetailsCreateNestedManyWithoutProductInput
  }

  export type ProductUncheckedCreateWithoutStockMutationsInput = {
    id?: string
    categoryId: string
    name: string
    status: string
    price: number
    stock: number
    description: string
    imageFileName?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    wishlists?: WishlistUncheckedCreateNestedManyWithoutProductInput
    transactionDetails?: TransactionDetailsUncheckedCreateNestedManyWithoutProductInput
  }

  export type ProductCreateOrConnectWithoutStockMutationsInput = {
    where: ProductWhereUniqueInput
    create: XOR<ProductCreateWithoutStockMutationsInput, ProductUncheckedCreateWithoutStockMutationsInput>
  }

  export type ProductUpsertWithoutStockMutationsInput = {
    update: XOR<ProductUpdateWithoutStockMutationsInput, ProductUncheckedUpdateWithoutStockMutationsInput>
    create: XOR<ProductCreateWithoutStockMutationsInput, ProductUncheckedCreateWithoutStockMutationsInput>
    where?: ProductWhereInput
  }

  export type ProductUpdateToOneWithWhereWithoutStockMutationsInput = {
    where?: ProductWhereInput
    data: XOR<ProductUpdateWithoutStockMutationsInput, ProductUncheckedUpdateWithoutStockMutationsInput>
  }

  export type ProductUpdateWithoutStockMutationsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    price?: IntFieldUpdateOperationsInput | number
    stock?: IntFieldUpdateOperationsInput | number
    description?: StringFieldUpdateOperationsInput | string
    imageFileName?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    category?: CategoryUpdateOneRequiredWithoutProductsNestedInput
    wishlists?: WishlistUpdateManyWithoutProductNestedInput
    transactionDetails?: TransactionDetailsUpdateManyWithoutProductNestedInput
  }

  export type ProductUncheckedUpdateWithoutStockMutationsInput = {
    id?: StringFieldUpdateOperationsInput | string
    categoryId?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    price?: IntFieldUpdateOperationsInput | number
    stock?: IntFieldUpdateOperationsInput | number
    description?: StringFieldUpdateOperationsInput | string
    imageFileName?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    wishlists?: WishlistUncheckedUpdateManyWithoutProductNestedInput
    transactionDetails?: TransactionDetailsUncheckedUpdateManyWithoutProductNestedInput
  }

  export type PaymentAccountCreateWithoutPaymentTermInput = {
    id?: string
    accountHolderName: string
    accountNumber: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    TopUps?: TopUpCreateNestedManyWithoutPaymentAccountInput
  }

  export type PaymentAccountUncheckedCreateWithoutPaymentTermInput = {
    id?: string
    accountHolderName: string
    accountNumber: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    TopUps?: TopUpUncheckedCreateNestedManyWithoutPaymentAccountInput
  }

  export type PaymentAccountCreateOrConnectWithoutPaymentTermInput = {
    where: PaymentAccountWhereUniqueInput
    create: XOR<PaymentAccountCreateWithoutPaymentTermInput, PaymentAccountUncheckedCreateWithoutPaymentTermInput>
  }

  export type PaymentAccountCreateManyPaymentTermInputEnvelope = {
    data: PaymentAccountCreateManyPaymentTermInput | PaymentAccountCreateManyPaymentTermInput[]
    skipDuplicates?: boolean
  }

  export type TopUpCreateWithoutPaymentTermInput = {
    id?: string
    nominal: number
    proofOfTransferFileName: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    admin?: AdminCreateNestedOneWithoutTopUpsInput
    user: UserCreateNestedOneWithoutTopUpInput
    PaymentAccount: PaymentAccountCreateNestedOneWithoutTopUpsInput
  }

  export type TopUpUncheckedCreateWithoutPaymentTermInput = {
    id?: string
    nominal: number
    adminId?: string | null
    userId: string
    proofOfTransferFileName: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    paymentAccountId: string
  }

  export type TopUpCreateOrConnectWithoutPaymentTermInput = {
    where: TopUpWhereUniqueInput
    create: XOR<TopUpCreateWithoutPaymentTermInput, TopUpUncheckedCreateWithoutPaymentTermInput>
  }

  export type TopUpCreateManyPaymentTermInputEnvelope = {
    data: TopUpCreateManyPaymentTermInput | TopUpCreateManyPaymentTermInput[]
    skipDuplicates?: boolean
  }

  export type PaymentAccountUpsertWithWhereUniqueWithoutPaymentTermInput = {
    where: PaymentAccountWhereUniqueInput
    update: XOR<PaymentAccountUpdateWithoutPaymentTermInput, PaymentAccountUncheckedUpdateWithoutPaymentTermInput>
    create: XOR<PaymentAccountCreateWithoutPaymentTermInput, PaymentAccountUncheckedCreateWithoutPaymentTermInput>
  }

  export type PaymentAccountUpdateWithWhereUniqueWithoutPaymentTermInput = {
    where: PaymentAccountWhereUniqueInput
    data: XOR<PaymentAccountUpdateWithoutPaymentTermInput, PaymentAccountUncheckedUpdateWithoutPaymentTermInput>
  }

  export type PaymentAccountUpdateManyWithWhereWithoutPaymentTermInput = {
    where: PaymentAccountScalarWhereInput
    data: XOR<PaymentAccountUpdateManyMutationInput, PaymentAccountUncheckedUpdateManyWithoutPaymentTermInput>
  }

  export type PaymentAccountScalarWhereInput = {
    AND?: PaymentAccountScalarWhereInput | PaymentAccountScalarWhereInput[]
    OR?: PaymentAccountScalarWhereInput[]
    NOT?: PaymentAccountScalarWhereInput | PaymentAccountScalarWhereInput[]
    id?: StringFilter<"PaymentAccount"> | string
    paymentTermId?: StringFilter<"PaymentAccount"> | string
    accountHolderName?: StringFilter<"PaymentAccount"> | string
    accountNumber?: StringFilter<"PaymentAccount"> | string
    status?: StringFilter<"PaymentAccount"> | string
    createdAt?: DateTimeFilter<"PaymentAccount"> | Date | string
    updatedAt?: DateTimeFilter<"PaymentAccount"> | Date | string
  }

  export type TopUpUpsertWithWhereUniqueWithoutPaymentTermInput = {
    where: TopUpWhereUniqueInput
    update: XOR<TopUpUpdateWithoutPaymentTermInput, TopUpUncheckedUpdateWithoutPaymentTermInput>
    create: XOR<TopUpCreateWithoutPaymentTermInput, TopUpUncheckedCreateWithoutPaymentTermInput>
  }

  export type TopUpUpdateWithWhereUniqueWithoutPaymentTermInput = {
    where: TopUpWhereUniqueInput
    data: XOR<TopUpUpdateWithoutPaymentTermInput, TopUpUncheckedUpdateWithoutPaymentTermInput>
  }

  export type TopUpUpdateManyWithWhereWithoutPaymentTermInput = {
    where: TopUpScalarWhereInput
    data: XOR<TopUpUpdateManyMutationInput, TopUpUncheckedUpdateManyWithoutPaymentTermInput>
  }

  export type PaymentTermCreateWithoutPaymentAccountsInput = {
    id?: string
    name: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    TopUps?: TopUpCreateNestedManyWithoutPaymentTermInput
  }

  export type PaymentTermUncheckedCreateWithoutPaymentAccountsInput = {
    id?: string
    name: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    TopUps?: TopUpUncheckedCreateNestedManyWithoutPaymentTermInput
  }

  export type PaymentTermCreateOrConnectWithoutPaymentAccountsInput = {
    where: PaymentTermWhereUniqueInput
    create: XOR<PaymentTermCreateWithoutPaymentAccountsInput, PaymentTermUncheckedCreateWithoutPaymentAccountsInput>
  }

  export type TopUpCreateWithoutPaymentAccountInput = {
    id?: string
    nominal: number
    proofOfTransferFileName: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    admin?: AdminCreateNestedOneWithoutTopUpsInput
    user: UserCreateNestedOneWithoutTopUpInput
    paymentTerm: PaymentTermCreateNestedOneWithoutTopUpsInput
  }

  export type TopUpUncheckedCreateWithoutPaymentAccountInput = {
    id?: string
    nominal: number
    adminId?: string | null
    userId: string
    proofOfTransferFileName: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    paymentTermId: string
  }

  export type TopUpCreateOrConnectWithoutPaymentAccountInput = {
    where: TopUpWhereUniqueInput
    create: XOR<TopUpCreateWithoutPaymentAccountInput, TopUpUncheckedCreateWithoutPaymentAccountInput>
  }

  export type TopUpCreateManyPaymentAccountInputEnvelope = {
    data: TopUpCreateManyPaymentAccountInput | TopUpCreateManyPaymentAccountInput[]
    skipDuplicates?: boolean
  }

  export type PaymentTermUpsertWithoutPaymentAccountsInput = {
    update: XOR<PaymentTermUpdateWithoutPaymentAccountsInput, PaymentTermUncheckedUpdateWithoutPaymentAccountsInput>
    create: XOR<PaymentTermCreateWithoutPaymentAccountsInput, PaymentTermUncheckedCreateWithoutPaymentAccountsInput>
    where?: PaymentTermWhereInput
  }

  export type PaymentTermUpdateToOneWithWhereWithoutPaymentAccountsInput = {
    where?: PaymentTermWhereInput
    data: XOR<PaymentTermUpdateWithoutPaymentAccountsInput, PaymentTermUncheckedUpdateWithoutPaymentAccountsInput>
  }

  export type PaymentTermUpdateWithoutPaymentAccountsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    TopUps?: TopUpUpdateManyWithoutPaymentTermNestedInput
  }

  export type PaymentTermUncheckedUpdateWithoutPaymentAccountsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    TopUps?: TopUpUncheckedUpdateManyWithoutPaymentTermNestedInput
  }

  export type TopUpUpsertWithWhereUniqueWithoutPaymentAccountInput = {
    where: TopUpWhereUniqueInput
    update: XOR<TopUpUpdateWithoutPaymentAccountInput, TopUpUncheckedUpdateWithoutPaymentAccountInput>
    create: XOR<TopUpCreateWithoutPaymentAccountInput, TopUpUncheckedCreateWithoutPaymentAccountInput>
  }

  export type TopUpUpdateWithWhereUniqueWithoutPaymentAccountInput = {
    where: TopUpWhereUniqueInput
    data: XOR<TopUpUpdateWithoutPaymentAccountInput, TopUpUncheckedUpdateWithoutPaymentAccountInput>
  }

  export type TopUpUpdateManyWithWhereWithoutPaymentAccountInput = {
    where: TopUpScalarWhereInput
    data: XOR<TopUpUpdateManyMutationInput, TopUpUncheckedUpdateManyWithoutPaymentAccountInput>
  }

  export type UserCreateWithoutWishlistsInput = {
    id?: string
    name: string
    email: string
    password: string
    status: string
    profile: string
    balance: number
    createdAt?: Date | string
    updatedAt?: Date | string
    topUp?: TopUpCreateNestedManyWithoutUserInput
    transactions?: TransactionCreateNestedManyWithoutUserInput
    userVerificationTokens?: UserVerificationTokenCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutWishlistsInput = {
    id?: string
    name: string
    email: string
    password: string
    status: string
    profile: string
    balance: number
    createdAt?: Date | string
    updatedAt?: Date | string
    topUp?: TopUpUncheckedCreateNestedManyWithoutUserInput
    transactions?: TransactionUncheckedCreateNestedManyWithoutUserInput
    userVerificationTokens?: UserVerificationTokenUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutWishlistsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutWishlistsInput, UserUncheckedCreateWithoutWishlistsInput>
  }

  export type ProductCreateWithoutWishlistsInput = {
    id?: string
    name: string
    status: string
    price: number
    stock: number
    description: string
    imageFileName?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    category: CategoryCreateNestedOneWithoutProductsInput
    stockMutations?: StockMutationCreateNestedManyWithoutProductInput
    transactionDetails?: TransactionDetailsCreateNestedManyWithoutProductInput
  }

  export type ProductUncheckedCreateWithoutWishlistsInput = {
    id?: string
    categoryId: string
    name: string
    status: string
    price: number
    stock: number
    description: string
    imageFileName?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    stockMutations?: StockMutationUncheckedCreateNestedManyWithoutProductInput
    transactionDetails?: TransactionDetailsUncheckedCreateNestedManyWithoutProductInput
  }

  export type ProductCreateOrConnectWithoutWishlistsInput = {
    where: ProductWhereUniqueInput
    create: XOR<ProductCreateWithoutWishlistsInput, ProductUncheckedCreateWithoutWishlistsInput>
  }

  export type UserUpsertWithoutWishlistsInput = {
    update: XOR<UserUpdateWithoutWishlistsInput, UserUncheckedUpdateWithoutWishlistsInput>
    create: XOR<UserCreateWithoutWishlistsInput, UserUncheckedCreateWithoutWishlistsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutWishlistsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutWishlistsInput, UserUncheckedUpdateWithoutWishlistsInput>
  }

  export type UserUpdateWithoutWishlistsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    profile?: StringFieldUpdateOperationsInput | string
    balance?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    topUp?: TopUpUpdateManyWithoutUserNestedInput
    transactions?: TransactionUpdateManyWithoutUserNestedInput
    userVerificationTokens?: UserVerificationTokenUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutWishlistsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    profile?: StringFieldUpdateOperationsInput | string
    balance?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    topUp?: TopUpUncheckedUpdateManyWithoutUserNestedInput
    transactions?: TransactionUncheckedUpdateManyWithoutUserNestedInput
    userVerificationTokens?: UserVerificationTokenUncheckedUpdateManyWithoutUserNestedInput
  }

  export type ProductUpsertWithoutWishlistsInput = {
    update: XOR<ProductUpdateWithoutWishlistsInput, ProductUncheckedUpdateWithoutWishlistsInput>
    create: XOR<ProductCreateWithoutWishlistsInput, ProductUncheckedCreateWithoutWishlistsInput>
    where?: ProductWhereInput
  }

  export type ProductUpdateToOneWithWhereWithoutWishlistsInput = {
    where?: ProductWhereInput
    data: XOR<ProductUpdateWithoutWishlistsInput, ProductUncheckedUpdateWithoutWishlistsInput>
  }

  export type ProductUpdateWithoutWishlistsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    price?: IntFieldUpdateOperationsInput | number
    stock?: IntFieldUpdateOperationsInput | number
    description?: StringFieldUpdateOperationsInput | string
    imageFileName?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    category?: CategoryUpdateOneRequiredWithoutProductsNestedInput
    stockMutations?: StockMutationUpdateManyWithoutProductNestedInput
    transactionDetails?: TransactionDetailsUpdateManyWithoutProductNestedInput
  }

  export type ProductUncheckedUpdateWithoutWishlistsInput = {
    id?: StringFieldUpdateOperationsInput | string
    categoryId?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    price?: IntFieldUpdateOperationsInput | number
    stock?: IntFieldUpdateOperationsInput | number
    description?: StringFieldUpdateOperationsInput | string
    imageFileName?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    stockMutations?: StockMutationUncheckedUpdateManyWithoutProductNestedInput
    transactionDetails?: TransactionDetailsUncheckedUpdateManyWithoutProductNestedInput
  }

  export type AdminCreateWithoutTopUpsInput = {
    id?: string
    name: string
    email: string
    password: string
    role: string
    status: string
    isPasswordChanged: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type AdminUncheckedCreateWithoutTopUpsInput = {
    id?: string
    name: string
    email: string
    password: string
    role: string
    status: string
    isPasswordChanged: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type AdminCreateOrConnectWithoutTopUpsInput = {
    where: AdminWhereUniqueInput
    create: XOR<AdminCreateWithoutTopUpsInput, AdminUncheckedCreateWithoutTopUpsInput>
  }

  export type UserCreateWithoutTopUpInput = {
    id?: string
    name: string
    email: string
    password: string
    status: string
    profile: string
    balance: number
    createdAt?: Date | string
    updatedAt?: Date | string
    wishlists?: WishlistCreateNestedManyWithoutUserInput
    transactions?: TransactionCreateNestedManyWithoutUserInput
    userVerificationTokens?: UserVerificationTokenCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutTopUpInput = {
    id?: string
    name: string
    email: string
    password: string
    status: string
    profile: string
    balance: number
    createdAt?: Date | string
    updatedAt?: Date | string
    wishlists?: WishlistUncheckedCreateNestedManyWithoutUserInput
    transactions?: TransactionUncheckedCreateNestedManyWithoutUserInput
    userVerificationTokens?: UserVerificationTokenUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutTopUpInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutTopUpInput, UserUncheckedCreateWithoutTopUpInput>
  }

  export type PaymentAccountCreateWithoutTopUpsInput = {
    id?: string
    accountHolderName: string
    accountNumber: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    paymentTerm: PaymentTermCreateNestedOneWithoutPaymentAccountsInput
  }

  export type PaymentAccountUncheckedCreateWithoutTopUpsInput = {
    id?: string
    paymentTermId: string
    accountHolderName: string
    accountNumber: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type PaymentAccountCreateOrConnectWithoutTopUpsInput = {
    where: PaymentAccountWhereUniqueInput
    create: XOR<PaymentAccountCreateWithoutTopUpsInput, PaymentAccountUncheckedCreateWithoutTopUpsInput>
  }

  export type PaymentTermCreateWithoutTopUpsInput = {
    id?: string
    name: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    PaymentAccounts?: PaymentAccountCreateNestedManyWithoutPaymentTermInput
  }

  export type PaymentTermUncheckedCreateWithoutTopUpsInput = {
    id?: string
    name: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    PaymentAccounts?: PaymentAccountUncheckedCreateNestedManyWithoutPaymentTermInput
  }

  export type PaymentTermCreateOrConnectWithoutTopUpsInput = {
    where: PaymentTermWhereUniqueInput
    create: XOR<PaymentTermCreateWithoutTopUpsInput, PaymentTermUncheckedCreateWithoutTopUpsInput>
  }

  export type AdminUpsertWithoutTopUpsInput = {
    update: XOR<AdminUpdateWithoutTopUpsInput, AdminUncheckedUpdateWithoutTopUpsInput>
    create: XOR<AdminCreateWithoutTopUpsInput, AdminUncheckedCreateWithoutTopUpsInput>
    where?: AdminWhereInput
  }

  export type AdminUpdateToOneWithWhereWithoutTopUpsInput = {
    where?: AdminWhereInput
    data: XOR<AdminUpdateWithoutTopUpsInput, AdminUncheckedUpdateWithoutTopUpsInput>
  }

  export type AdminUpdateWithoutTopUpsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    role?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    isPasswordChanged?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AdminUncheckedUpdateWithoutTopUpsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    role?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    isPasswordChanged?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserUpsertWithoutTopUpInput = {
    update: XOR<UserUpdateWithoutTopUpInput, UserUncheckedUpdateWithoutTopUpInput>
    create: XOR<UserCreateWithoutTopUpInput, UserUncheckedCreateWithoutTopUpInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutTopUpInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutTopUpInput, UserUncheckedUpdateWithoutTopUpInput>
  }

  export type UserUpdateWithoutTopUpInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    profile?: StringFieldUpdateOperationsInput | string
    balance?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    wishlists?: WishlistUpdateManyWithoutUserNestedInput
    transactions?: TransactionUpdateManyWithoutUserNestedInput
    userVerificationTokens?: UserVerificationTokenUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutTopUpInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    profile?: StringFieldUpdateOperationsInput | string
    balance?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    wishlists?: WishlistUncheckedUpdateManyWithoutUserNestedInput
    transactions?: TransactionUncheckedUpdateManyWithoutUserNestedInput
    userVerificationTokens?: UserVerificationTokenUncheckedUpdateManyWithoutUserNestedInput
  }

  export type PaymentAccountUpsertWithoutTopUpsInput = {
    update: XOR<PaymentAccountUpdateWithoutTopUpsInput, PaymentAccountUncheckedUpdateWithoutTopUpsInput>
    create: XOR<PaymentAccountCreateWithoutTopUpsInput, PaymentAccountUncheckedCreateWithoutTopUpsInput>
    where?: PaymentAccountWhereInput
  }

  export type PaymentAccountUpdateToOneWithWhereWithoutTopUpsInput = {
    where?: PaymentAccountWhereInput
    data: XOR<PaymentAccountUpdateWithoutTopUpsInput, PaymentAccountUncheckedUpdateWithoutTopUpsInput>
  }

  export type PaymentAccountUpdateWithoutTopUpsInput = {
    id?: StringFieldUpdateOperationsInput | string
    accountHolderName?: StringFieldUpdateOperationsInput | string
    accountNumber?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    paymentTerm?: PaymentTermUpdateOneRequiredWithoutPaymentAccountsNestedInput
  }

  export type PaymentAccountUncheckedUpdateWithoutTopUpsInput = {
    id?: StringFieldUpdateOperationsInput | string
    paymentTermId?: StringFieldUpdateOperationsInput | string
    accountHolderName?: StringFieldUpdateOperationsInput | string
    accountNumber?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PaymentTermUpsertWithoutTopUpsInput = {
    update: XOR<PaymentTermUpdateWithoutTopUpsInput, PaymentTermUncheckedUpdateWithoutTopUpsInput>
    create: XOR<PaymentTermCreateWithoutTopUpsInput, PaymentTermUncheckedCreateWithoutTopUpsInput>
    where?: PaymentTermWhereInput
  }

  export type PaymentTermUpdateToOneWithWhereWithoutTopUpsInput = {
    where?: PaymentTermWhereInput
    data: XOR<PaymentTermUpdateWithoutTopUpsInput, PaymentTermUncheckedUpdateWithoutTopUpsInput>
  }

  export type PaymentTermUpdateWithoutTopUpsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    PaymentAccounts?: PaymentAccountUpdateManyWithoutPaymentTermNestedInput
  }

  export type PaymentTermUncheckedUpdateWithoutTopUpsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    PaymentAccounts?: PaymentAccountUncheckedUpdateManyWithoutPaymentTermNestedInput
  }

  export type UserCreateWithoutTransactionsInput = {
    id?: string
    name: string
    email: string
    password: string
    status: string
    profile: string
    balance: number
    createdAt?: Date | string
    updatedAt?: Date | string
    wishlists?: WishlistCreateNestedManyWithoutUserInput
    topUp?: TopUpCreateNestedManyWithoutUserInput
    userVerificationTokens?: UserVerificationTokenCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutTransactionsInput = {
    id?: string
    name: string
    email: string
    password: string
    status: string
    profile: string
    balance: number
    createdAt?: Date | string
    updatedAt?: Date | string
    wishlists?: WishlistUncheckedCreateNestedManyWithoutUserInput
    topUp?: TopUpUncheckedCreateNestedManyWithoutUserInput
    userVerificationTokens?: UserVerificationTokenUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutTransactionsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutTransactionsInput, UserUncheckedCreateWithoutTransactionsInput>
  }

  export type TransactionDetailsCreateWithoutTransactionInput = {
    id?: string
    purchasedPrice: number
    quantity: number
    subtotal: number
    createdAt?: Date | string
    updatedAt?: Date | string
    product: ProductCreateNestedOneWithoutTransactionDetailsInput
  }

  export type TransactionDetailsUncheckedCreateWithoutTransactionInput = {
    id?: string
    productId: string
    purchasedPrice: number
    quantity: number
    subtotal: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type TransactionDetailsCreateOrConnectWithoutTransactionInput = {
    where: TransactionDetailsWhereUniqueInput
    create: XOR<TransactionDetailsCreateWithoutTransactionInput, TransactionDetailsUncheckedCreateWithoutTransactionInput>
  }

  export type TransactionDetailsCreateManyTransactionInputEnvelope = {
    data: TransactionDetailsCreateManyTransactionInput | TransactionDetailsCreateManyTransactionInput[]
    skipDuplicates?: boolean
  }

  export type UserUpsertWithoutTransactionsInput = {
    update: XOR<UserUpdateWithoutTransactionsInput, UserUncheckedUpdateWithoutTransactionsInput>
    create: XOR<UserCreateWithoutTransactionsInput, UserUncheckedCreateWithoutTransactionsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutTransactionsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutTransactionsInput, UserUncheckedUpdateWithoutTransactionsInput>
  }

  export type UserUpdateWithoutTransactionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    profile?: StringFieldUpdateOperationsInput | string
    balance?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    wishlists?: WishlistUpdateManyWithoutUserNestedInput
    topUp?: TopUpUpdateManyWithoutUserNestedInput
    userVerificationTokens?: UserVerificationTokenUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutTransactionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    profile?: StringFieldUpdateOperationsInput | string
    balance?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    wishlists?: WishlistUncheckedUpdateManyWithoutUserNestedInput
    topUp?: TopUpUncheckedUpdateManyWithoutUserNestedInput
    userVerificationTokens?: UserVerificationTokenUncheckedUpdateManyWithoutUserNestedInput
  }

  export type TransactionDetailsUpsertWithWhereUniqueWithoutTransactionInput = {
    where: TransactionDetailsWhereUniqueInput
    update: XOR<TransactionDetailsUpdateWithoutTransactionInput, TransactionDetailsUncheckedUpdateWithoutTransactionInput>
    create: XOR<TransactionDetailsCreateWithoutTransactionInput, TransactionDetailsUncheckedCreateWithoutTransactionInput>
  }

  export type TransactionDetailsUpdateWithWhereUniqueWithoutTransactionInput = {
    where: TransactionDetailsWhereUniqueInput
    data: XOR<TransactionDetailsUpdateWithoutTransactionInput, TransactionDetailsUncheckedUpdateWithoutTransactionInput>
  }

  export type TransactionDetailsUpdateManyWithWhereWithoutTransactionInput = {
    where: TransactionDetailsScalarWhereInput
    data: XOR<TransactionDetailsUpdateManyMutationInput, TransactionDetailsUncheckedUpdateManyWithoutTransactionInput>
  }

  export type TransactionCreateWithoutTransactionDetailsInput = {
    id?: string
    total: number
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    user: UserCreateNestedOneWithoutTransactionsInput
  }

  export type TransactionUncheckedCreateWithoutTransactionDetailsInput = {
    id?: string
    userId: string
    total: number
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type TransactionCreateOrConnectWithoutTransactionDetailsInput = {
    where: TransactionWhereUniqueInput
    create: XOR<TransactionCreateWithoutTransactionDetailsInput, TransactionUncheckedCreateWithoutTransactionDetailsInput>
  }

  export type ProductCreateWithoutTransactionDetailsInput = {
    id?: string
    name: string
    status: string
    price: number
    stock: number
    description: string
    imageFileName?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    category: CategoryCreateNestedOneWithoutProductsInput
    stockMutations?: StockMutationCreateNestedManyWithoutProductInput
    wishlists?: WishlistCreateNestedManyWithoutProductInput
  }

  export type ProductUncheckedCreateWithoutTransactionDetailsInput = {
    id?: string
    categoryId: string
    name: string
    status: string
    price: number
    stock: number
    description: string
    imageFileName?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    stockMutations?: StockMutationUncheckedCreateNestedManyWithoutProductInput
    wishlists?: WishlistUncheckedCreateNestedManyWithoutProductInput
  }

  export type ProductCreateOrConnectWithoutTransactionDetailsInput = {
    where: ProductWhereUniqueInput
    create: XOR<ProductCreateWithoutTransactionDetailsInput, ProductUncheckedCreateWithoutTransactionDetailsInput>
  }

  export type TransactionUpsertWithoutTransactionDetailsInput = {
    update: XOR<TransactionUpdateWithoutTransactionDetailsInput, TransactionUncheckedUpdateWithoutTransactionDetailsInput>
    create: XOR<TransactionCreateWithoutTransactionDetailsInput, TransactionUncheckedCreateWithoutTransactionDetailsInput>
    where?: TransactionWhereInput
  }

  export type TransactionUpdateToOneWithWhereWithoutTransactionDetailsInput = {
    where?: TransactionWhereInput
    data: XOR<TransactionUpdateWithoutTransactionDetailsInput, TransactionUncheckedUpdateWithoutTransactionDetailsInput>
  }

  export type TransactionUpdateWithoutTransactionDetailsInput = {
    id?: StringFieldUpdateOperationsInput | string
    total?: IntFieldUpdateOperationsInput | number
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutTransactionsNestedInput
  }

  export type TransactionUncheckedUpdateWithoutTransactionDetailsInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    total?: IntFieldUpdateOperationsInput | number
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ProductUpsertWithoutTransactionDetailsInput = {
    update: XOR<ProductUpdateWithoutTransactionDetailsInput, ProductUncheckedUpdateWithoutTransactionDetailsInput>
    create: XOR<ProductCreateWithoutTransactionDetailsInput, ProductUncheckedCreateWithoutTransactionDetailsInput>
    where?: ProductWhereInput
  }

  export type ProductUpdateToOneWithWhereWithoutTransactionDetailsInput = {
    where?: ProductWhereInput
    data: XOR<ProductUpdateWithoutTransactionDetailsInput, ProductUncheckedUpdateWithoutTransactionDetailsInput>
  }

  export type ProductUpdateWithoutTransactionDetailsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    price?: IntFieldUpdateOperationsInput | number
    stock?: IntFieldUpdateOperationsInput | number
    description?: StringFieldUpdateOperationsInput | string
    imageFileName?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    category?: CategoryUpdateOneRequiredWithoutProductsNestedInput
    stockMutations?: StockMutationUpdateManyWithoutProductNestedInput
    wishlists?: WishlistUpdateManyWithoutProductNestedInput
  }

  export type ProductUncheckedUpdateWithoutTransactionDetailsInput = {
    id?: StringFieldUpdateOperationsInput | string
    categoryId?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    price?: IntFieldUpdateOperationsInput | number
    stock?: IntFieldUpdateOperationsInput | number
    description?: StringFieldUpdateOperationsInput | string
    imageFileName?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    stockMutations?: StockMutationUncheckedUpdateManyWithoutProductNestedInput
    wishlists?: WishlistUncheckedUpdateManyWithoutProductNestedInput
  }

  export type TopUpCreateManyAdminInput = {
    id?: string
    nominal: number
    userId: string
    proofOfTransferFileName: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    paymentAccountId: string
    paymentTermId: string
  }

  export type TopUpUpdateWithoutAdminInput = {
    id?: StringFieldUpdateOperationsInput | string
    nominal?: IntFieldUpdateOperationsInput | number
    proofOfTransferFileName?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutTopUpNestedInput
    PaymentAccount?: PaymentAccountUpdateOneRequiredWithoutTopUpsNestedInput
    paymentTerm?: PaymentTermUpdateOneRequiredWithoutTopUpsNestedInput
  }

  export type TopUpUncheckedUpdateWithoutAdminInput = {
    id?: StringFieldUpdateOperationsInput | string
    nominal?: IntFieldUpdateOperationsInput | number
    userId?: StringFieldUpdateOperationsInput | string
    proofOfTransferFileName?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    paymentAccountId?: StringFieldUpdateOperationsInput | string
    paymentTermId?: StringFieldUpdateOperationsInput | string
  }

  export type TopUpUncheckedUpdateManyWithoutAdminInput = {
    id?: StringFieldUpdateOperationsInput | string
    nominal?: IntFieldUpdateOperationsInput | number
    userId?: StringFieldUpdateOperationsInput | string
    proofOfTransferFileName?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    paymentAccountId?: StringFieldUpdateOperationsInput | string
    paymentTermId?: StringFieldUpdateOperationsInput | string
  }

  export type WishlistCreateManyUserInput = {
    id?: string
    productId: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type TopUpCreateManyUserInput = {
    id?: string
    nominal: number
    adminId?: string | null
    proofOfTransferFileName: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    paymentAccountId: string
    paymentTermId: string
  }

  export type TransactionCreateManyUserInput = {
    id?: string
    total: number
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type UserVerificationTokenCreateManyUserInput = {
    id?: string
    token: string
    purpose: string
    createdAt?: Date | string
    updatedAt?: Date | string
    expiredAt?: Date | string | null
  }

  export type WishlistUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    product?: ProductUpdateOneRequiredWithoutWishlistsNestedInput
  }

  export type WishlistUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    productId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type WishlistUncheckedUpdateManyWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    productId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type TopUpUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    nominal?: IntFieldUpdateOperationsInput | number
    proofOfTransferFileName?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    admin?: AdminUpdateOneWithoutTopUpsNestedInput
    PaymentAccount?: PaymentAccountUpdateOneRequiredWithoutTopUpsNestedInput
    paymentTerm?: PaymentTermUpdateOneRequiredWithoutTopUpsNestedInput
  }

  export type TopUpUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    nominal?: IntFieldUpdateOperationsInput | number
    adminId?: NullableStringFieldUpdateOperationsInput | string | null
    proofOfTransferFileName?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    paymentAccountId?: StringFieldUpdateOperationsInput | string
    paymentTermId?: StringFieldUpdateOperationsInput | string
  }

  export type TopUpUncheckedUpdateManyWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    nominal?: IntFieldUpdateOperationsInput | number
    adminId?: NullableStringFieldUpdateOperationsInput | string | null
    proofOfTransferFileName?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    paymentAccountId?: StringFieldUpdateOperationsInput | string
    paymentTermId?: StringFieldUpdateOperationsInput | string
  }

  export type TransactionUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    total?: IntFieldUpdateOperationsInput | number
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    transactionDetails?: TransactionDetailsUpdateManyWithoutTransactionNestedInput
  }

  export type TransactionUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    total?: IntFieldUpdateOperationsInput | number
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    transactionDetails?: TransactionDetailsUncheckedUpdateManyWithoutTransactionNestedInput
  }

  export type TransactionUncheckedUpdateManyWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    total?: IntFieldUpdateOperationsInput | number
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserVerificationTokenUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    purpose?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    expiredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type UserVerificationTokenUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    purpose?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    expiredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type UserVerificationTokenUncheckedUpdateManyWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    purpose?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    expiredAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type ProductCreateManyCategoryInput = {
    id?: string
    name: string
    status: string
    price: number
    stock: number
    description: string
    imageFileName?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type ProductUpdateWithoutCategoryInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    price?: IntFieldUpdateOperationsInput | number
    stock?: IntFieldUpdateOperationsInput | number
    description?: StringFieldUpdateOperationsInput | string
    imageFileName?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    stockMutations?: StockMutationUpdateManyWithoutProductNestedInput
    wishlists?: WishlistUpdateManyWithoutProductNestedInput
    transactionDetails?: TransactionDetailsUpdateManyWithoutProductNestedInput
  }

  export type ProductUncheckedUpdateWithoutCategoryInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    price?: IntFieldUpdateOperationsInput | number
    stock?: IntFieldUpdateOperationsInput | number
    description?: StringFieldUpdateOperationsInput | string
    imageFileName?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    stockMutations?: StockMutationUncheckedUpdateManyWithoutProductNestedInput
    wishlists?: WishlistUncheckedUpdateManyWithoutProductNestedInput
    transactionDetails?: TransactionDetailsUncheckedUpdateManyWithoutProductNestedInput
  }

  export type ProductUncheckedUpdateManyWithoutCategoryInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    price?: IntFieldUpdateOperationsInput | number
    stock?: IntFieldUpdateOperationsInput | number
    description?: StringFieldUpdateOperationsInput | string
    imageFileName?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type StockMutationCreateManyProductInput = {
    id?: string
    currentStock: number
    quantity: number
    type: string
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type WishlistCreateManyProductInput = {
    id?: string
    userId: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type TransactionDetailsCreateManyProductInput = {
    id?: string
    transactionId: string
    purchasedPrice: number
    quantity: number
    subtotal: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type StockMutationUpdateWithoutProductInput = {
    id?: StringFieldUpdateOperationsInput | string
    currentStock?: IntFieldUpdateOperationsInput | number
    quantity?: IntFieldUpdateOperationsInput | number
    type?: StringFieldUpdateOperationsInput | string
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type StockMutationUncheckedUpdateWithoutProductInput = {
    id?: StringFieldUpdateOperationsInput | string
    currentStock?: IntFieldUpdateOperationsInput | number
    quantity?: IntFieldUpdateOperationsInput | number
    type?: StringFieldUpdateOperationsInput | string
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type StockMutationUncheckedUpdateManyWithoutProductInput = {
    id?: StringFieldUpdateOperationsInput | string
    currentStock?: IntFieldUpdateOperationsInput | number
    quantity?: IntFieldUpdateOperationsInput | number
    type?: StringFieldUpdateOperationsInput | string
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type WishlistUpdateWithoutProductInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutWishlistsNestedInput
  }

  export type WishlistUncheckedUpdateWithoutProductInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type WishlistUncheckedUpdateManyWithoutProductInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type TransactionDetailsUpdateWithoutProductInput = {
    id?: StringFieldUpdateOperationsInput | string
    purchasedPrice?: IntFieldUpdateOperationsInput | number
    quantity?: IntFieldUpdateOperationsInput | number
    subtotal?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    transaction?: TransactionUpdateOneRequiredWithoutTransactionDetailsNestedInput
  }

  export type TransactionDetailsUncheckedUpdateWithoutProductInput = {
    id?: StringFieldUpdateOperationsInput | string
    transactionId?: StringFieldUpdateOperationsInput | string
    purchasedPrice?: IntFieldUpdateOperationsInput | number
    quantity?: IntFieldUpdateOperationsInput | number
    subtotal?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type TransactionDetailsUncheckedUpdateManyWithoutProductInput = {
    id?: StringFieldUpdateOperationsInput | string
    transactionId?: StringFieldUpdateOperationsInput | string
    purchasedPrice?: IntFieldUpdateOperationsInput | number
    quantity?: IntFieldUpdateOperationsInput | number
    subtotal?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PaymentAccountCreateManyPaymentTermInput = {
    id?: string
    accountHolderName: string
    accountNumber: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type TopUpCreateManyPaymentTermInput = {
    id?: string
    nominal: number
    adminId?: string | null
    userId: string
    proofOfTransferFileName: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    paymentAccountId: string
  }

  export type PaymentAccountUpdateWithoutPaymentTermInput = {
    id?: StringFieldUpdateOperationsInput | string
    accountHolderName?: StringFieldUpdateOperationsInput | string
    accountNumber?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    TopUps?: TopUpUpdateManyWithoutPaymentAccountNestedInput
  }

  export type PaymentAccountUncheckedUpdateWithoutPaymentTermInput = {
    id?: StringFieldUpdateOperationsInput | string
    accountHolderName?: StringFieldUpdateOperationsInput | string
    accountNumber?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    TopUps?: TopUpUncheckedUpdateManyWithoutPaymentAccountNestedInput
  }

  export type PaymentAccountUncheckedUpdateManyWithoutPaymentTermInput = {
    id?: StringFieldUpdateOperationsInput | string
    accountHolderName?: StringFieldUpdateOperationsInput | string
    accountNumber?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type TopUpUpdateWithoutPaymentTermInput = {
    id?: StringFieldUpdateOperationsInput | string
    nominal?: IntFieldUpdateOperationsInput | number
    proofOfTransferFileName?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    admin?: AdminUpdateOneWithoutTopUpsNestedInput
    user?: UserUpdateOneRequiredWithoutTopUpNestedInput
    PaymentAccount?: PaymentAccountUpdateOneRequiredWithoutTopUpsNestedInput
  }

  export type TopUpUncheckedUpdateWithoutPaymentTermInput = {
    id?: StringFieldUpdateOperationsInput | string
    nominal?: IntFieldUpdateOperationsInput | number
    adminId?: NullableStringFieldUpdateOperationsInput | string | null
    userId?: StringFieldUpdateOperationsInput | string
    proofOfTransferFileName?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    paymentAccountId?: StringFieldUpdateOperationsInput | string
  }

  export type TopUpUncheckedUpdateManyWithoutPaymentTermInput = {
    id?: StringFieldUpdateOperationsInput | string
    nominal?: IntFieldUpdateOperationsInput | number
    adminId?: NullableStringFieldUpdateOperationsInput | string | null
    userId?: StringFieldUpdateOperationsInput | string
    proofOfTransferFileName?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    paymentAccountId?: StringFieldUpdateOperationsInput | string
  }

  export type TopUpCreateManyPaymentAccountInput = {
    id?: string
    nominal: number
    adminId?: string | null
    userId: string
    proofOfTransferFileName: string
    status: string
    createdAt?: Date | string
    updatedAt?: Date | string
    paymentTermId: string
  }

  export type TopUpUpdateWithoutPaymentAccountInput = {
    id?: StringFieldUpdateOperationsInput | string
    nominal?: IntFieldUpdateOperationsInput | number
    proofOfTransferFileName?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    admin?: AdminUpdateOneWithoutTopUpsNestedInput
    user?: UserUpdateOneRequiredWithoutTopUpNestedInput
    paymentTerm?: PaymentTermUpdateOneRequiredWithoutTopUpsNestedInput
  }

  export type TopUpUncheckedUpdateWithoutPaymentAccountInput = {
    id?: StringFieldUpdateOperationsInput | string
    nominal?: IntFieldUpdateOperationsInput | number
    adminId?: NullableStringFieldUpdateOperationsInput | string | null
    userId?: StringFieldUpdateOperationsInput | string
    proofOfTransferFileName?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    paymentTermId?: StringFieldUpdateOperationsInput | string
  }

  export type TopUpUncheckedUpdateManyWithoutPaymentAccountInput = {
    id?: StringFieldUpdateOperationsInput | string
    nominal?: IntFieldUpdateOperationsInput | number
    adminId?: NullableStringFieldUpdateOperationsInput | string | null
    userId?: StringFieldUpdateOperationsInput | string
    proofOfTransferFileName?: StringFieldUpdateOperationsInput | string
    status?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    paymentTermId?: StringFieldUpdateOperationsInput | string
  }

  export type TransactionDetailsCreateManyTransactionInput = {
    id?: string
    productId: string
    purchasedPrice: number
    quantity: number
    subtotal: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type TransactionDetailsUpdateWithoutTransactionInput = {
    id?: StringFieldUpdateOperationsInput | string
    purchasedPrice?: IntFieldUpdateOperationsInput | number
    quantity?: IntFieldUpdateOperationsInput | number
    subtotal?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    product?: ProductUpdateOneRequiredWithoutTransactionDetailsNestedInput
  }

  export type TransactionDetailsUncheckedUpdateWithoutTransactionInput = {
    id?: StringFieldUpdateOperationsInput | string
    productId?: StringFieldUpdateOperationsInput | string
    purchasedPrice?: IntFieldUpdateOperationsInput | number
    quantity?: IntFieldUpdateOperationsInput | number
    subtotal?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type TransactionDetailsUncheckedUpdateManyWithoutTransactionInput = {
    id?: StringFieldUpdateOperationsInput | string
    productId?: StringFieldUpdateOperationsInput | string
    purchasedPrice?: IntFieldUpdateOperationsInput | number
    quantity?: IntFieldUpdateOperationsInput | number
    subtotal?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}